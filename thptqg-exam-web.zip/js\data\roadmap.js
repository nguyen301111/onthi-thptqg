// Dữ liệu Lộ trình Ôn thi Tốt nghiệp THPT 2027 cho học sinh 2k9
// Cập nhật chuẩn theo định hướng và khung chương trình GDPT 2018 của Bộ Giáo dục & Đào tạo

window.ROADMAP_2K9 = [
  {
    phaseId: "phase-1",
    phaseName: "Giai Đoạn 1: Bứt Phá Học Kỳ I & Quét Sạch Nền Tảng",
    timeframe: "Tháng 10/2026 – Tháng 12/2026",
    status: "Đang diễn ra",
    color: "blue",
    description: "Nắm vững toàn bộ kiến thức trọng tâm Học kỳ I Lớp 12 và củng cố vững chắc các chuyên đề bản lề Lớp 11.",
    target: "Mục tiêu: Đạt 7.0+ ở các bài kiểm tra khảo sát chất lượng HK1.",
    subjects: [
      {
        subjectName: "Toán Học",
        icon: "∑",
        color: "text-blue-600 bg-blue-50",
        items: [
          { id: "m1_1", text: "Ứng dụng đạo hàm: Tính đơn điệu, cực trị, GTLN - GTNN của hàm số", tag: "Toán 12", completed: false },
          { id: "m1_2", text: "Khảo sát và vẽ đồ thị hàm phân thức bậc 1/bậc 1, bậc 2/bậc 1 và tiệm cận xiên", tag: "Toán 12", completed: false },
          { id: "m1_3", text: "Bài toán thực tế tối ưu hóa (tối ưu chi phí, diện tích, thể tích, lợi nhuận)", tag: "Dạng mới BGD", completed: false },
          { id: "m1_4", text: "Vectơ và các phép toán vectơ trong không gian 3 chiều", tag: "Toán 12", completed: false },
          { id: "m1_5", text: "Hệ trục tọa độ Oxyz: Tọa độ điểm, vectơ, tích có hướng và ứng dụng", tag: "Toán 12", completed: false },
          { id: "m1_6", text: "Thống kê: Khoảng biến thiên, khoảng tứ phân vị, phương sai, độ lệch chuẩn mẫu ghép nhóm", tag: "Toán 12", completed: false },
          { id: "m1_7", text: "Ôn tập Lớp 11: Cấp số cộng, cấp số nhân, đạo hàm và tiếp tuyến", tag: "Lớp 11", completed: false }
        ]
      },
      {
        subjectName: "Vật Lí",
        icon: "⚡",
        color: "text-indigo-600 bg-indigo-50",
        items: [
          { id: "p1_1", text: "Vật lí nhiệt: Mô hình động học phân tử, cấu trúc chất, nhiệt độ và thang nhiệt độ (Celsius, Kelvin)", tag: "Vật lí 12", completed: false },
          { id: "p1_2", text: "Nội năng và định luật I nhiệt động lực học (Delta U = Q + A)", tag: "Vật lí 12", completed: false },
          { id: "p1_3", text: "Nhiệt dung riêng, nhiệt nóng chảy riêng, nhiệt hóa hơi riêng và thí nghiệm đo đạc", tag: "Thực hành", completed: false },
          { id: "p1_4", text: "Khí lí tưởng: Thuyết động học phân tử chất khí, áp suất chất khí tác dụng lên thành bình", tag: "Vật lí 12", completed: false },
          { id: "p1_5", text: "Định luật Boyle, Charles và phương trình trạng thái khí lí tưởng (p.V/T = const)", tag: "Vật lí 12", completed: false },
          { id: "p1_6", text: "Ôn tập Lớp 11: Điện tích, điện trường, định luật Coulomb, điện thế và tụ điện", tag: "Lớp 11", completed: false }
        ]
      },
      {
        subjectName: "Hóa Học",
        icon: "🧪",
        color: "text-emerald-600 bg-emerald-50",
        items: [
          { id: "c1_1", text: "Ester - Lipid: Danh pháp, tính chất vật lí, phản ứng thủy phân trong môi trường acid và kiềm", tag: "Hóa 12", completed: false },
          { id: "c1_2", text: "Chất béo (Triacylglycerol), xà phòng và chất giặt rửa tổng hợp, cơ chế giặt rửa", tag: "Hóa 12", completed: false },
          { id: "c1_3", text: "Carbohydrate: Phân loại, cấu trúc phân tử glucose, fructose, saccharose, maltose, tinh bột, cellulose", tag: "Hóa 12", completed: false },
          { id: "c1_4", text: "Phản ứng tráng bạc (Tollens), phản ứng màu với Cu(OH)2 và thủy phân tinh bột", tag: "Thí nghiệm", completed: false },
          { id: "c1_5", text: "Hợp chất chứa Nitơ: Amine (phân loại, bậc amine), Amino acid (lưỡng tính, điểm đẳng điện)", tag: "Hóa 12", completed: false },
          { id: "c1_6", text: "Peptide và Protein: Cấu trúc, liên kết peptide, phản ứng màu Biuret, enzyme", tag: "Hóa 12", completed: false },
          { id: "c1_7", text: "Ôn tập Lớp 11: Cân bằng hóa học, thuyết acid-base Bronsted - Lowry, pH và chuẩn độ dung dịch", tag: "Lớp 11", completed: false }
        ]
      }
    ]
  },
  {
    phaseId: "phase-2",
    phaseName: "Giai Đoạn 2: Về Đích Chương Trình 12 & Nâng Cao Vận Dụng",
    timeframe: "Tháng 01/2027 – Tháng 03/2027",
    status: "Sắp tới",
    color: "indigo",
    description: "Hoàn tất toàn bộ nội dung SGK Lớp 12 sớm hơn chương trình trên lớp để chuyển trọng tâm sang luyện đề.",
    target: "Mục tiêu: Hoàn thành 100% khối lượng kiến thức của cả 3 năm cấp ba trước tháng 4/2027.",
    subjects: [
      {
        subjectName: "Toán Học",
        icon: "∑",
        color: "text-blue-600 bg-blue-50",
        items: [
          { id: "m2_1", text: "Nguyên hàm và bảng nguyên hàm cơ bản, phương pháp đổi biến số, từng phần", tag: "Toán 12", completed: false },
          { id: "m2_2", text: "Tích phân xác định và ứng dụng hình học tính diện tích hình phẳng, thể tích khối tròn xoay", tag: "Toán 12", completed: false },
          { id: "m2_3", text: "Phương trình mặt phẳng, đường thẳng và mặt cầu trong không gian Oxyz", tag: "Toán 12", completed: false },
          { id: "m2_4", text: "Bài toán khoảng cách, góc và vị trí tương đối giữa đường thẳng, mặt phẳng trong Oxyz", tag: "Toán 12", completed: false },
          { id: "m2_5", text: "Xác suất có điều kiện: Định nghĩa, công thức nhân xác suất", tag: "Chương mới BGD", completed: false },
          { id: "m2_6", text: "Công thức xác suất toàn phần và công thức Bayes (Ứng dụng y học, dự báo)", tag: "Vận dụng cao", completed: false }
        ]
      },
      {
        subjectName: "Vật Lí",
        icon: "⚡",
        color: "text-indigo-600 bg-indigo-50",
        items: [
          { id: "p2_1", text: "Từ trường: Cảm ứng từ, từ trường của dòng điện chạy trong dây dẫn thẳng, tròn, ống dây", tag: "Vật lí 12", completed: false },
          { id: "p2_2", text: "Lực từ tác dụng lên đoạn dây dẫn mang dòng điện, lực Lorentz tác dụng lên điện tích chuyển động", tag: "Vật lí 12", completed: false },
          { id: "p2_3", text: "Từ thông, hiện tượng cảm ứng điện từ, định luật Faraday và định luật Lenz", tag: "Vật lí 12", completed: false },
          { id: "p2_4", text: "Vật lí hạt nhân: Cấu tạo hạt nhân, lực hạt nhân, độ hụt khối và năng lượng liên kết", tag: "Vật lí 12", completed: false },
          { id: "p2_5", text: "Phản ứng hạt nhân: Phân hạch, nhiệt hạch, định luật bảo toàn năng lượng và động lượng", tag: "Vật lí 12", completed: false },
          { id: "p2_6", text: "Định luật phóng xạ, chu kỳ bán rã và ứng dụng đồng vị phóng xạ trong y tế, khảo cổ", tag: "Vật lí 12", completed: false }
        ]
      },
      {
        subjectName: "Hóa Học",
        icon: "🧪",
        color: "text-emerald-600 bg-emerald-50",
        items: [
          { id: "c2_1", text: "Polymer và vật liệu polymer: Chất dẻo, tơ sợi, cao su, keo dán", tag: "Hóa 12", completed: false },
          { id: "c2_2", text: "Đại cương kim loại: Tính chất vật lí chung, tính khử, dãy thế điện cực chuẩn và pin Galvani", tag: "Hóa 12", completed: false },
          { id: "c2_3", text: "Điện phân dung dịch và điện phân nóng chảy, ứng dụng mạ điện, tinh chế kim loại", tag: "Hóa 12", completed: false },
          { id: "c2_4", text: "Kim loại chuyển tiếp dãy thứ nhất (Sc đến Zn) và cấu hình electron đặc trưng", tag: "Kiến thức 2018", completed: false },
          { id: "c2_5", text: "Hợp chất phức chất: Nguyên tử trung tâm, phối tử, số phối trí, dạng hình học và màu sắc", tag: "Trọng tâm mới", completed: false },
          { id: "c2_6", text: "Hóa học với môi trường và phát triển bền vững: Xử lý khí thải, nước thải, hóa học xanh", tag: "Hóa 12", completed: false }
        ]
      }
    ]
  },
  {
    phaseId: "phase-3",
    phaseName: "Giai Đoạn 3: Luyện Đề Thực Chiến Chuẩn Cấu Trúc BGD 2025-2027",
    timeframe: "Tháng 04/2027 – Tháng 05/2027",
    status: "Kế hoạch",
    color: "purple",
    description: "Luyện tối thiểu 30 đề thi thử chuẩn 3 phần mới, rèn kỹ năng quản lý thời gian và hạn chế tối đa bẫy điểm.",
    target: "Mục tiêu: Đạt phong độ ổn định 8.5 - 9.5 điểm trong mọi đề thi thử.",
    subjects: [
      {
        subjectName: "Chiến Lược Phần I (Trắc nghiệm 4 lựa chọn)",
        icon: "🎯",
        color: "text-purple-600 bg-purple-50",
        items: [
          { id: "strat_1", text: "Phản xạ câu nhận biết - thông hiểu: Hoàn thành trong 15 phút đầu, chính xác tuyệt đối 100%", tag: "Tối ưu tốc độ", completed: false },
          { id: "strat_2", text: "Kỹ năng loại trừ đáp án vô lý, thử nghiệm với các trường hợp đặc biệt", tag: "Mẹo làm bài", completed: false }
        ]
      },
      {
        subjectName: "Chiến Lược Phần II (Trắc nghiệm Đúng / Sai)",
        icon: "⚖️",
        color: "text-amber-600 bg-amber-50",
        items: [
          { id: "strat_3", text: "Tuyệt đối không đoán mò: Nắm vững quy tắc lũy tiến điểm (1 ý: 0.1đ; 2 ý: 0.25đ; 3 ý: 0.5đ; 4 ý: 1.0đ)", tag: "Chiến thuật", completed: false },
          { id: "strat_4", text: "Đọc kỹ từng câu chữ điều kiện biên (ví dụ: 'luôn luôn', 'chỉ khi', 'tất cả')", tag: "Phòng tránh bẫy", completed: false }
        ]
      },
      {
        subjectName: "Chiến Lược Phần III (Trắc nghiệm trả lời ngắn)",
        icon: "✍️",
        color: "text-rose-600 bg-rose-50",
        items: [
          { id: "strat_5", text: "Quy chuẩn làm tròn số: Làm tròn chữ số thập phân thứ nhất, thứ hai đúng yêu cầu đề bài", tag: "Cực kỳ quan trọng", completed: false },
          { id: "strat_6", text: "Kiểm tra đơn vị đo lường: Đổi chuẩn hệ SI (J, kJ, Pa, kPa, lít, m3, gam, kg)", tag: "Chống mất điểm", completed: false }
        ]
      }
    ]
  },
  {
    phaseId: "phase-4",
    phaseName: "Giai Đoạn 4: Tổng Duyệt, Giữ Vững Tâm Lý & Về Đích 2027",
    timeframe: "Tháng 06/2027 (Tháng Thi Tốt Nghiệp)",
    status: "Kế hoạch",
    color: "amber",
    description: "Rà soát lại sổ tay lỗi sai, củng cố sự tự tin, làm quen với áp lực phòng thi và thi tốt nghiệp THPT 2027 đạt kết quả cao nhất.",
    target: "Mục tiêu: Đạt điểm xét tuyển đại học tối đa vào các trường nguyện vọng 1 mong muốn.",
    subjects: [
      {
        subjectName: "Các Bước Tuần Cuối Cùng",
        icon: "🏆",
        color: "text-amber-600 bg-amber-50",
        items: [
          { id: "fin_1", text: "Xem lại toàn bộ Sổ tay lỗi sai (Mistake Log) đã tích lũy trong các lần thi thử", tag: "Ôn tập nhẹ nhàng", completed: false },
          { id: "fin_2", text: "Quét lại bảng công thức tổng hợp Toán - Lí - Hóa bỏ túi", tag: "Ghi nhớ nhanh", completed: false },
          { id: "fin_3", text: "Chuẩn bị đầy đủ máy tính cầm tay đạt chuẩn (Casio fx-580VN X, fx-880BTG) thay pin mới", tag: "Dụng cụ thi", completed: false },
          { id: "fin_4", text: "Điều chỉnh nhịp sinh học: Ngủ đủ giấc, thức dậy lúc 6h sáng để não bộ tỉnh táo nhất vào khung giờ thi", tag: "Tâm lý & Sức khỏe", completed: false }
        ]
      }
    ]
  }
];

// =======================================================================
// LỘ TRÌNH DÀNH RIÊNG CHO THÍ SINH TỰ DO / MẤT GỐC ÔN LẠI TỪ CON SỐ 0
// Cập nhật chuẩn theo định dạng Bộ GD&ĐT 2025 - 2027 (GDPT 2018)
// Thiết kế 4 chặng: Xóa Mất Gốc -> Bứt Phá Chuyên Đề -> Luyện Đề & Casio -> Tổng Lực 9+
// =======================================================================

window.ROADMAP_FREE_CANDIDATE_2K9 = [
  {
    phaseId: "phase-1",
    phaseName: "Chặng 1: Xóa Mất Gốc & Xây Lại Nền Tảng Cốt Lõi (0 → 5.5 Điểm)",
    timeframe: "3 Tháng Đầu (Tự học tốc hành 60-90 ngày)",
    status: "Bắt đầu ngay",
    color: "emerald",
    description: "Dành riêng cho thí sinh quên kiến thức hoặc mất gốc lâu năm. Khôi phục toàn bộ tư duy đại số, hình học cơ sở, định luật vật lý nền tảng và nguyên tắc phản ứng hóa học cơ bản.",
    target: "Mục tiêu: Quét sạch điểm liệt, cầm chắc 5.0 - 6.0 điểm trắc nghiệm phần nhận biết & thông hiểu.",
    subjects: [
      {
        subjectName: "Toán Học",
        icon: "∑",
        color: "text-blue-600 bg-blue-50",
        items: [
          { id: "free_m1_1", text: "Lấy lại gốc Đại số: Công thức nghiệm tam thức bậc 2, nhị thức bậc 1, quy tắc lũy thừa và logarit", tag: "Xóa mất gốc", completed: false },
          { id: "free_m1_2", text: "Đạo hàm căn bản: Bảng đạo hàm các hàm đa thức, phân thức, hàm mũ và logarit (x^n, e^x, ln x)", tag: "Toán 11 & 12", completed: false },
          { id: "free_m1_3", text: "Khảo sát hàm số cơ sở: Tìm tập xác định, xét dấu y' để xác định khoảng đồng biến, nghịch biến và cực trị", tag: "Toán 12", completed: false },
          { id: "free_m1_4", text: "Hình học không gian Oxyz cơ bản: Tọa độ điểm, vectơ, độ dài vectơ và tích vô hướng trong không gian 3 chiều", tag: "Toán 12", completed: false },
          { id: "free_m1_5", text: "Thống kê mẫu ghép nhóm: Đọc bảng tần số, tính số trung bình, trung vị, tứ phân vị cơ bản", tag: "Toán 12", completed: false },
          { id: "free_m1_6", text: "Kỹ năng Casio 570 cơ sở: Bấm giải phương trình bậc 2-3 (MODE 5-3, 5-4), dùng phím CALC thử giá trị", tag: "Kỹ năng Casio", completed: false }
        ]
      },
      {
        subjectName: "Vật Lí",
        icon: "⚡",
        color: "text-indigo-600 bg-indigo-50",
        items: [
          { id: "free_p1_1", text: "Khôi phục gốc Cơ học: Định luật II Newton (F = ma), định luật bảo toàn cơ năng, công thức công A = F.s.cos(alpha)", tag: "Xóa mất gốc", completed: false },
          { id: "free_p1_2", text: "Vật lí nhiệt cơ bản: Thuyết động học phân tử, cấu trúc chất rắn - lỏng - khí, chuyển đổi nhiệt độ Celsius và Kelvin", tag: "Vật lí 12", completed: false },
          { id: "free_p1_3", text: "Nội năng và định luật I nhiệt động lực học: Biểu thức Delta U = A + Q và quy ước dấu truyền nhiệt, sinh công", tag: "Vật lí 12", completed: false },
          { id: "free_p1_4", text: "Tính nhiệt lượng: Nhiệt dung riêng Q = mc.Delta t, nhiệt nóng chảy riêng Q = lambda.m, nhiệt hóa hơi riêng Q = L.m", tag: "Vật lí 12", completed: false },
          { id: "free_p1_5", text: "Khí lí tưởng cơ sở: Phương trình trạng thái pV/T = const và định luật Boyle (p.V = const trong đẳng nhiệt)", tag: "Vật lí 12", completed: false },
          { id: "free_p1_6", text: "Thao tác quy đổi đơn vị SI: Đổi chuẩn cm3/lit sang m3, áp suất mmHg/bar sang Pa, nhiệt độ sang Kelvin", tag: "Chống mất điểm", completed: false }
        ]
      },
      {
        subjectName: "Hóa Học",
        icon: "🧪",
        color: "text-emerald-600 bg-emerald-50",
        items: [
          { id: "free_c1_1", text: "Lấy lại gốc Hóa vô cơ: Bảng tuần hoàn, hóa trị kim loại/phi kim, xác định số oxi hóa trong hợp chất", tag: "Xóa mất gốc", completed: false },
          { id: "free_c1_2", text: "Các định luật bảo toàn cốt lõi: Bảo toàn khối lượng, bảo toàn nguyên tố, bảo toàn electron trong phản ứng oxi hóa - khử", tag: "Nền tảng vàng", completed: false },
          { id: "free_c1_3", text: "Thuyết Acid - Base Bronsted - Lowry: Khái niệm cho/nhận proton H+, công thức tính pH = -log[H+] và ý nghĩa thang pH", tag: "Hóa 11 & 12", completed: false },
          { id: "free_c1_4", text: "Nhập môn Hóa hữu cơ: Phân loại liên kết đơn, đôi, ba; danh pháp IUPAC mạch carbon cơ bản", tag: "Xóa mất gốc", completed: false },
          { id: "free_c1_5", text: "Ester cơ bản: Nhóm chức -COO-, công thức phân tử CnH2nO2 (n>=2), phản ứng thủy phân trong môi trường kiềm (xà phòng hóa)", tag: "Hóa 12", completed: false }
        ]
      }
    ]
  },
  {
    phaseId: "phase-2",
    phaseName: "Chặng 2: Nâng Cao Chuyên Đề Trọng Tâm & Bứt Phá Vận Dụng (5.5 → 7.5 Điểm)",
    timeframe: "Tháng Thứ 4 – Tháng Thứ 6",
    status: "Kế hoạch",
    color: "blue",
    description: "Tiến sâu vào các chuyên đề trọng tâm của SGK GDPT 2018 Lớp 12. Rèn luyện tư duy giải các bài toán có chứa tham số và mô hình hóa bài toán thực tế đời sống.",
    target: "Mục tiêu: Đạt 7.0 - 7.8 điểm vững chắc, hoàn thành trọn vẹn Phần I và ít nhất 2-3 ý mỗi câu ở Phần II.",
    subjects: [
      {
        subjectName: "Toán Học",
        icon: "∑",
        color: "text-blue-600 bg-blue-50",
        items: [
          { id: "free_m2_1", text: "Tiệm cận & Khảo sát đồ thị: Tiệm cận đứng, ngang và tiệm cận xiên của hàm phân thức bậc 2/bậc 1", tag: "Toán 12", completed: false },
          { id: "free_m2_2", text: "Bài toán thực tế tối ưu hóa: Ứng dụng GTLN - GTNN giải quyết bài toán kinh tế (doanh thu, lợi nhuận, thể tích hộp)", tag: "Trọng tâm BGD", completed: false },
          { id: "free_m2_3", text: "Nguyên hàm & Tích phân xác định: Bảng nguyên hàm mở rộng, đổi biến số, từng phần và diện tích hình phẳng", tag: "Toán 12", completed: false },
          { id: "free_m2_4", text: "Hình học Oxyz: Phương trình mặt cầu, mặt phẳng, khoảng cách từ điểm đến mp và góc giữa 2 đối tượng", tag: "Toán 12", completed: false },
          { id: "free_m2_5", text: "Xác suất có điều kiện: Công thức nhân xác suất P(AB) = P(A).P(B|A), bảng số liệu chéo 2x2 và công thức Bayes", tag: "Mới GDPT 2018", completed: false }
        ]
      },
      {
        subjectName: "Vật Lí",
        icon: "⚡",
        color: "text-indigo-600 bg-indigo-50",
        items: [
          { id: "free_p2_1", text: "Từ trường & Cảm ứng từ: Cảm ứng từ B của dòng điện thẳng, ống dây hình trụ B = 4pi.10^-7.n.I", tag: "Vật lí 12", completed: false },
          { id: "free_p2_2", text: "Lực từ & Lực Lorentz: Lực từ F = B.I.l.sin(alpha), quy tắc bàn tay trái, lực tác dụng lên hạt mang điện chuyển động", tag: "Vật lí 12", completed: false },
          { id: "free_p2_3", text: "Cảm ứng điện từ: Từ thông Phi = B.S.cos(alpha), định luật Faraday e_c = -Delta Phi/Delta t và định luật Lenz", tag: "Vật lí 12", completed: false },
          { id: "free_p2_4", text: "Vật lí hạt nhân: Cấu tạo hạt nhân (Z, N), độ hụt khối Delta m, năng lượng liên kết và liên kết riêng", tag: "Vật lí 12", completed: false },
          { id: "free_p2_5", text: "Phóng xạ & Năng lượng: Định luật phóng xạ N(t) = N0.2^(-t/T), chu kỳ bán rã và phản ứng phân hạch, nhiệt hạch", tag: "Vật lí 12", completed: false }
        ]
      },
      {
        subjectName: "Hóa Học",
        icon: "🧪",
        color: "text-emerald-600 bg-emerald-50",
        items: [
          { id: "free_c2_1", text: "Lipid & Chất béo: Cấu trúc triacylglycerol, phản ứng xà phòng hóa, cơ chế tẩy rửa của xà phòng và chất giặt rửa", tag: "Hóa 12", completed: false },
          { id: "free_c2_2", text: "Carbohydrate chuyên sâu: Phân biệt glucose, fructose, saccharose, maltose, tinh bột, cellulose và phản ứng tráng bạc", tag: "Hóa 12", completed: false },
          { id: "free_c2_3", text: "Hợp chất chứa Nitơ: Phân loại bậc amine, tính chất lưỡng tính của amino acid, liên kết peptide và phản ứng màu Biuret", tag: "Hóa 12", completed: false },
          { id: "free_c2_4", text: "Điện hóa học & Pin Galvani: Dãy thế điện cực chuẩn kim loại, sức điện động E0_pin = E0_catot - E0_anot, chống ăn mòn", tag: "Hóa 12", completed: false },
          { id: "free_c2_5", text: "Phức chất & Kim loại chuyển tiếp: Khái niệm nguyên tử trung tâm, phối tử (ligand), số phối trí và màu sắc phức chất", tag: "Mới GDPT 2018", completed: false }
        ]
      }
    ]
  },
  {
    phaseId: "phase-3",
    phaseName: "Chặng 3: Luyện Đề Chuẩn Form BGD 3 Phần & Rèn Phản Xạ Casio fx-570 (7.5 → 8.8 Điểm)",
    timeframe: "Tháng Thứ 7 – Tháng Thứ 9",
    status: "Kế hoạch",
    color: "indigo",
    description: "Thích nghi hoàn toàn với cấu trúc đề thi 3 phần của Bộ GD&ĐT. Làm chủ kỹ năng làm bài Đúng/Sai (Phần II) và câu trả lời ngắn điền số (Phần III). Thành thạo bấm máy tính Casio fx-570 để tăng tốc độ làm bài.",
    target: "Mục tiêu: Đạt 8.0 - 8.8 điểm ổn định, không bị mất điểm ngớ ngẩn do bẫy format mới.",
    subjects: [
      {
        subjectName: "Chiến Lược 3 Phần Đề Thi BGD",
        icon: "🎯",
        color: "text-purple-600 bg-purple-50",
        items: [
          { id: "free_strat_1", text: "Phần I (4 lựa chọn): Hoàn thành 12 câu Toán hoặc 18 câu Lí/Hóa trong 20 phút đầu, tuyệt đối chính xác 100%", tag: "Phản xạ nhanh", completed: false },
          { id: "free_strat_2", text: "Phần II (Đúng/Sai barem 0.1 - 0.25 - 0.5 - 1.0): Chỉ kết luận khi chắc chắn, nhận diện bẫy câu chữ biên (luôn luôn, duy nhất)", tag: "Chiến thuật barem", completed: false },
          { id: "free_strat_3", text: "Phần III (Điền đáp số): Tính toán đến bước cuối cùng, tuân thủ nghiêm ngặt quy tắc làm tròn (1 hoặc 2 chữ số thập phân)", tag: "Tránh mất điểm", completed: false },
          { id: "free_strat_4", text: "Quản lý thời gian: Phân bổ 40% cho P1, 35% cho P2 và 25% cho P3; luôn để dành 5 phút kiểm tra lại ô điền số", tag: "Kỹ năng phòng thi", completed: false }
        ]
      },
      {
        subjectName: "Kỹ Năng Bấm Máy Casio fx-570",
        icon: "🖩",
        color: "text-amber-600 bg-amber-50",
        items: [
          { id: "free_casio_1", text: "Chức năng TABLE (MODE 7): Dò tìm GTLN - GTNN của hàm số trên đoạn [a, b] với bước nhảy Step = (b-a)/29", tag: "Mẹo Casio", completed: false },
          { id: "free_casio_2", text: "Bấm tích phân và đạo hàm d/dx: Kiểm tra nhanh nguyên hàm, phương trình tiếp tuyến mà không cần tính tay", tag: "Mẹo Casio", completed: false },
          { id: "free_casio_3", text: "Giải hệ phương trình (MODE 5): Giải hệ 2-3 ẩn, tìm nghiệm phương trình bậc 2-3 phục vụ cân bằng hóa học và tìm tọa độ", tag: "Mẹo Casio", completed: false },
          { id: "free_casio_4", text: "Thống kê (MODE 3 STAT): Nhập mẫu số liệu ghép nhóm tính nhanh kỳ vọng, phương sai và độ lệch chuẩn", tag: "Mẹo Casio", completed: false }
        ]
      },
      {
        subjectName: "Kế Hoạch Thi Thử & Thi Lại",
        icon: "🔄",
        color: "text-emerald-600 bg-emerald-50",
        items: [
          { id: "free_retake_1", text: "Thi tối thiểu 2 đề thi thử/tuần trên web với bộ số đổi ngẫu nhiên để rèn luyện tư duy thực chất", tag: "Thực hành đều đặn", completed: false },
          { id: "free_retake_2", text: "Bấm 'Xem lại' sau mỗi lần thi, đọc kỹ phần Cơ sở lý thuyết và Lời giải chi tiết của mọi câu làm sai", tag: "Học từ sai lầm", completed: false },
          { id: "free_retake_3", text: "Sử dụng tính năng 'Thi lại đề này' sau 3 ngày để kiểm tra xem đã sửa được các lỗi sai của đề đó chưa", tag: "Cố định kiến thức", completed: false }
        ]
      }
    ]
  },
  {
    phaseId: "phase-4",
    phaseName: "Chặng 4: Tổng Lực Về Đích, Quét Sạch Lỗ Hổng & Chinh Phục Điểm 9+ (8.8 → 9.5+)",
    timeframe: "Giai Đoạn Nước Rút Trước Kỳ Thi",
    status: "Kế hoạch",
    color: "purple",
    description: "Giai đoạn then chốt dành cho thí sinh tự do cạnh tranh vào các trường đại học top 1 (Bách Khoa, Y Dược, Ngoại Thương, Kinh Tế). Tinh chỉnh đồng hồ sinh học và giữ vững tâm lý phòng thi bản lĩnh.",
    target: "Mục tiêu: Đạt 9.0 - 9.6 điểm, tối ưu hóa điểm số xét tuyển đại học tổ hợp A00, B00, A01.",
    subjects: [
      {
        subjectName: "Chinh Phục Câu Phân Loại Cao 9+",
        icon: "🏆",
        color: "text-purple-600 bg-purple-50",
        items: [
          { id: "free_adv_1", text: "Toán Vận dụng cao: Tối ưu hóa đa biến, bài toán xác suất Bayes nhiều nhánh trong y tế/kinh tế, Oxyz cực trị hình học", tag: "Điểm 9+", completed: false },
          { id: "free_adv_2", text: "Vật lí Vận dụng cao: Bài toán thực nghiệm đo nhiệt dung/nhiệt hóa hơi, chu trình Carnot, hạt nhân kết hợp bảo toàn động lượng", tag: "Điểm 9+", completed: false },
          { id: "free_adv_3", text: "Hóa học Vận dụng cao: Biện luận cấu tạo ester đa chức, bài toán hiệu suất pin điện hóa và điện phân nhiều giai đoạn", tag: "Điểm 9+", completed: false }
        ]
      },
      {
        subjectName: "Tâm Lý & Chiến Thuật Thí Sinh Tự Do",
        icon: "🛡️",
        color: "text-amber-600 bg-amber-50",
        items: [
          { id: "free_mind_1", text: "Giải tỏa áp lực tâm lý: Thí sinh tự do thường tự ti về khoảng trống kiến thức - hãy kiên định với tiến độ cá nhân", tag: "Tâm lý", completed: false },
          { id: "free_mind_2", text: "Quét lại Sổ tay lỗi sai trong mục Lịch Sử: Xem lại toàn bộ câu hỏi từng làm sai để không lặp lại lỗi cũ", tag: "Chống mất điểm", completed: false },
          { id: "free_mind_3", text: "Điều chỉnh nhịp sinh học: Đi ngủ trước 23h, thức dậy 5h30 để não bộ đạt độ hưng phấn cao nhất vào khung giờ thi sáng", tag: "Sức khỏe", completed: false },
          { id: "free_mind_4", text: "Chuẩn bị đầy đủ hồ sơ dự thi thí sinh tự do, thẻ CCCD và 2 máy tính Casio thay pin mới sẵn sàng", tag: "Hành trang thi", completed: false }
        ]
      }
    ]
  }
];

