// Máy tính khoa học Casio fx-570VN PLUS ảo tích hợp trên web
// Thiết kế dành riêng cho thí sinh luyện thi THPT Quốc Gia (Toán, Vật Lí, Hóa Học)

(function() {
  const Casio570 = {
    isOpen: false,
    isMinimized: false,
    mode: 'calc', // 'calc' | 'eqn2' | 'sys2'
    angleMode: 'DEG', // 'DEG' | 'RAD'
    isShift: false,
    isAlpha: false,
    expression: '',      // Biểu thức hiển thị trên màn hình LCD
    internalExpr: '',    // Biểu thức dùng để tính toán
    result: '0',         // Kết quả tính toán
    lastAns: 0,          // Giá trị Ans trước đó
    memory: 0,           // Bộ nhớ M
    isShowingFraction: false,
    currentFraction: null,
    
    // Khởi tạo
    init: function() {
      this.bindKeyboard();
      this.makeDraggable();
      this.render();
    },

    // Bật/tắt giao diện máy tính
    toggle: function() {
      const widget = document.getElementById('casio-widget');
      if (!widget) return;
      this.isOpen = !this.isOpen;
      if (this.isOpen) {
        widget.classList.remove('hidden');
        this.isMinimized = false;
        widget.classList.remove('casio-minimized');
        this.updateDisplay();
      } else {
        widget.classList.add('hidden');
      }
    },

    // Thu nhỏ / phóng to
    toggleMinimize: function() {
      const widget = document.getElementById('casio-widget');
      if (!widget) return;
      this.isMinimized = !this.isMinimized;
      if (this.isMinimized) {
        widget.classList.add('casio-minimized');
      } else {
        widget.classList.remove('casio-minimized');
      }
    },

    // Chuyển đổi DEG / RAD
    toggleAngleMode: function() {
      this.angleMode = this.angleMode === 'DEG' ? 'RAD' : 'DEG';
      this.updateDisplay();
    },

    // Bật/tắt SHIFT
    toggleShift: function() {
      this.isShift = !this.isShift;
      this.isAlpha = false;
      this.updateIndicators();
    },

    // Bật/tắt ALPHA
    toggleAlpha: function() {
      this.isAlpha = !this.isAlpha;
      this.isShift = false;
      this.updateIndicators();
    },

    // Chuyển đổi tab tính năng (Tính toán / Giải PT bậc 2 / Giải Hệ PT)
    setTab: function(tabName) {
      this.mode = tabName;
      const calcKeypad = document.getElementById('casio-calc-keypad');
      const eqnPanel = document.getElementById('casio-eqn-panel');
      const tabCalc = document.getElementById('casio-tab-calc');
      const tabEqn = document.getElementById('casio-tab-eqn');

      if (tabName === 'calc') {
        if (calcKeypad) calcKeypad.classList.remove('hidden');
        if (eqnPanel) eqnPanel.classList.add('hidden');
        if (tabCalc) tabCalc.className = "px-3 py-1 text-xs font-bold rounded-lg bg-amber-400 text-slate-900";
        if (tabEqn) tabEqn.className = "px-3 py-1 text-xs font-bold rounded-lg text-slate-400 hover:text-white";
      } else {
        if (calcKeypad) calcKeypad.classList.add('hidden');
        if (eqnPanel) eqnPanel.classList.remove('hidden');
        if (tabCalc) tabCalc.className = "px-3 py-1 text-xs font-bold rounded-lg text-slate-400 hover:text-white";
        if (tabEqn) tabEqn.className = "px-3 py-1 text-xs font-bold rounded-lg bg-amber-400 text-slate-900";
      }
    },

    // Thêm ký tự hoặc toán tử vào biểu thức
    input: function(displayChar, evalChar = displayChar) {
      // Nếu vừa có kết quả mà nhập số mới (không phải toán tử), reset biểu thức
      if (this.justCalculated && !['+', '-', '×', '÷', '^', '²', '³'].includes(displayChar)) {
        this.expression = '';
        this.internalExpr = '';
      }
      this.justCalculated = false;

      this.expression += displayChar;
      this.internalExpr += evalChar;

      // Reset Shift & Alpha sau khi nhấn nút
      if (this.isShift) {
        this.isShift = false;
        this.updateIndicators();
      }
      if (this.isAlpha) {
        this.isAlpha = false;
        this.updateIndicators();
      }

      this.updateDisplay();
    },

    // Nhập hàm toán học (như sin(, cos(, sqrt()
    inputFunc: function(funcName, internalName = funcName) {
      if (this.justCalculated) {
        this.expression = '';
        this.internalExpr = '';
      }
      this.justCalculated = false;

      let disp = funcName + '(';
      let evalStr = internalName + '(';

      // Xử lý các hàm đặc biệt theo trạng thái SHIFT
      if (this.isShift) {
        if (funcName === 'sin') { disp = 'sin⁻¹('; evalStr = 'asin('; }
        else if (funcName === 'cos') { disp = 'cos⁻¹('; evalStr = 'acos('; }
        else if (funcName === 'tan') { disp = 'tan⁻¹('; evalStr = 'atan('; }
        else if (funcName === '√') { disp = '∛('; evalStr = 'cbrt('; }
        else if (funcName === 'log') { disp = '10^('; evalStr = '10^('; }
        else if (funcName === 'ln') { disp = 'e^('; evalStr = 'exp('; }
        this.isShift = false;
        this.updateIndicators();
      }

      this.expression += disp;
      this.internalExpr += evalStr;
      this.updateDisplay();
    },

    // Xóa ký tự cuối (DEL)
    del: function() {
      if (this.expression.length > 0) {
        this.expression = this.expression.slice(0, -1);
        this.internalExpr = this.internalExpr.slice(0, -1);
      }
      this.updateDisplay();
    },

    // Xóa toàn bộ (AC)
    ac: function() {
      this.expression = '';
      this.internalExpr = '';
      this.result = '0';
      this.currentFraction = null;
      this.isShowingFraction = false;
      this.updateDisplay();
    },

    // Tính toán kết quả (=)
    calculate: function() {
      if (!this.expression.trim()) return;

      try {
        let code = this.internalExpr;

        // Chuẩn hóa biểu thức
        code = code.replace(/×/g, '*').replace(/÷/g, '/');
        code = code.replace(/π/g, 'Math.PI');
        code = code.replace(/Ans/g, '(' + this.lastAns + ')');
        code = code.replace(/²/g, '^2').replace(/³/g, '^3');

        // Đóng các dấu ngoặc còn thiếu
        const openParens = (code.match(/\(/g) || []).length;
        const closeParens = (code.match(/\)/g) || []).length;
        if (openParens > closeParens) {
          code += ')'.repeat(openParens - closeParens);
        }

        // Tính toán an toàn
        const calculatedVal = this.evaluateMath(code);

        if (isNaN(calculatedVal) || !isFinite(calculatedVal)) {
          this.result = 'Math ERROR';
        } else {
          // Làm tròn số thực tránh lỗi dấu phẩy động 0.0000000000000001
          const cleanNum = Math.abs(calculatedVal) < 1e-12 ? 0 : calculatedVal;
          this.lastAns = cleanNum;
          this.result = this.formatNumber(cleanNum);
          this.currentFraction = this.toFraction(cleanNum);
          this.isShowingFraction = false;
        }
      } catch (err) {
        this.result = 'Syntax ERROR';
      }

      this.justCalculated = true;
      this.updateDisplay();
    },

    // Đánh giá biểu thức toán học có hàm lượng giác DEG/RAD
    evaluateMath: function(expr) {
      const isDeg = this.angleMode === 'DEG';
      const toRad = deg => (deg * Math.PI) / 180;
      const toDeg = rad => (rad * 180) / Math.PI;

      // Hàm bọc lượng giác
      const mathScope = {
        sin: x => Math.sin(isDeg ? toRad(x) : x),
        cos: x => Math.cos(isDeg ? toRad(x) : x),
        tan: x => {
          const cosVal = Math.cos(isDeg ? toRad(x) : x);
          if (Math.abs(cosVal) < 1e-12) throw new Error("Math ERROR");
          return Math.tan(isDeg ? toRad(x) : x);
        },
        asin: x => (isDeg ? toDeg(Math.asin(x)) : Math.asin(x)),
        acos: x => (isDeg ? toDeg(Math.acos(x)) : Math.acos(x)),
        atan: x => (isDeg ? toDeg(Math.atan(x)) : Math.atan(x)),
        sqrt: x => Math.sqrt(x),
        cbrt: x => Math.cbrt(x),
        log: x => Math.log10(x),
        ln: x => Math.log(x),
        exp: x => Math.exp(x),
        abs: x => Math.abs(x),
        fact: n => {
          if (n < 0 || !Number.isInteger(n)) return NaN;
          let r = 1;
          for (let i = 2; i <= n; i++) r *= i;
          return r;
        },
        PI: Math.PI,
        E: Math.E
      };

      // Xử lý lũy thừa a^b thành Math.pow(a, b)
      let parsed = expr;
      
      // Xử lý n!
      parsed = parsed.replace(/(\d+)!/g, 'fact($1)');

      // Thay thế hàm toán học
      parsed = parsed.replace(/\bsin\(/g, 'mathScope.sin(');
      parsed = parsed.replace(/\bcos\(/g, 'mathScope.cos(');
      parsed = parsed.replace(/\btan\(/g, 'mathScope.tan(');
      parsed = parsed.replace(/\basin\(/g, 'mathScope.asin(');
      parsed = parsed.replace(/\bacos\(/g, 'mathScope.acos(');
      parsed = parsed.replace(/\batan\(/g, 'mathScope.atan(');
      parsed = parsed.replace(/\bsqrt\(/g, 'mathScope.sqrt(');
      parsed = parsed.replace(/\bcbrt\(/g, 'mathScope.cbrt(');
      parsed = parsed.replace(/\blog\(/g, 'mathScope.log(');
      parsed = parsed.replace(/\bln\(/g, 'mathScope.ln(');
      parsed = parsed.replace(/\bexp\(/g, 'mathScope.exp(');
      parsed = parsed.replace(/\bfact\(/g, 'mathScope.fact(');
      parsed = parsed.replace(/\bMath\.PI\b/g, 'mathScope.PI');

      // Chuyển đổi lũy thừa a^b
      while (parsed.includes('^')) {
        parsed = parsed.replace(/([0-9.]+|\([^\(\)]+\))\^([0-9.]+|\([^\(\)]+\))/g, 'Math.pow($1, $2)');
      }

      // Đánh giá biểu thức qua hàm Function an toàn với scope giới hạn
      const func = new Function('mathScope', `return (${parsed});`);
      return func(mathScope);
    },

    // Chuyển đổi Số thập phân <-> Phân số (nút S<=>D kinh điển của Casio)
    toggleFraction: function() {
      if (!this.currentFraction) return;
      this.isShowingFraction = !this.isShowingFraction;
      if (this.isShowingFraction && this.currentFraction.denom !== 1) {
        this.result = `${this.currentFraction.num} / ${this.currentFraction.denom}`;
      } else {
        this.result = this.formatNumber(this.lastAns);
      }
      this.updateDisplay();
    },

    // Tìm phân số tối giản từ số thực
    toFraction: function(val, maxDenom = 10000) {
      if (isNaN(val) || !isFinite(val)) return null;
      const sign = val < 0 ? -1 : 1;
      val = Math.abs(val);

      if (Number.isInteger(val)) return { num: sign * val, denom: 1 };

      let bestNumerator = 1;
      let bestDenominator = 1;
      let minError = Math.abs(val - bestNumerator / bestDenominator);

      for (let d = 1; d <= maxDenom; d++) {
        const n = Math.round(val * d);
        const error = Math.abs(val - n / d);
        if (error < minError) {
          bestNumerator = n;
          bestDenominator = d;
          minError = error;
          if (error < 1e-7) break;
        }
      }

      if (minError < 1e-4 && bestDenominator <= maxDenom) {
        return { num: sign * bestNumerator, denom: bestDenominator };
      }
      return null;
    },

    // Định dạng số hiển thị gọn gàng
    formatNumber: function(num) {
      if (isNaN(num)) return 'ERROR';
      if (!isFinite(num)) return num > 0 ? '+Infinity' : '-Infinity';
      if (Math.abs(num) >= 1e11 || (Math.abs(num) > 0 && Math.abs(num) < 1e-7)) {
        return num.toExponential(6).replace('e+', ' × 10^').replace('e-', ' × 10^-');
      }
      // Giới hạn tối đa 10 chữ số thập phân, bỏ số 0 thừa
      return parseFloat(num.toFixed(8)).toString();
    },

    // Cập nhật màn hình LCD
    updateDisplay: function() {
      const exprEl = document.getElementById('casio-expr-display');
      const resEl = document.getElementById('casio-res-display');
      const angleIndicator = document.getElementById('casio-ind-angle');

      if (exprEl) {
        exprEl.textContent = this.expression || ' ';
        // Cuộn tự động về cuối biểu thức
        exprEl.scrollLeft = exprEl.scrollWidth;
      }
      if (resEl) {
        resEl.textContent = this.result;
      }
      if (angleIndicator) {
        angleIndicator.textContent = this.angleMode;
      }

      this.updateIndicators();
    },

    // Cập nhật các đèn báo SHIFT, ALPHA, M
    updateIndicators: function() {
      const shiftInd = document.getElementById('casio-ind-shift');
      const alphaInd = document.getElementById('casio-ind-alpha');
      const mInd = document.getElementById('casio-ind-m');

      if (shiftInd) {
        shiftInd.className = this.isShift ? 'font-black text-amber-300' : 'text-slate-600';
      }
      if (alphaInd) {
        alphaInd.className = this.isAlpha ? 'font-black text-rose-400' : 'text-slate-600';
      }
      if (mInd) {
        mInd.className = this.memory !== 0 ? 'font-black text-emerald-400' : 'text-slate-600';
      }
    },

    // Bộ giải Phương trình Bậc 2: ax² + bx + c = 0
    solveQuadratic: function() {
      const a = parseFloat(document.getElementById('casio-eqn-a')?.value || 0);
      const b = parseFloat(document.getElementById('casio-eqn-b')?.value || 0);
      const c = parseFloat(document.getElementById('casio-eqn-c')?.value || 0);
      const out = document.getElementById('casio-eqn-result');
      if (!out) return;

      if (isNaN(a) || isNaN(b) || isNaN(c)) {
        out.innerHTML = '<span class="text-rose-400">Vui lòng nhập đầy đủ hệ số a, b, c hợp lệ.</span>';
        return;
      }

      if (a === 0) {
        if (b === 0) {
          out.innerHTML = c === 0 ? 'Phương trình vô số nghiệm (0 = 0).' : 'Phương trình vô nghiệm.';
        } else {
          const x = -c / b;
          out.innerHTML = `Phương trình bậc nhất: <b>x = ${Casio570.formatNumber(x)}</b>`;
        }
        return;
      }

      const delta = b * b - 4 * a * c;
      const xv = -b / (2 * a);
      const yv = -delta / (4 * a);

      let html = `<div class="space-y-1.5 text-xs font-mono">`;
      html += `<div>Δ = b² - 4ac = <b>${Casio570.formatNumber(delta)}</b></div>`;

      if (delta > 0) {
        const x1 = (-b + Math.sqrt(delta)) / (2 * a);
        const x2 = (-b - Math.sqrt(delta)) / (2 * a);
        html += `<div class="text-emerald-300 font-bold">x₁ = ${Casio570.formatNumber(x1)}</div>`;
        html += `<div class="text-emerald-300 font-bold">x₂ = ${Casio570.formatNumber(x2)}</div>`;
      } else if (delta === 0) {
        html += `<div class="text-emerald-300 font-bold">Nghiệm kép: x₁ = x₂ = ${Casio570.formatNumber(xv)}</div>`;
      } else {
        const real = xv;
        const imag = Math.sqrt(-delta) / (2 * Math.abs(a));
        html += `<div class="text-amber-300">Nghiệm phức:</div>`;
        html += `<div>x₁ = ${Casio570.formatNumber(real)} + ${Casio570.formatNumber(imag)}i</div>`;
        html += `<div>x₂ = ${Casio570.formatNumber(real)} - ${Casio570.formatNumber(imag)}i</div>`;
      }

      html += `<div class="text-slate-400 pt-1 border-t border-slate-700/60">Đỉnh parabol: (${Casio570.formatNumber(xv)}; ${Casio570.formatNumber(yv)})</div>`;
      html += `</div>`;
      out.innerHTML = html;
    },

    // Bộ giải Hệ 2 phương trình bậc nhất 2 ẩn
    solveLinearSystem2: function() {
      const a1 = parseFloat(document.getElementById('casio-sys-a1')?.value || 0);
      const b1 = parseFloat(document.getElementById('casio-sys-b1')?.value || 0);
      const c1 = parseFloat(document.getElementById('casio-sys-c1')?.value || 0);
      const a2 = parseFloat(document.getElementById('casio-sys-a2')?.value || 0);
      const b2 = parseFloat(document.getElementById('casio-sys-b2')?.value || 0);
      const c2 = parseFloat(document.getElementById('casio-sys-c2')?.value || 0);
      const out = document.getElementById('casio-sys-result');
      if (!out) return;

      const D = a1 * b2 - a2 * b1;
      const Dx = c1 * b2 - c2 * b1;
      const Dy = a1 * c2 - a2 * c1;

      if (D === 0) {
        if (Dx === 0 && Dy === 0) {
          out.innerHTML = '<span class="text-amber-300">Hệ phương trình có vô số nghiệm.</span>';
        } else {
          out.innerHTML = '<span class="text-rose-400">Hệ phương trình vô nghiệm.</span>';
        }
      } else {
        const x = Dx / D;
        const y = Dy / D;
        out.innerHTML = `
          <div class="space-y-1 font-mono text-emerald-300 text-xs">
            <div>D = ${Casio570.formatNumber(D)}</div>
            <div class="text-sm font-bold">x = ${Casio570.formatNumber(x)}</div>
            <div class="text-sm font-bold">y = ${Casio570.formatNumber(y)}</div>
          </div>
        `;
      }
    },

    // Lắng nghe bàn phím máy tính để nhập nhanh
    bindKeyboard: function() {
      document.addEventListener('keydown', e => {
        // Phím tắt Alt + C để mở nhanh Casio
        if (e.altKey && (e.key === 'c' || e.key === 'C')) {
          e.preventDefault();
          this.toggle();
          return;
        }

        if (!this.isOpen || this.isMinimized) return;

        // Nếu người dùng đang gõ vào input trường đề thi thì không bắt sự kiện này
        const activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
        if (activeTag === 'input' && !document.activeElement.classList.contains('casio-input')) return;

        if (e.key >= '0' && e.key <= '9') {
          this.input(e.key);
        } else if (e.key === '.') {
          this.input('.');
        } else if (e.key === '+') {
          this.input(' + ', '+');
        } else if (e.key === '-') {
          this.input(' - ', '-');
        } else if (e.key === '*') {
          this.input(' × ', '*');
        } else if (e.key === '/') {
          e.preventDefault();
          this.input(' ÷ ', '/');
        } else if (e.key === '(' || e.key === ')') {
          this.input(e.key);
        } else if (e.key === 'Enter' || e.key === '=') {
          e.preventDefault();
          this.calculate();
        } else if (e.key === 'Backspace') {
          this.del();
        } else if (e.key === 'Escape') {
          this.ac();
        }
      });
    },

    // Tính năng Kéo Thả (Drag & Drop) di chuyển máy tính trên màn hình
    makeDraggable: function() {
      const widget = document.getElementById('casio-widget');
      const header = document.getElementById('casio-header');
      if (!widget || !header) return;

      let isDragging = false;
      let startX, startY, initialLeft, initialTop;

      header.addEventListener('mousedown', e => {
        if (e.target.tagName.toLowerCase() === 'button' || e.target.closest('button')) return;
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        
        const rect = widget.getBoundingClientRect();
        initialLeft = rect.left;
        initialTop = rect.top;

        widget.style.right = 'auto';
        widget.style.bottom = 'auto';
        widget.style.left = `${initialLeft}px`;
        widget.style.top = `${initialTop}px`;
        header.style.cursor = 'grabbing';
      });

      document.addEventListener('mousemove', e => {
        if (!isDragging) return;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;

        let newLeft = initialLeft + dx;
        let newTop = initialTop + dy;

        // Giới hạn trong khung nhìn
        const maxLeft = window.innerWidth - widget.offsetWidth;
        const maxTop = window.innerHeight - widget.offsetHeight;

        newLeft = Math.max(10, Math.min(newLeft, maxLeft - 10));
        newTop = Math.max(10, Math.min(newTop, maxTop - 10));

        widget.style.left = `${newLeft}px`;
        widget.style.top = `${newTop}px`;
      });

      document.addEventListener('mouseup', () => {
        if (isDragging) {
          isDragging = false;
          header.style.cursor = 'grab';
        }
      });
    },

    render: function() {
      this.updateDisplay();
    }
  };

  window.Casio570 = Casio570;
  document.addEventListener("DOMContentLoaded", () => {
    Casio570.init();
  });
})();
