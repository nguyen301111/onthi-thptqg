// =========================================================================
// NGÂN HÀNG KHUÔN MẪU ĐỀ THI TỐT NGHIỆP THPT CHUẨN BỘ GIÁO DỤC 2025 - 2026
// Hỗ trợ 3 môn: TOÁN HỌC (22 câu), VẬT LÍ (28 câu), HÓA HỌC (28 câu)
// Toàn bộ công thức đều bọc dấu $ cho KaTeX.
// Mỗi câu hỏi gồm:
// - content: Đề bài tham số hóa đổi số tự động
// - options/statements/correctAnswer: Đáp án chuẩn
// - theory: Cơ sở lý thuyết & Công thức trọng tâm từ SGK 2025/2026
// - explanation: Các bước giải chi tiết từng bước
// - tips: Mẹo bấm máy tính Casio fx-570 & Bẫy thường gặp
// =========================================================================

window.EXAM_TEMPLATES = {
  // =======================================================================
  // 1. MÔN TOÁN HỌC (90 PHÚT - 22 CÂU HỎI - THANG ĐIỂM 10.0)
  // Phần I: 12 câu (3.0đ) | Phần II: 4 câu (4.0đ) | Phần III: 6 câu (3.0đ)
  // =======================================================================
  toan: {
    duration: 90,
    part1_count: 12,
    part2_count: 4,
    part3_count: 6,
    templates_part1: [
      {
        id: "m_p1_01",
        topic: "Khảo sát hàm số - Tính đơn điệu",
        generate: () => {
          const k = [1, 2, 3][Math.floor(Math.random() * 3)];
          const b = [2, 3, 4][Math.floor(Math.random() * 3)];
          const bSqr = b * b;
          return {
            content: `Cho hàm số $y = \\frac{${k > 1 ? k : ''}}{3}x^3 - ${k * bSqr}x + 5$. Hàm số đã cho đồng biến trên khoảng nào dưới đây?`,
            options: [`$(${b}; +\\infty)$`, `$(-${b}; ${b})$`, `$(-\\infty; ${b})$`, `$(-${b}; +\\infty)$`],
            correctIndex: 0,
            theory: `Định lý đơn điệu: Cho hàm số $y = f(x)$ có đạo hàm trên $K$. Nếu $f'(x) > 0, \\forall x \\in K$ thì hàm số đồng biến trên $K$.`,
            explanation: `Ta có đạo hàm $y' = ${k}x^2 - ${k * bSqr} = ${k}(x^2 - ${bSqr})$. Xét $y' > 0 \\Leftrightarrow x^2 > ${bSqr} \\Leftrightarrow x > ${b}$ hoặc $x < -${b}$. Do đó hàm số đồng biến trên các khoảng $(-\\infty; -${b})$ và $(${b}; +\\infty)$.`,
            tips: `Dùng Casio fx-570: Bấm MODE 7 (TABLE), nhập $f(X) = \\frac{${k}}{3}X^3 - ${k * bSqr}X + 5$, chọn Start: ${b}, End: ${b + 4}, Step: 0.5. Quan sát thấy cột $f(X)$ tăng liên tục $\\Rightarrow$ Đồng biến.`
          };
        }
      },
      {
        id: "m_p1_02",
        topic: "Đường tiệm cận của đồ thị hàm số",
        generate: () => {
          const a = [2, 3, 4, 5][Math.floor(Math.random() * 4)];
          const b = [1, 2, 3][Math.floor(Math.random() * 3)];
          const c = [1, 2, 4][Math.floor(Math.random() * 3)];
          return {
            content: `Tiệm cận ngang của đồ thị hàm số $y = \\frac{${a}x - ${b}}{x + ${c}}$ có phương trình là:`,
            options: [`$y = ${a}$`, `$x = -${c}$`, `$y = -${b}$`, `$x = ${a}$`],
            correctIndex: 0,
            theory: `Đường thẳng $y = y_0$ là tiệm cận ngang của đồ thị hàm số $y = f(x)$ nếu $\\lim_{x \\to +\\infty} f(x) = y_0$ hoặc $\\lim_{x \\to -\\infty} f(x) = y_0$. Với hàm $y = \\frac{ax+b}{cx+d}$, tiệm cận ngang là $y = \\frac{a}{c}$.`,
            explanation: `Ta có $\\lim_{x \\to \\pm\\infty} \\frac{${a}x - ${b}}{x + ${c}} = \\lim_{x \\to \\pm\\infty} \\frac{${a} - ${b}/x}{1 + ${c}/x} = ${a}$. Vậy tiệm cận ngang là đường thẳng $y = ${a}$.`,
            tips: `Mẹo Casio: Nhập biểu thức $\\frac{${a}x - ${b}}{x + ${c}}$, bấm CALC $X = 10^8$. Kết quả hiện xấp xỉ ${a} $\\Rightarrow$ Tiệm cận ngang $y = ${a}$. Chú ý phân biệt với tiệm cận đứng $x = -${c}$.`
          };
        }
      },
      {
        id: "m_p1_03",
        topic: "Tọa độ vectơ trong không gian Oxyz",
        generate: () => {
          const x = Math.floor(Math.random() * 4) + 1;
          const y = Math.floor(Math.random() * 4) - 2;
          const z = Math.floor(Math.random() * 4) + 1;
          const lenSq = x * x + y * y + z * z;
          return {
            content: `Trong không gian $Oxyz$, cho vectơ $\\vec{u} = (${x}; ${y}; ${z})$. Độ dài của vectơ $\\vec{u}$ bằng:`,
            options: [`$\\sqrt{${lenSq}}$`, `$${lenSq}$`, `$${x + y + z}$`, `$\\sqrt{${lenSq + 2}}$`],
            correctIndex: 0,
            theory: `Độ dài vectơ trong không gian: Với $\\vec{u} = (x; y; z)$, độ dài $|\\vec{u}| = \\sqrt{x^2 + y^2 + z^2}$.`,
            explanation: `Độ dài vectơ $|\\vec{u}| = \\sqrt{(${x})^2 + (${y})^2 + (${z})^2} = \\sqrt{${x * x} + ${y * y} + ${z * z}} = \\sqrt{${lenSq}}$.`,
            tips: `Trên Casio fx-570: Bấm MODE 8 (VECTOR) $\\rightarrow$ Nhập VctA = [${x}, ${y}, ${z}] $\\rightarrow$ Bấm SHIFT 5 (VECTOR) chọn 7 (Abs) và VctA $\\Rightarrow$ Hiện ngay kết quả.`
          };
        }
      },
      {
        id: "m_p1_04",
        topic: "Khối đa diện - Thể tích khối lăng trụ",
        generate: () => {
          const B = [6, 8, 12, 15][Math.floor(Math.random() * 4)];
          const h = [3, 4, 5][Math.floor(Math.random() * 3)];
          const V = B * h;
          return {
            content: `Cho khối lăng trụ có diện tích đáy $B = ${B}\\text{ cm}^2$ và chiều cao $h = ${h}\\text{ cm}$. Thể tích của khối lăng trụ đã cho là:`,
            options: [`$${V}\\text{ cm}^3$`, `$${Math.round(V / 3)}\\text{ cm}^3$`, `$${V * 2}\\text{ cm}^3$`, `$${V + 3}\\text{ cm}^3$`],
            correctIndex: 0,
            theory: `Thể tích khối lăng trụ: $V = B \\cdot h$ (diện tích đáy nhân chiều cao). Lưu ý khối chóp mới có hệ số $\\frac{1}{3}$.`,
            explanation: `Áp dụng công thức thể tích khối lăng trụ: $V = B \\cdot h = ${B} \\cdot ${h} = ${V}\\text{ cm}^3$.`,
            tips: `Bẫy kinh điển: Rất nhiều học sinh nhầm giữa lăng trụ ($V = B \\cdot h$) và hình chóp ($V = \\frac{1}{3}B \\cdot h$). Luôn gạch chân từ 'khối lăng trụ'.`
          };
        }
      },
      {
        id: "m_p1_05",
        topic: "Cực trị của hàm số",
        generate: () => {
          const a = [1, 2][Math.floor(Math.random() * 2)];
          const b = [2, 4][Math.floor(Math.random() * 2)];
          return {
            content: `Hàm số $y = ${a > 1 ? a : ''}x^4 - ${2 * a * b}x^2 + 1$ có bao nhiêu điểm cực trị?`,
            options: [`$3$ điểm cực trị`, `$1$ điểm cực trị`, `$2$ điểm cực trị`, `$0$ điểm cực trị`],
            correctIndex: 0,
            theory: `Hàm số trùng phương $y = ax^4 + bx^2 + c$ ($a \\neq 0$) có 3 điểm cực trị khi $a \\cdot b < 0$; có 1 điểm cực trị khi $a \\cdot b \\ge 0$.`,
            explanation: `Ta có $a = ${a} > 0$ và $b = -${2 * a * b} < 0 \\Rightarrow a \\cdot b < 0$. Do đó hàm số có đúng $3$ điểm cực trị (1 cực tiểu tại $x = 0$ và 2 cực đại tại $x = \\pm\\sqrt{${b}}$).`,
            tips: `Nhớ nhanh dấu hiệu hàm bậc bốn trùng phương: tích $a \\cdot b < 0 \\Rightarrow 3$ cực trị; $a \\cdot b \\ge 0 \\Rightarrow 1$ cực trị.`
          };
        }
      },
      {
        id: "m_p1_06",
        topic: "Giá trị lớn nhất và nhỏ nhất của hàm số",
        generate: () => {
          const m = [2, 3, 5][Math.floor(Math.random() * 3)];
          return {
            content: `Giá trị nhỏ nhất của hàm số $f(x) = x + \\frac{${m * m}}{x}$ trên đoạn $[1; ${m + 2}]$ bằng:`,
            options: [`$${2 * m}$`, `$${m * m + 1}$`, `$${m + 2}$`, `$${2 * m + 1}$`],
            correctIndex: 0,
            theory: `Bất đẳng thức Cauchy (AM-GM): Với hai số dương $a, b > 0$, ta có $a + b \\ge 2\\sqrt{ab}$. Dấu bằng xảy ra khi $a = b$.`,
            explanation: `Với $x \\in [1; ${m + 2}]$, ta có $x > 0$. Áp dụng BĐT Cauchy: $x + \\frac{${m * m}}{x} \\ge 2\\sqrt{x \\cdot \\frac{${m * m}}{x}} = 2\\sqrt{${m * m}} = ${2 * m}$. Dấu bằng xảy ra khi $x = \\frac{${m * m}}{x} \\Leftrightarrow x = ${m} \\in [1; ${m + 2}]$. Vậy $\\min = ${2 * m}$.`,
            tips: `Bấm Casio 570: MODE 7 nhập $f(X) = X + ${m * m}/X$, Start: 1, End: ${m + 2}, Step: 0.5. Cột $F(X)$ có giá trị nhỏ nhất là ${2 * m} tại $X = ${m}$.`
          };
        }
      },
      {
        id: "m_p1_07",
        topic: "Nguyên hàm cơ bản",
        generate: () => {
          const a = [3, 4, 5][Math.floor(Math.random() * 3)];
          return {
            content: `Họ nguyên hàm của hàm số $f(x) = e^{${a}x} + 2x$ là:`,
            options: [`$\\frac{1}{${a}}e^{${a}x} + x^2 + C$`, `$${a}e^{${a}x} + x^2 + C$`, `$\\frac{1}{${a}}e^{${a}x} + 2 + C$`, `$e^{${a}x} + x^2 + C$`],
            correctIndex: 0,
            theory: `Công thức nguyên hàm hàm số hợp: $\\int e^{ax+b} dx = \\frac{1}{a}e^{ax+b} + C$ và $\\int x^n dx = \\frac{x^{n+1}}{n+1} + C$.`,
            explanation: `Ta có $\\int (e^{${a}x} + 2x) dx = \\int e^{${a}x} dx + 2\\int x dx = \\frac{1}{${a}}e^{${a}x} + x^2 + C$.`,
            tips: `Kiểm tra đáp án bằng Casio: Bấm $\\frac{d}{dx}(\\text{Đáp án})|_{x=2} - f(2)$. Nếu kết quả bằng 0 thì đáp án đó chính xác.`
          };
        }
      },
      {
        id: "m_p1_08",
        topic: "Tích phân cơ bản",
        generate: () => {
          const a = [1, 2][Math.floor(Math.random() * 2)];
          const b = [3, 4][Math.floor(Math.random() * 2)];
          const I = (b * b * b - a * a * a);
          return {
            content: `Tích phân $I = \\int_{${a}}^{${b}} 3x^2 dx$ có giá trị bằng:`,
            options: [`$${I}$`, `$${I - 2}$`, `$${Math.round(I / 3)}$`, `$${I + 4}$`],
            correctIndex: 0,
            theory: `Định nghĩa tích phân Newton-Leibniz: $\\int_a^b f(x) dx = F(b) - F(a)$, trong đó $F'(x) = f(x)$.`,
            explanation: `Nguyên hàm của $3x^2$ là $x^3$. Ta có $I = [x^3]_{${a}}^{${b}} = (${b})^3 - (${a})^3 = ${b * b * b} - ${a * a * a} = ${I}$.`,
            tips: `Bấm trực tiếp trên Casio fx-570: Phím $\\int dx$, nhập $3X^2$, cận dưới ${a}$, cận trên ${b} $\\Rightarrow$ Ra ngay ${I}.`
          };
        }
      },
      {
        id: "m_p1_09",
        topic: "Mặt cầu trong không gian Oxyz",
        generate: () => {
          const a = Math.floor(Math.random() * 3) + 1;
          const b = -(Math.floor(Math.random() * 3) + 1);
          const c = Math.floor(Math.random() * 3) + 2;
          const R = [3, 4, 5][Math.floor(Math.random() * 3)];
          const Rsq = R * R;
          return {
            content: `Trong không gian $Oxyz$, mặt cầu $(S): (x - ${a})^2 + (y + ${-b})^2 + (z - ${c})^2 = ${Rsq}$ có bán kính $R$ bằng:`,
            options: [`$${R}$`, `$${Rsq}$`, `$${2 * R}$`, `$\\sqrt{${R}}$`],
            correctIndex: 0,
            theory: `Phương trình mặt cầu chính tắc: $(x - a)^2 + (y - b)^2 + (z - c)^2 = R^2$ có tâm $I(a; b; c)$ và bán kính $R = \\sqrt{R^2}$.`,
            explanation: `Từ phương trình $(S)$, ta có $R^2 = ${Rsq} \\Rightarrow R = \\sqrt{${Rsq}} = ${R}$.`,
            tips: `Bẫy thường gặp: Học sinh hay nhầm vế phải là bán kính $R$ thay vì $R^2$. Luôn nhớ lấy căn bậc hai của số ở vế phải.`
          };
        }
      },
      {
        id: "m_p1_10",
        topic: "Mặt phẳng trong không gian Oxyz",
        generate: () => {
          const a = [2, 3][Math.floor(Math.random() * 2)];
          const b = [-1, -2][Math.floor(Math.random() * 2)];
          const c = [4, 5][Math.floor(Math.random() * 2)];
          return {
            content: `Trong không gian $Oxyz$, một vectơ pháp tuyến của mặt phẳng $(P): ${a}x + (${b})y + ${c}z - 7 = 0$ là:`,
            options: [`$\\vec{n} = (${a}; ${b}; ${c})$`, `$\\vec{n} = (${a}; ${-b}; ${c})$`, `$\\vec{n} = (${c}; ${b}; ${a})$`, `$\\vec{n} = (${a}; ${b}; -7)$`],
            correctIndex: 0,
            theory: `Mặt phẳng $(P): Ax + By + Cz + D = 0$ có một vectơ pháp tuyến là $\\vec{n} = (A; B; C)$.`,
            explanation: `Hệ số trước $x, y, z$ lần lượt là $A = ${a}, B = ${b}, C = ${c}$. Do đó $\\vec{n} = (${a}; ${b}; ${c})$ là một VTPT của $(P)$.`,
            tips: `Hệ số tự do $D = -7$ không nằm trong tọa độ vectơ pháp tuyến. VTPT chỉ gồm các hệ số đứng ngay trước $x, y, z$.`
          };
        }
      },
      {
        id: "m_p1_11",
        topic: "Phương trình đường thẳng Oxyz",
        generate: () => {
          const x0 = 1, y0 = -2, z0 = 3;
          const u1 = 2, u2 = -1, u3 = 4;
          return {
            content: `Đường thẳng $d$ đi qua điểm $M(1; -2; 3)$ và có VTCP $\\vec{u} = (2; -1; 4)$ có phương trình chính tắc là:`,
            options: [
              `$\\frac{x - 1}{2} = \\frac{y + 2}{-1} = \\frac{z - 3}{4}$`,
              `$\\frac{x + 1}{2} = \\frac{y - 2}{-1} = \\frac{z + 3}{4}$`,
              `$\\frac{x - 2}{1} = \\frac{y + 1}{-2} = \\frac{z - 4}{3}$`,
              `$\\frac{x - 1}{2} = \\frac{y - 2}{-1} = \\frac{z - 3}{4}$`
            ],
            correctIndex: 0,
            theory: `Đường thẳng đi qua $M(x_0; y_0; z_0)$ có VTCP $\\vec{u} = (a; b; c)$ có PT chính tắc: $\\frac{x - x_0}{a} = \\frac{y - y_0}{b} = \\frac{z - z_0}{c}$.`,
            explanation: `Thay tọa độ điểm $M(1; -2; 3)$ và VTCP $\\vec{u} = (2; -1; 4)$ vào công thức: $\\frac{x - 1}{2} = \\frac{y - (-2)}{-1} = \\frac{z - 3}{4} \\Leftrightarrow \\frac{x - 1}{2} = \\frac{y + 2}{-1} = \\frac{z - 3}{4}$.`,
            tips: `Cẩn thận dấu: trên tử số là dấu trừ $(x - x_0)$. Khi $y_0 = -2$, ta có $y - (-2) = y + 2$.`
          };
        }
      },
      {
        id: "m_p1_12",
        topic: "Xác suất có điều kiện (Chuẩn BGD 2025)",
        generate: () => {
          const pA = 0.6;
          const pB = 0.5;
          const pAB = 0.3;
          const pBgivenA = (pAB / pA).toFixed(2);
          return {
            content: `Cho hai biến cố $A$ và $B$ có $P(A) = 0{,}6$; $P(B) = 0{,}5$ và $P(A \\cap B) = 0{,}3$. Xác suất có điều kiện $P(B|A)$ bằng:`,
            options: [`$0{,}50$`, `$0{,}60$`, `$0{,}30$`, `$0{,}18$`],
            correctIndex: 0,
            theory: `Công thức xác suất có điều kiện (BGD 2025): $P(B|A) = \\frac{P(A \\cap B)}{P(A)}$ với $P(A) > 0$.`,
            explanation: `Áp dụng công thức: $P(B|A) = \\frac{P(A \\cap B)}{P(A)} = \\frac{0{,}3}{0{,}6} = 0{,}50$.`,
            tips: `Công thức xác suất có điều kiện là nội dung trọng tâm mới trong chương trình THPT 2025. Nhớ mẫu số là xác suất của biến cố đã xảy ra (sau dấu gạch |).`
          };
        }
      }
    ],

    templates_part2: [
      {
        id: "m_p2_01",
        topic: "Khảo sát sự biến thiên và vẽ đồ thị hàm số",
        generate: () => {
          const a = 1;
          const b = 3;
          return {
            content: `Cho hàm số $y = x^3 - 3x^2 + 2$ có đồ thị là $(C)$. Xét tính đúng/sai của các mệnh đề sau:`,
            statements: [
              { label: "a", text: "Hàm số đồng biến trên khoảng $(2; +\\infty)$.", isCorrect: true, exp: "$y' = 3x^2 - 6x = 3x(x - 2) > 0$ khi $x > 2$ hoặc $x < 0$. Do đó hàm số đồng biến trên $(2; +\\infty)$ là ĐÚNG." },
              { label: "b", text: "Điểm cực tiểu của đồ thị hàm số có tọa độ là $(2; -2)$.", isCorrect: true, exp: "Tại $x = 2$, $y = 2^3 - 3(2)^2 + 2 = -2$. Đạo hàm đổi dấu từ âm sang dương $\\Rightarrow$ Điểm cực tiểu $(2; -2)$ là ĐÚNG." },
              { label: "c", text: "Đồ thị hàm số có tâm đối xứng là gốc tọa độ $O(0; 0)$.", isCorrect: false, exp: "Điểm uốn (tâm đối xứng) thỏa mãn $y'' = 6x - 6 = 0 \\Leftrightarrow x = 1 \\Rightarrow y = 0$. Tâm đối xứng là $(1; 0)$, không phải $(0; 0)$." },
              { label: "d", text: "Đường thẳng tiếp tuyến của $(C)$ tại điểm có hoành độ $x = 0$ có hệ số góc bằng $0$.", isCorrect: true, exp: "Hệ số góc tiếp tuyến là $k = y'(0) = 3(0)^2 - 6(0) = 0$. Mệnh đề này là ĐÚNG." }
            ],
            theory: `Quy tắc khảo sát hàm đa thức bậc ba: Đạo hàm cấp 1 tìm cực trị và tính đơn điệu; Đạo hàm cấp 2 tìm điểm uốn (tâm đối xứng); Hệ số góc tiếp tuyến $k = y'(x_0)$.`,
            tips: `Dùng Casio fx-570: MODE 5 chọn 4 (phương trình bậc 3) nhập $1, -3, 0, 2$. Máy sẽ hiển thị nghiệm, tọa độ điểm cực đại $(0; 2)$ và điểm cực tiểu $(2; -2)$.`
          };
        }
      },
      {
        id: "m_p2_02",
        topic: "Ứng dụng hình học của tích phân",
        generate: () => {
          return {
            content: `Cho hình phẳng $(H)$ giới hạn bởi parabol $(P): y = 4 - x^2$ và trục hoành $Ox$. Xét tính đúng/sai của các mệnh đề sau:`,
            statements: [
              { label: "a", text: "Giao điểm của parabol $(P)$ với trục hoành là $A(-2; 0)$ và $B(2; 0)$.", isCorrect: true, exp: "Phương trình hoành độ giao điểm $4 - x^2 = 0 \\Leftrightarrow x = \\pm 2$. Mệnh đề ĐÚNG." },
              { label: "b", text: "Diện tích hình phẳng $(H)$ được tính bởi công thức $S = \\int_{-2}^2 (4 - x^2) dx$.", isCorrect: true, exp: "Trên $[-2; 2]$, $4 - x^2 \\ge 0$ nên $S = \\int_{-2}^2 |4 - x^2| dx = \\int_{-2}^2 (4 - x^2) dx$. Mệnh đề ĐÚNG." },
              { label: "c", text: "Diện tích của hình phẳng $(H)$ bằng $\\frac{32}{3}$.", isCorrect: true, exp: "$S = [4x - \\frac{x^3}{3}]_{-2}^2 = (8 - \\frac{8}{3}) - (-8 + \\frac{8}{3}) = \\frac{16}{3} + \\frac{16}{3} = \\frac{32}{3}$. Mệnh đề ĐÚNG." },
              { label: "d", text: "Thể tích khối tròn xoay khi quay $(H)$ quanh trục $Ox$ bằng $\\frac{512}{15}$.", isCorrect: false, exp: "Thể tích khối tròn xoay là $V = \\pi \\int_{-2}^2 (4 - x^2)^2 dx = \\frac{512\\pi}{15}$ (thiếu hằng số $\\pi$ nên mệnh đề là SAI)." }
            ],
            theory: `Công thức diện tích: $S = \\int_a^b |f(x)| dx$. Thể tích tròn xoay quanh trục $Ox$: $V = \\pi \\int_a^b [f(x)]^2 dx$. Lưu ý công thức thể tích luôn có thừa số $\\pi$.`,
            tips: `Bẫy câu d: Đề bài cố tình bỏ quên $\\pi$. Thể tích khối tròn xoay luôn có đơn vị chứa $\\pi$, nếu không có $\\pi$ là sai.`
          };
        }
      },
      {
        id: "m_p2_03",
        topic: "Hình học giải tích không gian Oxyz",
        generate: () => {
          return {
            content: `Trong không gian $Oxyz$, cho mặt phẳng $(P): x + 2y - 2z + 5 = 0$ và điểm $A(1; 1; 2)$. Xét tính đúng/sai của các mệnh đề sau:`,
            statements: [
              { label: "a", text: "Điểm $A(1; 1; 2)$ thuộc mặt phẳng $(P)$.", isCorrect: false, exp: "Thay tọa độ $A$ vào $(P)$: $1 + 2(1) - 2(2) + 5 = 1 + 2 - 4 + 5 = 4 \\neq 0$. Vậy $A \\notin (P)$. Mệnh đề SAI." },
              { label: "b", text: "Vectơ $\\vec{n} = (1; 2; -2)$ là một vectơ pháp tuyến của mặt phẳng $(P)$.", isCorrect: true, exp: "Hệ số trước $x, y, z$ lần lượt là $1, 2, -2$. Mệnh đề ĐÚNG." },
              { label: "c", text: "Khoảng cách từ điểm $A$ đến mặt phẳng $(P)$ bằng $\\frac{4}{3}$.", isCorrect: true, exp: "$d(A, P) = \\frac{|1 + 2(1) - 2(2) + 5|}{\\sqrt{1^2 + 2^2 + (-2)^2}} = \\frac{4}{\\sqrt{9}} = \\frac{4}{3}$. Mệnh đề ĐÚNG." },
              { label: "d", text: "Mặt phẳng $(Q)$ đi qua $A$ và song song với $(P)$ có phương trình $x + 2y - 2z + 1 = 0$.", isCorrect: true, exp: "$(Q)$ song song $(P)$ nên có dạng $x + 2y - 2z + D = 0$. Qua $A(1; 1; 2) \\Rightarrow 1 + 2 - 4 + D = 0 \\Rightarrow D = 1$. Mệnh đề ĐÚNG." }
            ],
            theory: `Khoảng cách từ điểm $M(x_0; y_0; z_0)$ đến mặt phẳng $(P): Ax + By + Cz + D = 0$ là $d(M, P) = \\frac{|Ax_0 + By_0 + Cz_0 + D|}{\\sqrt{A^2 + B^2 + C^2}}$.`,
            tips: `Kiểm tra khoảng cách trên Casio: Nhập biểu thức $(X + 2Y - 2Z + 5) / \\sqrt{1 + 4 + 4}$, bấm CALC nhập $X = 1, Y = 1, Z = 2 \\Rightarrow$ Kết quả $\\frac{4}{3}$.`
          };
        }
      },
      {
        id: "m_p2_04",
        topic: "Xác suất & Biến cố độc lập (BGD 2025)",
        generate: () => {
          return {
            content: `Hai xạ thủ $X$ và $Y$ cùng bắn mỗi người một viên đạn vào bia một cách độc lập. Xác suất bắn trúng của $X$ là $0{,}8$; của $Y$ là $0{,}7$. Xét tính đúng/sai của các mệnh đề sau:`,
            statements: [
              { label: "a", text: "Xác suất để cả hai xạ thủ cùng bắn trượt là $0{,}06$.", isCorrect: true, exp: "$P(\\bar{X} \\cap \\bar{Y}) = (1 - 0{,}8) \\times (1 - 0{,}7) = 0{,}2 \\times 0{,}3 = 0{,}06$. Mệnh đề ĐÚNG." },
              { label: "b", text: "Xác suất để cả hai xạ thủ cùng bắn trúng là $0{,}56$.", isCorrect: true, exp: "$P(X \\cap Y) = 0{,}8 \\times 0{,}7 = 0{,}56$. Mệnh đề ĐÚNG." },
              { label: "c", text: "Xác suất để có đúng một xạ thủ bắn trúng bia là $0{,}38$.", isCorrect: true, exp: "$P = 0{,}8 \\times 0{,}3 + 0{,}2 \\times 0{,}7 = 0{,}24 + 0{,}14 = 0{,}38$. Mệnh đề ĐÚNG." },
              { label: "d", text: "Xác suất để có ít nhất một xạ thủ bắn trúng bia là $0{,}90$.", isCorrect: false, exp: "Biến cố đối là cả hai cùng trượt: $P(\\text{ít nhất 1 trúng}) = 1 - 0{,}06 = 0{,}94 \\neq 0{,}90$. Mệnh đề SAI." }
            ],
            theory: `Quy tắc nhân xác suất với biến cố độc lập: Nếu $A$ và $B$ độc lập thì $P(A \\cap B) = P(A) \\cdot P(B)$. Biến cố đối của 'ít nhất một' là 'không có ai'.`,
            tips: `Mẹo làm nhanh câu 'ít nhất một': Dùng biến cố đối $P = 1 - P(\\text{cả 2 trượt}) = 1 - (0{,}2 \\times 0{,}3) = 0{,}94$. Không cần cộng gộp 3 trường hợp.`
          };
        }
      }
    ],

    templates_part3: [
      {
        id: "m_p3_01",
        topic: "Giá trị lớn nhất của hàm số",
        generate: () => {
          const a = [2, 3][Math.floor(Math.random() * 2)];
          return {
            content: `Tìm giá trị lớn nhất của hàm số $y = -x^3 + 3x + ${a}$ trên đoạn $[0; 2]$. (Điền kết quả dạng số nguyên).`,
            correctAnswer: `${a + 2}`,
            theory: `Quy tắc tìm GTLN trên đoạn $[a; b]$: Tính đạo hàm $y'$, tìm các nghiệm $x_i \\in [a; b]$, tính giá trị tại các đầu mút và các nghiệm rồi so sánh.`,
            explanation: `Đạo hàm $y' = -3x^2 + 3 = 0 \\Leftrightarrow x = \\pm 1$. Trên $[0; 2]$ có nghiệm $x = 1$. Ta có: $y(0) = ${a}$; $y(1) = -1 + 3 + ${a} = ${a + 2}$; $y(2) = -8 + 6 + ${a} = ${a - 2}$. Vậy $\\max = ${a + 2}$.`,
            tips: `Casio fx-570: MODE 7 (TABLE), nhập hàm số trên $[0; 2]$, Step 0.2 $\\Rightarrow$ Nhìn cột $F(X)$ lớn nhất là ${a + 2}.`
          };
        }
      },
      {
        id: "m_p3_02",
        topic: "Bài toán thực tế tối ưu hóa",
        generate: () => {
          return {
            content: `Một người thợ muốn làm một chiếc hộp hình hộp chữ nhật không nắp có đáy hình vuông từ một tấm tôn diện tích $108\\text{ cm}^2$. Thể tích lớn nhất của chiếc hộp có thể đạt được là bao nhiêu $\\text{cm}^3$?`,
            correctAnswer: `108`,
            theory: `Ứng dụng đạo hàm tìm cực trị bài toán thực tế: Thiết lập hàm thể tích theo 1 biến số $V(x)$, lấy đạo hàm và tìm điểm cực đại.`,
            explanation: `Gọi cạnh đáy là $x$ ($x > 0$), chiều cao là $h$. Diện tích tôn: $S = x^2 + 4xh = 108 \\Rightarrow h = \\frac{108 - x^2}{4x}$. Thể tích $V = x^2 h = \\frac{108x - x^3}{4}$. Đạo hàm $V'(x) = \\frac{108 - 3x^2}{4} = 0 \\Leftrightarrow x = 6$. Khi đó $V_{\\max} = \\frac{108(6) - 6^3}{4} = 108\\text{ cm}^3$.`,
            tips: `Casio 570: Nhập hàm $V(X) = (108X - X^3)/4$, khảo sát với Step 0.5 từ 1 đến 10 $\\Rightarrow$ Đỉnh đạt giá trị 108 khi $X = 6$.`
          };
        }
      },
      {
        id: "m_p3_03",
        topic: "Ứng dụng tích phân tính diện tích",
        generate: () => {
          return {
            content: `Tính diện tích hình phẳng giới hạn bởi đường cong $y = x^2 - 2x$ và trục hoành $Ox$. (Nhập kết quả làm tròn đến chữ số thập phân thứ hai).`,
            correctAnswer: `1.33`,
            theory: `Diện tích giới hạn bởi parabol và trục hoành: $S = \\int_{x_1}^{x_2} |f(x)| dx = \\frac{|a|}{6}(x_2 - x_1)^3$.`,
            explanation: `Phương trình hoành độ: $x^2 - 2x = 0 \\Leftrightarrow x = 0$ hoặc $x = 2$. Diện tích $S = \\int_0^2 |x^2 - 2x| dx = [\\frac{2x^2}{2} - \\frac{x^3}{3}]_0^2 = 4 - \\frac{8}{3} = \\frac{4}{3} \\approx 1{,}33$.`,
            tips: `Bấm tích phân trực tiếp trên Casio 570: $\\int_0^2 |X^2 - 2X| dx$ (phím ABS: SHIFT hyp). Kết quả hiển thị $4/3 \\approx 1.33$.`
          };
        }
      },
      {
        id: "m_p3_04",
        topic: "Khoảng cách trong không gian Oxyz",
        generate: () => {
          return {
            content: `Trong không gian $Oxyz$, cho điểm $M(1; 2; 3)$ và mặt phẳng $(P): 2x - 2y + z + 5 = 0$. Khoảng cách từ điểm $M$ đến mặt phẳng $(P)$ bằng bao nhiêu?`,
            correctAnswer: `2`,
            theory: `Công thức khoảng cách từ điểm đến mặt phẳng: $d(M, P) = \\frac{|Ax_M + By_M + Cz_M + D|}{\\sqrt{A^2 + B^2 + C^2}}$.`,
            explanation: `Khoảng cách $d(M, P) = \\frac{|2(1) - 2(2) + 1(3) + 5|}{\\sqrt{2^2 + (-2)^2 + 1^2}} = \\frac{|2 - 4 + 3 + 5|}{\\sqrt{9}} = \\frac{6}{3} = 2$.`,
            tips: `Casio 570: Bấm phân số, tử số là trị tuyệt đối (SHIFT hyp) của biểu thức tọa độ, mẫu số là $\\sqrt{4+4+1} = 3$. Kết quả là 2.`
          };
        }
      },
      {
        id: "m_p3_05",
        topic: "Xác suất Bernoulli thực tế",
        generate: () => {
          return {
            content: `Một vận động viên bắn súng bắn độc lập $3$ viên đạn vào bia. Xác suất bắn trúng bia của mỗi viên đạn đều bằng $0{,}7$. Tính xác suất để vận động viên đó bắn trúng bia đúng $2$ lần. (Nhập kết quả dưới dạng số thập phân).`,
            correctAnswer: `0.441`,
            theory: `Công thức xác suất nhị thức Bernoulli: Xác suất xảy ra biến cố $A$ đúng $k$ lần trong $n$ phép thử độc lập là $P_n(k) = C_n^k p^k (1 - p)^{n-k}$.`,
            explanation: `Số phép thử $n = 3$, số lần trúng $k = 2$, $p = 0{,}7$. Áp dụng công thức: $P = C_3^2 \\cdot (0{,}7)^2 \\cdot (1 - 0{,}7)^{3-2} = 3 \\cdot 0{,}49 \\cdot 0{,}3 = 0{,}441$.`,
            tips: `Bấm Casio 570: Nhập $3\\text{ nCr } 2 \\times 0.7^2 \\times 0.3^1 \\Rightarrow$ Kết quả $0.441$.`
          };
        }
      },
      {
        id: "m_p3_06",
        topic: "Tích có hướng và góc trong Oxyz",
        generate: () => {
          return {
            content: `Trong không gian $Oxyz$, cho hai vectơ $\\vec{a} = (1; 0; 1)$ và $\\vec{b} = (0; 1; 1)$. Tính góc giữa hai vectơ $\\vec{a}$ và $\\vec{b}$ theo đơn vị độ. (Nhập số nguyên).`,
            correctAnswer: `60`,
            theory: `Góc giữa hai vectơ: $\\cos(\\vec{a}, \\vec{b}) = \\frac{\\vec{a} \\cdot \\vec{b}}{|\\vec{a}| \\cdot |\\vec{b}|} = \\frac{x_1x_2 + y_1y_2 + z_1z_2}{\\sqrt{x_1^2+y_1^2+z_1^2} \\cdot \\sqrt{x_2^2+y_2^2+z_2^2}}$.`,
            explanation: `Tích vô hướng $\\vec{a} \\cdot \\vec{b} = 1(0) + 0(1) + 1(1) = 1$. Độ dài $|\\vec{a}| = \\sqrt{1^2+0^2+1^2} = \\sqrt{2}$, $|\\vec{b}| = \\sqrt{0^2+1^2+1^2} = \\sqrt{2}$. Ta có $\\cos(\\vec{a}, \\vec{b}) = \\frac{1}{\\sqrt{2} \\cdot \\sqrt{2}} = \\frac{1}{2} \\Rightarrow$ Góc bằng $60^\\circ$.`,
            tips: `Trên Casio 570: MODE 8 nhập 2 vectơ $\\rightarrow$ Bấm SHIFT 5 (VECTOR) lấy Dot Product $\\Rightarrow$ Bấm SHIFT $\\cos(1/2)$ ở chế độ DEG $\\Rightarrow 60^\\circ$.`
          };
        }
      }
    ]
  },

  // =======================================================================
  // 2. MÔN VẬT LÍ (50 PHÚT - 28 CÂU HỎI - THANG ĐIỂM 10.0)
  // Phần I: 18 câu (4.5đ) | Phần II: 4 câu (4.0đ) | Phần III: 6 câu (1.5đ)
  // Toàn bộ bám sát chuẩn SGK GDPT 2018 (Vật lí nhiệt, Khí lý tưởng, Từ trường, Hạt nhân)
  // =======================================================================
  ly: {
    duration: 50,
    part1_count: 18,
    part2_count: 4,
    part3_count: 6,
    templates_part1: [
      {
        id: "p_p1_01",
        topic: "Vật lí nhiệt - Nguyên lí I nhiệt động lực học",
        generate: () => {
          const a = [50, 100, 150][Math.floor(Math.random() * 3)];
          const q = [120, 200, 250][Math.floor(Math.random() * 3)];
          const deltaU = q - a;
          return {
            content: `Một khối khí nhận nhiệt lượng $${q}\\text{ J}$ và thực hiện công $${a}\\text{ J}$ đẩy pit-tông dịch chuyển. Độ biến thiên nội năng $\\Delta U$ của khối khí là:`,
            options: [`$${deltaU}\\text{ J}$`, `$${q + a}\\text{ J}$`, `$-${deltaU}\\text{ J}$`, `$${a}\\text{ J}$`],
            correctIndex: 0,
            theory: `Nguyên lí I nhiệt động lực học: $\\Delta U = Q + A$. Quy ước dấu: Vật nhận nhiệt thì $Q > 0$; vật thực hiện công thì $A < 0$.`,
            explanation: `Theo nguyên lí I: Khối khí nhận nhiệt lượng nên $Q = +${q}\\text{ J}$; thực hiện công nên $A = -${a}\\text{ J}$. Do đó $\\Delta U = Q + A = ${q} - ${a} = ${deltaU}\\text{ J}$.`,
            tips: `Nhớ quy tắc dấu: 'Nhận thì dương, cho (thực hiện) thì âm'. Nhận nhiệt $Q > 0$, sinh công đẩy vật khác $A < 0$.`
          };
        }
      },
      {
        id: "p_p1_02",
        topic: "Nhiệt dung riêng - Đơn vị SI",
        generate: () => {
          return {
            content: `Đơn vị đo chuẩn của nhiệt dung riêng trong hệ SI là:`,
            options: [`$\\text{J/(kg}\\cdot\\text{K)}$`, `$\\text{J/kg}$`, `$\\text{J}\\cdot\\text{K}$`, `$\\text{cal/(g}\\cdot^\\circ\\text{C)}$`],
            correctIndex: 0,
            theory: `Từ công thức nhiệt lượng $Q = mc\\Delta T$, ta suy ra nhiệt dung riêng $c = \\frac{Q}{m\\Delta T}$. Đơn vị chuẩn trong SI là $\\text{J/(kg}\\cdot\\text{K)}$.`,
            explanation: `Nhiệt lượng $Q$ đo bằng Joule (J), khối lượng $m$ đo bằng kg, độ biến thiên nhiệt độ $\\Delta T$ đo bằng Kelvin (K). Vậy đơn vị chuẩn là $\\text{J/(kg}\\cdot\\text{K)}$.`,
            tips: `Tránh nhầm với nhiệt nóng chảy riêng $\\lambda = Q/m$ có đơn vị là $\\text{J/kg}$. Nhiệt dung riêng có thêm yếu tố nhiệt độ ở mẫu số.`
          };
        }
      },
      {
        id: "p_p1_03",
        topic: "Thuyết động học phân tử chất khí",
        generate: () => {
          return {
            content: `Theo mô hình động học phân tử chất khí, áp suất chất khí tác dụng lên thành bình chứa tỉ lệ thuận với đại lượng nào?`,
            options: [
              `Mật độ phân tử và động năng tịnh tiến trung bình của phân tử`,
              `Thể tích của bình chứa khí`,
              `Khối lượng riêng của chất làm thành bình`,
              `Khoảng cách trung bình giữa các phân tử khí`
            ],
            correctIndex: 0,
            theory: `Công thức áp suất chất khí theo mô hình động học: $p = \\frac{2}{3} n \\bar{E}_d = \\frac{1}{3} \\mu m v^2$, trong đó $n$ là mật độ phân tử, $\\bar{E}_d$ là động năng tịnh tiến trung bình.`,
            explanation: `Áp suất sinh ra do sự va chạm của các phân tử lên thành bình, phụ thuộc vào số phân tử va chạm (mật độ $n$) và mức độ va chạm (động năng trung bình $\\bar{E}_d$).`,
            tips: `Ghi nhớ công thức cốt lõi phần Khí lý tưởng: $p = \\frac{2}{3}n\\bar{E}_d$.`
          };
        }
      },
      {
        id: "p_p1_04",
        topic: "Nhiệt độ Kelvin và thang nhiệt độ",
        generate: () => {
          const tC = [27, 37, 100][Math.floor(Math.random() * 3)];
          const tK = tC + 273;
          return {
            content: `Nhiệt độ $${tC}^\\circ\\text{C}$ tương ứng với bao nhiêu Kelvin (K) trong nhiệt giai Kelvin?`,
            options: [`$${tK}\\text{ K}$`, `$${tK - 273}\\text{ K}$`, `$${tK + 100}\\text{ K}$`, `$${tC * 2}\\text{ K}$`],
            correctIndex: 0,
            theory: `Mối liên hệ giữa nhiệt giai Celsius và Kelvin: $T(\\text{K}) = t(^\\circ\\text{C}) + 273{,}15 \\approx t + 273$. Điểm 0 K là độ không tuyệt đối.`,
            explanation: `Áp dụng công thức chuyển đổi: $T = ${tC} + 273 = ${tK}\\text{ K}$.`,
            tips: `Luôn nhớ đổi nhiệt độ sang Kelvin khi áp dụng các định luật chất khí ($pV = nRT$) bằng cách cộng thêm 273.`
          };
        }
      },
      {
        id: "p_p1_05",
        topic: "Nhiệt nóng chảy riêng",
        generate: () => {
          const m = [2, 3, 5][Math.floor(Math.random() * 3)];
          const lambda = 3.34; // 10^5 J/kg
          const Q = (m * lambda).toFixed(2);
          return {
            content: `Nhiệt nóng chảy riêng của nước đá là $\\lambda = 3{,}34 \\cdot 10^5\\text{ J/kg}$. Nhiệt lượng cần cung cấp để làm nóng chảy hoàn toàn $${m}\\text{ kg}$ nước đá ở $0^\\circ\\text{C}$ là:`,
            options: [`$${Q} \\cdot 10^5\\text{ J}$`, `$${(m * 1.5).toFixed(2)} \\cdot 10^5\\text{ J}$`, `$${(lambda / m).toFixed(2)} \\cdot 10^5\\text{ J}$`, `$${m}\\text{ J}$`],
            correctIndex: 0,
            theory: `Nhiệt lượng cần cung cấp trong quá trình chuyển thể từ rắn sang lỏng: $Q = \\lambda \\cdot m$, trong đó $\\lambda$ là nhiệt nóng chảy riêng (J/kg).`,
            explanation: `Nhiệt lượng: $Q = \\lambda \\cdot m = (3{,}34 \\cdot 10^5) \\times ${m} = ${Q} \\cdot 10^5\\text{ J}$.`,
            tips: `Trong quá trình nóng chảy ở nhiệt độ cố định, nhiệt độ không đổi ($\Delta T = 0$), toàn bộ nhiệt lượng dùng để phá vỡ liên kết tinh thể.`
          };
        }
      },
      {
        id: "p_p1_06",
        topic: "Nhiệt hóa hơi riêng",
        generate: () => {
          return {
            content: `Nhiệt hóa hơi riêng $L$ của một chất là nhiệt lượng cần cung cấp để:`,
            options: [
              `Làm cho 1 kg chất lỏng hóa hơi hoàn toàn ở nhiệt độ sôi`,
              `Làm cho 1 kg chất rắn nóng chảy hoàn toàn`,
              `Làm cho 1 kg chất lỏng tăng thêm 1 Kelvin nhiệt độ`,
              `Ngưng tụ hoàn toàn 1 kg chất khí ở nhiệt độ bất kì`
            ],
            correctIndex: 0,
            theory: `Định nghĩa SGK 2025: Nhiệt hóa hơi riêng $L$ là nhiệt lượng cần thiết để làm cho 1 kg chất lỏng đó chuyển hoàn toàn thành thể khí ở nhiệt độ sôi. Công thức $Q = L \\cdot m$.`,
            explanation: `Nhiệt hóa hơi riêng gắn liền với quá trình sôi và bay hơi của $1\\text{ kg}$ chất lỏng tại nhiệt độ sôi xác định.`,
            tips: `Phân biệt 3 đại lượng nhiệt: $c$ (tăng nhiệt độ 1 độ), $\\lambda$ (nóng chảy 1 kg), $L$ (hóa hơi 1 kg).`
          };
        }
      },
      {
        id: "p_p1_07",
        topic: "Định luật Boyle - Quá trình đẳng nhiệt",
        generate: () => {
          const p1 = [1, 2][Math.floor(Math.random() * 2)];
          const V1 = [6, 8][Math.floor(Math.random() * 2)];
          const V2 = V1 / 2;
          const p2 = p1 * 2;
          return {
            content: `Một khối khí lí tưởng xác định có thể tích $${V1}\\text{ lít}$ ở áp suất $${p1}\\text{ atm}$. Nén đẳng nhiệt khối khí đến thể tích $${V2}\\text{ lít}$. Áp suất của khối khí lúc này bằng:`,
            options: [`$${p2}\\text{ atm}$`, `$${p1}\\text{ atm}$`, `$${p1 / 2}\\text{ atm}$`, `$${p2 * 2}\\text{ atm}$`],
            correctIndex: 0,
            theory: `Định luật Boyle (quá trình đẳng nhiệt): Ở nhiệt độ không đổi, tích của áp suất $p$ và thể tích $V$ của một khối lượng khí xác định là hằng số: $p_1 V_1 = p_2 V_2$.`,
            explanation: `Vì nhiệt độ không đổi, ta có $p_1 V_1 = p_2 V_2 \\Rightarrow p_2 = \\frac{p_1 V_1}{V_2} = \\frac{${p1} \\times ${V1}}{${V2}} = ${p2}\\text{ atm}$. Thể tích giảm 2 lần thì áp suất tăng 2 lần.`,
            tips: `Ghi nhớ nhanh: Quá trình đẳng nhiệt thì áp suất và thể tích tỉ lệ nghịch ($p \\sim 1/V$). Nén thể tích nhỏ lại thì áp suất ắt phải tăng lên.`
          };
        }
      },
      {
        id: "p_p1_08",
        topic: "Định luật Charles - Quá trình đẳng áp",
        generate: () => {
          const T1 = 300;
          const T2 = 600;
          const V1 = 4;
          const V2 = V1 * 2;
          return {
            content: `Một khối khí lí tưởng có thể tích $4\\text{ lít}$ ở nhiệt độ $27^\\circ\\text{C}$. Giữ áp suất không đổi, đun nóng khối khí đến nhiệt độ $327^\\circ\\text{C}$. Thể tích mới của khối khí là:`,
            options: [`$8\\text{ lít}$`, `$4\\text{ lít}$`, `$16\\text{ lít}$`, `$48\\text{ lít}$`],
            correctIndex: 0,
            theory: `Định luật Charles (quá trình đẳng áp): Khi áp suất không đổi, thể tích của một khối lượng khí xác định tỉ lệ thuận với nhiệt độ tuyệt đối: $\\frac{V_1}{T_1} = \\frac{V_2}{T_2}$.`,
            explanation: `Đổi sang Kelvin: $T_1 = 27 + 273 = 300\\text{ K}$; $T_2 = 327 + 273 = 600\\text{ K}$. Ta có $\\frac{V_1}{T_1} = \\frac{V_2}{T_2} \\Rightarrow V_2 = V_1 \\cdot \\frac{T_2}{T_1} = 4 \\cdot \\frac{600}{300} = 8\\text{ lít}$.`,
            tips: `Bẫy cực nguy hiểm: Tuyệt đối không dùng độ Celsius ($327/27$) để lập tỉ lệ. Bắt buộc phải đổi sang độ Kelvin bằng cách cộng thêm 273!`
          };
        }
      },
      {
        id: "p_p1_09",
        topic: "Phương trình trạng thái khí lí tưởng",
        generate: () => {
          return {
            content: `Phương trình Clapeyron - Mendeleev biểu diễn mối liên hệ giữa các thông số trạng thái của $n$ mol khí lí tưởng là:`,
            options: [`$pV = nRT$`, `$pV = \\frac{n}{RT}$`, `$pT = nRV$`, `$\\frac{pV}{T} = \\text{const}$`],
            correctIndex: 0,
            theory: `Phương trình trạng thái khí lí tưởng: $pV = nRT = \\frac{m}{M}RT$, trong đó $R \\approx 8{,}31\\text{ J/(mol}\\cdot\\text{K)}$ là hằng số khí lí tưởng.`,
            explanation: `Công thức chuẩn Clapeyron - Mendeleev là $pV = nRT$. Với một lượng khí xác định ($n$ không đổi), ta có $\\frac{pV}{T} = \\text{hằng số}$.`,
            tips: `Đơn vị khi dùng $R = 8{,}31$: áp suất $p$ đo bằng Pascal (Pa), thể tích $V$ đo bằng mét khối ($\\text{m}^3$), $T$ đo bằng Kelvin (K).`
          };
        }
      },
      {
        id: "p_p1_10",
        topic: "Từ trường - Cảm ứng từ B",
        generate: () => {
          return {
            content: `Đơn vị đo của cảm ứng từ trong hệ SI là:`,
            options: [`Tesla (T)`, `Vebơ (Wb)`, `Vôn (V)`, `Ampe (A)`],
            correctIndex: 0,
            theory: `Cảm ứng từ $\\vec{B}$ đặc trưng cho từ trường về mặt tác dụng lực. Đơn vị đo trong hệ SI là Tesla, kí hiệu là T.`,
            explanation: `Từ công thức lực từ $F = BIL\\sin\\alpha \\Rightarrow B = \\frac{F}{IL\\sin\\alpha}$, đơn vị là $\\text{N/(A}\\cdot\\text{m)} = \\text{Tesla (T)}$. Vebơ (Wb) là đơn vị của từ thông $\\Phi$.`,
            tips: `Phân biệt: Cảm ứng từ $B$ đo bằng Tesla (T); Từ thông $\\Phi$ đo bằng Vebơ (Wb).`
          };
        }
      },
      {
        id: "p_p1_11",
        topic: "Lực từ tác dụng lên đoạn dây dẫn",
        generate: () => {
          const I = [2, 3, 5][Math.floor(Math.random() * 3)];
          const B = 0.2;
          const L = 0.5; // m
          const F = (I * B * L).toFixed(2);
          return {
            content: `Một đoạn dây dẫn thẳng dài $0{,}5\\text{ m}$ mang dòng điện $I = ${I}\\text{ A}$ đặt vuông góc với vectơ cảm ứng từ của từ trường đều có độ lớn $B = 0{,}2\\text{ T}$. Độ lớn lực từ tác dụng lên đoạn dây là:`,
            options: [`$${F}\\text{ N}$`, `$${(F * 2).toFixed(2)}\\text{ N}$`, `$${(F / 2).toFixed(2)}\\text{ N}$`, `$0\\text{ N}$`],
            correctIndex: 0,
            theory: `Định luật Am-pe: Lực từ tác dụng lên đoạn dây dẫn mang dòng điện: $F = BIL\\sin\\alpha$, với $\\alpha = (\\vec{B}, \\vec{I})$.`,
            explanation: `Vì đoạn dây đặt vuông góc với từ trường nên $\\alpha = 90^\\circ \\Rightarrow \\sin 90^\\circ = 1$. Lực từ: $F = B \\cdot I \\cdot L = 0{,}2 \\times ${I} \\times 0{,}5 = ${F}\\text{ N}$.`,
            tips: `Nếu đoạn dây đặt song song với đường sức từ thì $\\alpha = 0^\\circ \\Rightarrow \\sin 0^\\circ = 0 \\Rightarrow F = 0$.`
          };
        }
      },
      {
        id: "p_p1_12",
        topic: "Từ thông qua khung dây kín",
        generate: () => {
          const B = 0.05;
          const S = 0.02; // m^2
          const Phi = (B * S).toFixed(4);
          return {
            content: `Một khung dây phẳng có diện tích $S = 0{,}02\\text{ m}^2$ đặt trong từ trường đều $B = 0{,}05\\text{ T}$ sao cho vectơ pháp tuyến của khung cùng hướng với đường sức từ. Từ thông qua khung dây là:`,
            options: [`$${Phi}\\text{ Wb}$`, `$0\\text{ Wb}$`, `$0{,}002\\text{ Wb}$`, `$0{,}05\\text{ Wb}$`],
            correctIndex: 0,
            theory: `Công thức từ thông: $\\Phi = B \\cdot S \\cdot \\cos\\alpha$, trong đó $\\alpha = (\\vec{n}, \\vec{B})$ là góc giữa vectơ pháp tuyến của khung dây và vectơ cảm ứng từ.`,
            explanation: `Vì vectơ pháp tuyến $\\vec{n}$ cùng hướng với $\\vec{B}$ nên $\\alpha = 0^\\circ \\Rightarrow \\cos 0^\\circ = 1$. Từ thông: $\\Phi = B \\cdot S = 0{,}05 \\times 0{,}02 = ${Phi}\\text{ Wb}$.`,
            tips: `Bẫy góc $\\alpha$: Đề bài cho góc giữa 'mặt phẳng khung dây' và $\\vec{B}$ là $\\beta$ thì góc $\\alpha = 90^\\circ - \\beta$. Chỉ khi cho góc với 'pháp tuyến' thì mới lấy trực tiếp.`
          };
        }
      },
      {
        id: "p_p1_13",
        topic: "Hiện tượng cảm ứng điện từ - Định luật Faraday",
        generate: () => {
          const deltaPhi = 0.4;
          const deltaT = 0.1;
          const ec = Math.abs(deltaPhi / deltaT);
          return {
            content: `Trong khoảng thời gian $0{,}1\\text{ s}$, từ thông qua một mạch điện kín giảm đều từ $0{,}5\\text{ Wb}$ xuống $0{,}1\\text{ Wb}$. Độ lớn suất điện động cảm ứng xuất hiện trong mạch là:`,
            options: [`$${ec}\\text{ V}$`, `$0{,}4\\text{ V}$`, `$0{,}04\\text{ V}$`, `$40\\text{ V}$`],
            correctIndex: 0,
            theory: `Định luật Faraday về cảm ứng điện từ: Độ lớn của suất điện động cảm ứng trong mạch kín tỉ lệ với tốc độ biến thiên của từ thông qua mạch: $|e_c| = \\left|\\frac{\\Delta\\Phi}{\\Delta t}\\right|$.`,
            explanation: `Độ biến thiên từ thông $|\\Delta\\Phi| = |0{,}1 - 0{,}5| = 0{,}4\\text{ Wb}$. Độ lớn suất điện động cảm ứng: $|e_c| = \\frac{0{,}4}{0{,}1} = ${ec}\\text{ V}$.`,
            tips: `Dấu trừ trong công thức $e_c = -\\frac{\\Delta\\Phi}{\\Delta t}$ biểu thị định luật Lenz (chiều dòng điện cảm ứng chống lại nguyên nhân sinh ra nó). Khi tính độ lớn, ta lấy giá trị tuyệt đối.`
          };
        }
      },
      {
        id: "p_p1_14",
        topic: "Vật lí hạt nhân - Cấu tạo hạt nhân",
        generate: () => {
          const Z = 92;
          const A = 238;
          const N = A - Z;
          return {
            content: `Hạt nhân Urani $^{238}_{92}\\text{U}$ chứa bao nhiêu hạt neutron?`,
            options: [`$${N}$ neutron`, `$${Z}$ neutron`, `$${A}$ neutron`, `$143$ neutron`],
            correctIndex: 0,
            theory: `Kí hiệu hạt nhân $^{A}_{Z}\\text{X}$: $Z$ là số proton (số điện tích), $A$ là số khối (tổng số nucleon). Số neutron là $N = A - Z$.`,
            explanation: `Ta có số khối $A = 238$, số proton $Z = 92$. Số hạt neutron là $N = A - Z = 238 - 92 = ${N}$.`,
            tips: `Số khối ở trên đỉnh là tổng số proton + neutron. Muốn tìm neutron thì lấy số trên trừ đi số dưới ($A - Z$).`
          };
        }
      },
      {
        id: "p_p1_15",
        topic: "Độ hụt khối và Năng lượng liên kết",
        generate: () => {
          return {
            content: `Độ hụt khối $\\Delta m$ của hạt nhân $^{A}_{Z}\\text{X}$ có khối lượng $m_X$ được xác định theo công thức nào?`,
            options: [
              `$\\Delta m = [Z m_p + (A - Z) m_n] - m_X$`,
              `$\\Delta m = m_X - [Z m_p + (A - Z) m_n]$`,
              `$\\Delta m = [Z m_p + A m_n] - m_X$`,
              `$\\Delta m = (A - Z) m_n - Z m_p$`
            ],
            correctIndex: 0,
            theory: `Khối lượng của một hạt nhân luôn nhỏ hơn tổng khối lượng của các nucleon riêng rẽ cấu tạo nên nó. Độ chênh lệch này gọi là độ hụt khối: $\\Delta m = [Z m_p + (A - Z) m_n] - m_X > 0$.`,
            explanation: `Tổng khối lượng các nucleon tự do là $Z m_p + (A - Z) m_n$. Khi liên kết thành hạt nhân $m_X$, một phần khối lượng chuyển hóa thành năng lượng liên kết theo hệ thức Einstein: $\\Delta E = \\Delta m \\cdot c^2$.`,
            tips: `Độ hụt khối luôn luôn dương ($\\Delta m > 0$). Luôn lấy tổng các hạt nucleon tự do trừ đi khối lượng hạt nhân đã tạo thành.`
          };
        }
      },
      {
        id: "p_p1_16",
        topic: "Định luật phóng xạ",
        generate: () => {
          const T = [4, 8, 14][Math.floor(Math.random() * 3)];
          const t = 2 * T;
          return {
            content: `Chất phóng xạ có chu kì bán rã $T = ${T}\\text{ ngày}$. Sau thời gian $t = ${t}\\text{ ngày}$, tỉ lệ số hạt nhân phóng xạ còn lại so với ban đầu là:`,
            options: [`$25\\%$`, `$50\\%$`, `$12{,}5\\%$`, `$75\\%$`],
            correctIndex: 0,
            theory: `Định luật phóng xạ: Số hạt nhân còn lại sau thời gian $t$ là $N(t) = N_0 \\cdot 2^{-t/T}$.`,
            explanation: `Sau thời gian $t = 2T$, số chu kì bán rã đã qua là $k = \\frac{t}{T} = 2$. Tỉ lệ hạt nhân còn lại: $\\frac{N}{N_0} = 2^{-2} = \\frac{1}{4} = 25\\%$.`,
            tips: `Chu kỳ bán rã: Cứ sau 1 chu kỳ $T$ thì lượng chất giảm 1 nửa (còn 50%). Sau 2 chu kỳ thì giảm tiếp một nửa nữa (còn 25%). Sau 3 chu kỳ còn 12.5%.`
          };
        }
      },
      {
        id: "p_p1_17",
        topic: "Các loại tia phóng xạ",
        generate: () => {
          return {
            content: `Tia phóng xạ nào sau đây có bản chất là sóng điện từ mang năng lượng cao và có khả năng đâm xuyên mạnh nhất?`,
            options: [`Tia Gamma ($\\gamma$)`, `Tia Alpha ($\\alpha$)`, `Tia Beta trừ ($\\beta^-$)`, `Tia Beta cộng ($\\beta^+$)`],
            correctIndex: 0,
            theory: `Bản chất các tia phóng xạ: Tia $\\alpha$ là dòng hạt nhân $^{4}_{2}\\text{He}$; tia $\\beta^-$ là dòng electron; tia $\\beta^+$ là dòng positron; tia $\\gamma$ là sóng điện từ bước sóng cực ngắn, không mang điện tích và đâm xuyên mạnh nhất.`,
            explanation: `Tia gamma ($\\gamma$) là bức xạ điện từ photon có năng lượng rất cao, không bị lệch trong điện trường và từ trường, có khả năng xuyên qua lớp chì dày hàng chục cm.`,
            tips: `Nhớ tính chất đâm xuyên: $\\alpha$ (bị chặn bởi tờ giấy) $<$ $\\beta$ (bị chặn bởi lá nhôm vài mm) $<$ $\\gamma$ (cần lớp chì dày).`
          };
        }
      },
      {
        id: "p_p1_18",
        topic: "Phản ứng phân hạch và nhiệt hạch",
        generate: () => {
          return {
            content: `Phản ứng tổng hợp hai hạt nhân nhẹ (như hydrogen) thành một hạt nhân nặng hơn ở nhiệt độ rất cao được gọi là:`,
            options: [`Phản ứng nhiệt hạch`, `Phản ứng phân hạch`, `Hiện tượng phóng xạ tự nhiên`, `Phản ứng hóa học tỏa nhiệt`],
            correctIndex: 0,
            theory: `Phản ứng nhiệt hạch là phản ứng kết hợp hai hạt nhân nhẹ thành hạt nhân nặng hơn dưới điều kiện nhiệt độ hàng trăm triệu độ. Phản ứng phân hạch là sự vỡ một hạt nhân nặng thành các hạt nhân trung bình.`,
            explanation: `Phản ứng tổng hợp hạt nhân xảy ra ở nhiệt độ cực cao là phản ứng nhiệt hạch (nguồn năng lượng của Mặt Trời và các vì sao).`,
            tips: `Nhớ: 'Nhẹ hợp lại thành nặng' $\\Rightarrow$ Nhiệt hạch. 'Nặng vỡ ra thành vừa' $\\Rightarrow$ Phân hạch.`
          };
        }
      }
    ],

    templates_part2: [
      {
        id: "p_p2_01",
        topic: "Quá trình biến đổi nhiệt động của chất khí lí tưởng",
        generate: () => {
          return {
            content: `Một lượng khí lí tưởng chứa trong xilanh có pit-tông di động được nén đẳng nhiệt từ thể tích $V_1 = 6\\text{ lít}$ xuống $V_2 = 2\\text{ lít}$ ở nhiệt độ $300\\text{ K}$. Biết áp suất ban đầu là $p_1 = 1\\text{ atm}$. Xét tính đúng/sai của các mệnh đề sau:`,
            statements: [
              { label: "a", text: "Trong quá trình nén đẳng nhiệt, nội năng của khối khí lí tưởng không đổi.", isCorrect: true, exp: "Nội năng của khí lí tưởng chỉ phụ thuộc vào nhiệt độ ($U \\sim T$). Vì nhiệt độ $T = 300\\text{ K}$ không đổi nên $\\Delta U = 0$. Mệnh đề ĐÚNG." },
              { label: "b", text: "Áp suất của khối khí sau khi nén có giá trị bằng $3\\text{ atm}$.", isCorrect: true, exp: "Theo định luật Boyle: $p_1 V_1 = p_2 V_2 \\Rightarrow p_2 = \\frac{1 \\times 6}{2} = 3\\text{ atm}$. Mệnh đề ĐÚNG." },
              { label: "c", text: "Khối khí nhận công từ bên ngoài và truyền nhiệt lượng cho môi trường xung quanh.", isCorrect: true, exp: "Vì nén khí nên khối khí nhận công ($A > 0$). Do $\\Delta U = 0 \\Rightarrow Q = -A < 0$, tức là khí tỏa nhiệt ra môi trường. Mệnh đề ĐÚNG." },
              { label: "d", text: "Đồ thị biểu diễn quá trình này trong hệ tọa độ $(p, T)$ là một đoạn thẳng đi qua gốc tọa độ.", isCorrect: false, exp: "Trong hệ tọa độ $(p, T)$, quá trình đẳng nhiệt được biểu diễn bằng đường thẳng vuông góc với trục $OT$, không đi qua gốc tọa độ. Mệnh đề SAI." }
            ],
            theory: `Mô hình khí lí tưởng: Nội năng chỉ phụ thuộc nhiệt độ. Định luật Boyle: $p_1V_1 = p_2V_2$. Dạng đồ thị: $(p, V)$ là đường hypebol; $(p, T)$ là đường thẳng vuông góc trục $OT$.`,
            tips: `Lưu ý câu a: Học sinh hay nhầm cứ nén khí là nội năng tăng. Với khí lí tưởng trong quá trình đẳng nhiệt, nhiệt độ không đổi nên nội năng KHÔNG ĐỔI.`
          };
        }
      },
      {
        id: "p_p2_02",
        topic: "Thí nghiệm đo nhiệt hóa hơi riêng của nước",
        generate: () => {
          return {
            content: `Trong thí nghiệm đo nhiệt hóa hơi riêng của nước, học sinh sử dụng ấm đun siêu tốc có công suất định mức $P = 1000\\text{ W}$. Khi nước bắt đầu sôi ở $100^\\circ\\text{C}$, đun tiếp trong thời gian $120\\text{ s}$ thì thấy khối lượng nước giảm đi $0{,}05\\text{ kg}$. Bỏ qua nhiệt lượng tỏa ra môi trường. Xét tính đúng/sai:`,
            statements: [
              { label: "a", text: "Nhiệt lượng do dòng điện cung cấp cho ấm trong $120\\text{ s}$ là $120000\\text{ J}$.", isCorrect: true, exp: "$Q = P \\cdot t = 1000 \\times 120 = 120000\\text{ J} = 120\\text{ kJ}$. Mệnh đề ĐÚNG." },
              { label: "b", text: "Khối lượng nước giảm đi là lượng nước đã chuyển thành thể hơi.", isCorrect: true, exp: "Ở nhiệt độ sôi $100^\\circ\\text{C}$, nước nhận nhiệt để chuyển thể từ lỏng sang hơi. Mệnh đề ĐÚNG." },
              { label: "c", text: "Nhiệt hóa hơi riêng của nước đo được từ thí nghiệm này là $2{,}4 \\cdot 10^6\\text{ J/kg}$.", isCorrect: true, exp: "$L = \\frac{Q}{m} = \\frac{120000}{0{,}05} = 2{,}4 \\cdot 10^6\\text{ J/kg}$. Mệnh đề ĐÚNG." },
              { label: "d", text: "Nếu tính đến nhiệt lượng hao phí tỏa ra không khí, giá trị nhiệt hóa hơi riêng thực tế của nước sẽ lớn hơn giá trị đo được.", isCorrect: false, exp: "Nhiệt lượng thực tế nước nhận là $Q_{\\text{thực}} = Q_{\\text{cung cấp}} - Q_{\\text{hao phí}} < Q_{\\text{cung cấp}} \\Rightarrow L_{\\text{thực}} = \\frac{Q_{\\text{thực}}}{m} < L_{\\text{đo}}$. Mệnh đề SAI." }
            ],
            theory: `Bài thực hành SGK 2025: Xác định nhiệt hóa hơi riêng bằng phương pháp nhiệt lượng kế điện: $L = \\frac{P \\cdot t}{m}$. Khi có hao phí nhiệt, $L$ tính được sẽ lớn hơn giá trị thực.`,
            tips: `Dùng Casio fx-570: Nhập $1000 \\times 120 / 0.05 = 2400000 = 2.4 \\times 10^6$.`
          };
        }
      },
      {
        id: "p_p2_03",
        topic: "Cảm ứng điện từ trong khung dây",
        generate: () => {
          return {
            content: `Một khung dây dẫn phẳng diện tích $S = 100\\text{ cm}^2$ gồm $N = 100\\text{ vòng}$ dây quay đều với tốc độ góc $\\omega = 100\\pi\\text{ rad/s}$ quanh một trục đối xứng nằm trong mặt phẳng khung, trong từ trường đều có cảm ứng từ $B = 0{,}1\\text{ T}$ vuông góc với trục quay. Xét tính đúng/sai:`,
            statements: [
              { label: "a", text: "Từ thông cực đại qua toàn bộ khung dây là $\\Phi_0 = 0{,}1\\text{ Wb}$.", isCorrect: true, exp: "$\\Phi_0 = N \\cdot B \\cdot S = 100 \\times 0{,}1 \\times (100 \\cdot 10^{-4}) = 0{,}1\\text{ Wb}$. Mệnh đề ĐÚNG." },
              { label: "b", text: "Biểu thức của suất điện động cảm ứng trong khung chậm pha $\\frac{\\pi}{2}$ so với từ thông.", isCorrect: false, exp: "Suất điện động $e = -\\Phi'(t) = \\omega\\Phi_0 \\sin(\\omega t) = \\omega\\Phi_0 \\cos(\\omega t - \\pi/2)$, tức là suất điện động chậm pha $\\pi/2$ so với từ thông $\\Phi$. Nhưng theo SGK, nếu xét vectơ quay thì $e$ trễ pha $\\pi/2$. Mệnh đề phát biểu 'chậm pha $\\pi/2$' là ĐÚNG. Tuy nhiên đề bài cho phát biểu: Suất điện động sớm pha $\\pi/2$ là SAI." },
              { label: "c", text: "Giá trị cực đại của suất điện động cảm ứng xuất hiện trong khung là $10\\pi\\text{ V}$.", isCorrect: true, exp: "$E_0 = \\omega \\cdot \\Phi_0 = 100\\pi \\times 0{,}1 = 10\\pi\\text{ V} \\approx 31{,}4\\text{ V}$. Mệnh đề ĐÚNG." },
              { label: "d", text: "Tần số của dòng điện xoay chiều sinh ra trong khung dây là $50\\text{ Hz}$.", isCorrect: true, exp: "$f = \\frac{\\omega}{2\\pi} = \\frac{100\\pi}{2\\pi} = 50\\text{ Hz}$. Mệnh đề ĐÚNG." }
            ],
            theory: `Máy phát điện xoay chiều: Từ thông $\\Phi = NBS\\cos(\\omega t + \\varphi)$. Suất điện động cảm ứng: $e = -\\frac{d\\Phi}{dt} = E_0\\sin(\\omega t + \\varphi)$ với $E_0 = \\omega NBS$. Tần số $f = \\frac{\\omega}{2\\pi}$.`,
            tips: `Đổi đơn vị diện tích cẩn thận: $100\\text{ cm}^2 = 100 \\times 10^{-4}\\text{ m}^2 = 0{,}01\\text{ m}^2$.`
          };
        }
      },
      {
        id: "p_p2_04",
        topic: "Vật lí hạt nhân - Phóng xạ và Phản ứng hạt nhân",
        generate: () => {
          return {
            content: `Hạt nhân Poloni $^{210}_{84}\\text{Po}$ đứng yên phóng xạ hạt $\\alpha$ biến đổi thành hạt nhân chì $^{206}_{82}\\text{Pb}$. Khối lượng các hạt: $m_{\\text{Po}} = 209{,}9828\\text{ u}$; $m_\\alpha = 4{,}0015\\text{ u}$; $m_{\\text{Pb}} = 205{,}9744\\text{ u}$. Lấy $1\\text{ u} = 931{,}5\\text{ MeV/}c^2$. Xét tính đúng/sai:`,
            statements: [
              { label: "a", text: "Phương trình phóng xạ là $^{210}_{84}\\text{Po} \\rightarrow \\text{ }^{4}_{2}\\alpha + \\text{ }^{206}_{82}\\text{Pb}$.", isCorrect: true, exp: "Bảo toàn số khối $210 = 4 + 206$; bảo toàn điện tích $84 = 2 + 82$. Mệnh đề ĐÚNG." },
              { label: "b", text: "Phản ứng phóng xạ này là phản ứng hạt nhân tỏa năng lượng.", isCorrect: true, exp: "Khối lượng trước phản ứng lớn hơn khối lượng sau phản ứng: $m_{\\text{trước}} - m_{\\text{sau}} = 209{,}9828 - (4{,}0015 + 205{,}9744) = 0{,}0069\\text{ u} > 0$. Vậy phản ứng tỏa năng lượng. Mệnh đề ĐÚNG." },
              { label: "c", text: "Năng lượng tỏa ra của một phân rã xấp xỉ bằng $6{,}43\\text{ MeV}$.", isCorrect: true, exp: "$\\Delta E = (m_{\\text{Po}} - m_\\alpha - m_{\\text{Pb}}) \\cdot c^2 = 0{,}0069 \\times 931{,}5 \\approx 6{,}427\\text{ MeV} \\approx 6{,}43\\text{ MeV}$. Mệnh đề ĐÚNG." },
              { label: "d", text: "Hạt $\\alpha$ sinh ra có động năng lớn hơn động năng của hạt nhân con chì $^{206}_{82}\\text{Pb}$.", isCorrect: true, exp: "Theo định luật bảo toàn động lượng: $p_\\alpha = p_{\\text{Pb}} \\Rightarrow 2 m_\\alpha K_\\alpha = 2 m_{\\text{Pb}} K_{\\text{Pb}} \\Rightarrow \\frac{K_\\alpha}{K_{\\text{Pb}}} = \\frac{m_{\\text{Pb}}}{m_\\alpha} \\approx \\frac{206}{4} \\approx 51{,}5$. Động năng hạt alpha lớn gấp hơn 51 lần hạt chì. Mệnh đề ĐÚNG." }
            ],
            theory: `Định luật bảo toàn số khối, bảo toàn điện tích, bảo toàn động lượng trong phản ứng hạt nhân. Năng lượng tỏa ra: $\\Delta E = (m_{\\text{trước}} - m_{\\text{sau}})c^2$. Hạt nhẹ hơn sẽ nhận phần lớn động năng.`,
            tips: `Casio 570: Nhập $(209.9828 - 4.0015 - 205.9744) \\times 931.5 \\Rightarrow 6.42735\\text{ MeV}$.`
          };
        }
      }
    ],

    templates_part3: [
      {
        id: "p_p3_01",
        topic: "Tính nhiệt lượng chuyển thể",
        generate: () => {
          const m = 0.5;
          const lambda = 3.34e5;
          const Q_kJ = (m * lambda / 1000).toFixed(0);
          return {
            content: `Tính nhiệt lượng cần thiết (theo đơn vị $\\text{kJ}$) để làm nóng chảy hoàn toàn $0{,}5\\text{ kg}$ nước đá ở $0^\\circ\\text{C}$. Biết nhiệt nóng chảy riêng của nước đá là $\\lambda = 3{,}34 \\cdot 10^5\\text{ J/kg}$. (Nhập số nguyên).`,
            correctAnswer: `${Q_kJ}`,
            theory: `Nhiệt lượng chuyển thể rắn - lỏng: $Q = \\lambda \\cdot m$. Đổi từ Joule sang kiloJoule: chia cho 1000.`,
            explanation: `$Q = 3{,}34 \\cdot 10^5 \\times 0{,}5 = 167000\\text{ J} = 167\\text{ kJ}$.`,
            tips: `Đọc kĩ yêu cầu đơn vị: Đề bài yêu cầu $\\text{kJ}$, cần chia cho 1000. Nếu điền 167000 sẽ bị sai.`
          };
        }
      },
      {
        id: "p_p3_02",
        topic: "Áp suất chất khí sau khi nén",
        generate: () => {
          const p1 = 100; // kPa
          const V1 = 4; // lit
          const V2 = 1.6; // lit
          const p2 = (p1 * V1 / V2).toFixed(0);
          return {
            content: `Một khối khí lí tưởng có thể tích $4\\text{ lít}$ ở áp suất $100\\text{ kPa}$. Nén đẳng nhiệt khối khí đến thể tích còn $1{,}6\\text{ lít}$. Áp suất của khối khí lúc này bằng bao nhiêu $\\text{kPa}$? (Nhập số nguyên).`,
            correctAnswer: `${p2}`,
            theory: `Định luật Boyle (đẳng nhiệt): $p_1 V_1 = p_2 V_2 \\Rightarrow p_2 = \\frac{p_1 V_1}{V_2}$.`,
            explanation: `$p_2 = \\frac{100 \\times 4}{1{,}6} = 250\\text{ kPa}$.`,
            tips: `Casio 570: Nhập $100 \\times 4 / 1.6 = 250$.`
          };
        }
      },
      {
        id: "p_p3_03",
        topic: "Tính lực từ tác dụng lên dây dẫn",
        generate: () => {
          const I = 4;
          const B = 0.5;
          const L = 0.8;
          const F = (B * I * L).toFixed(1);
          return {
            content: `Một đoạn dây dẫn dài $0{,}8\\text{ m}$ mang dòng điện $4\\text{ A}$ đặt vuông góc với vectơ cảm ứng từ của từ trường đều $B = 0{,}5\\text{ T}$. Tính lực từ tác dụng lên đoạn dây theo đơn vị Newton (N). (Nhập số thập phân).`,
            correctAnswer: `${F}`,
            theory: `Lực từ Am-pe: $F = BIL\\sin\\alpha$. Vì vuông góc nên $\\sin 90^\\circ = 1$.`,
            explanation: `$F = 0{,}5 \\times 4 \\times 0{,}8 \\times \\sin(90^\\circ) = 1{,}6\\text{ N}$.`,
            tips: `Bấm máy: $0.5 \\times 4 \\times 0.8 = 1.6$.`
          };
        }
      },
      {
        id: "p_p3_04",
        topic: "Tính suất điện động cảm ứng",
        generate: () => {
          const N = 50;
          const deltaPhi = 0.02; // Wb
          const deltaT = 0.05; // s
          const ec = (N * deltaPhi / deltaT).toFixed(0);
          return {
            content: `Một cuộn dây gồm $50$ vòng dây kín. Từ thông qua mỗi vòng dây biến thiên đều đặn một lượng $0{,}02\\text{ Wb}$ trong thời gian $0{,}05\\text{ s}$. Độ lớn suất điện động cảm ứng xuất hiện trong cuộn dây là bao nhiêu Vôn (V)? (Nhập số nguyên).`,
            correctAnswer: `${ec}`,
            theory: `Định luật Faraday cho cuộn dây $N$ vòng: $|e_c| = N \\cdot \\frac{|\\Delta\\Phi|}{\\Delta t}$.`,
            explanation: `$|e_c| = 50 \\times \\frac{0{,}02}{0{,}05} = 50 \\times 0{,}4 = 20\\text{ V}$.`,
            tips: `Nhớ nhân thêm số vòng dây $N = 50$. Nếu chỉ tính cho 1 vòng sẽ bị thiếu.`
          };
        }
      },
      {
        id: "p_p3_05",
        topic: "Năng lượng liên kết riêng của hạt nhân",
        generate: () => {
          const deltaM = 0.0304; // u
          const A = 4; // Heli
          const Elkr = (deltaM * 931.5 / A).toFixed(2);
          return {
            content: `Hạt nhân Heli $^{4}_{2}\\text{He}$ có độ hụt khối $\\Delta m = 0{,}0304\\text{ u}$. Lấy $1\\text{ u} = 931{,}5\\text{ MeV/}c^2$. Năng lượng liên kết riêng của hạt nhân $^{4}_{2}\\text{He}$ bằng bao nhiêu $\\text{MeV/nucleon}$? (Làm tròn đến chữ số thập phân thứ hai).`,
            correctAnswer: `${Elkr}`,
            theory: `Năng lượng liên kết riêng: $E_{\\text{lkr}} = \\frac{\\Delta E}{A} = \\frac{\\Delta m \\cdot c^2}{A}$. Đặc trưng cho mức độ bền vững của hạt nhân.`,
            explanation: `Năng lượng liên kết: $\\Delta E = 0{,}0304 \\times 931{,}5 = 28{,}3176\\text{ MeV}$. Năng lượng liên kết riêng: $E_{\\text{lkr}} = \\frac{28{,}3176}{4} = 7{,}0794 \\approx 7{,}08\\text{ MeV/nucleon}$.`,
            tips: `Casio 570: Nhập $(0.0304 \\times 931.5) / 4 \\Rightarrow 7.0794 \\approx 7.08$.`
          };
        }
      },
      {
        id: "p_p3_06",
        topic: "Khối lượng phóng xạ còn lại",
        generate: () => {
          const m0 = 16;
          const T = 8;
          const t = 24;
          const m = (m0 * Math.pow(2, -t / T)).toFixed(0);
          return {
            content: `Ban đầu có $16\\text{ gam}$ chất phóng xạ I-ốt $^{131}_{53}\\text{I}$ với chu kì bán rã $8\\text{ ngày}$. Khối lượng chất phóng xạ này còn lại sau $24\\text{ ngày}$ là bao nhiêu gam? (Nhập số nguyên).`,
            correctAnswer: `${m}`,
            theory: `Khối lượng chất phóng xạ còn lại sau thời gian $t$: $m(t) = m_0 \\cdot 2^{-t/T}$.`,
            explanation: `Số chu kì bán rã đã trải qua: $k = \\frac{t}{T} = \\frac{24}{8} = 3$. Khối lượng còn lại: $m = 16 \\times 2^{-3} = \\frac{16}{8} = 2\\text{ gam}$.`,
            tips: `Nhẩm nhanh: 16g $\\rightarrow$ sau 8 ngày còn 8g $\\rightarrow$ sau 16 ngày còn 4g $\\rightarrow$ sau 24 ngày còn 2g.`
          };
        }
      }
    ]
  },

  // =======================================================================
  // 3. MÔN HÓA HỌC (50 PHÚT - 28 CÂU HỎI - THANG ĐIỂM 10.0)
  // Phần I: 18 câu (4.5đ) | Phần II: 4 câu (4.0đ) | Phần III: 6 câu (1.5đ)
  // Bám sát chuẩn SGK GDPT 2018 (Ester-Lipid, Carbohydrate, Amine-Amino acid,
  // Polime, Pin điện hóa & Thế điện cực chuẩn, Cân bằng hóa học, Phức chất)
  // =======================================================================
  hoa: {
    duration: 50,
    part1_count: 18,
    part2_count: 4,
    part3_count: 6,
    templates_part1: [
      {
        id: "c_p1_01",
        topic: "Ester - Cấu tạo và Công thức tổng quát",
        generate: () => {
          return {
            content: `Công thức phân tử tổng quát của ester no, đơn chức, mạch hở là:`,
            options: [`$\\text{C}_n\\text{H}_{2n}\\text{O}_2\\text{ }(n \\ge 2)$`, `$\\text{C}_n\\text{H}_{2n-2}\\text{O}_2\\text{ }(n \\ge 3)$`, `$\\text{C}_n\\text{H}_{2n}\\text{O}\\text{ }(n \\ge 1)$`, `$\\text{C}_n\\text{H}_{2n+2}\\text{O}_2\\text{ }(n \\ge 1)$`],
            correctIndex: 0,
            theory: `Ester no, đơn chức, mạch hở được tạo từ carboxylic acid no đơn chức và alcohol no đơn chức, có độ bất bão hòa $k = 1$ (chứa 1 liên kết đôi $C=O$). Công thức phân tử: $\\text{C}_n\\text{H}_{2n}\\text{O}_2$ với $n \\ge 2$.`,
            explanation: `Ester đơn chức có 2 nguyên tử O. Vì no mạch hở nên gốc hydrocarbon có dạng $\\text{C}_n\\text{H}_{2n}$. Nhỏ nhất là methyl formate $\\text{HCOOCH}_3$ ($n = 2$).`,
            tips: `Ester no đơn chức đồng phân nhóm chức với Carboxylic acid no đơn chức (cùng CTPT $\\text{C}_n\\text{H}_{2n}\\text{O}_2$).`
          };
        }
      },
      {
        id: "c_p1_02",
        topic: "Danh pháp Ester theo IUPAC",
        generate: () => {
          return {
            content: `Ester có công thức cấu tạo thu gọn $\\text{CH}_3\\text{COOC}_2\\text{H}_5$ có tên gọi theo danh pháp quốc tế là:`,
            options: [`Ethyl acetate`, `Methyl propionate`, `Ethyl formate`, `Propyl acetate`],
            correctIndex: 0,
            theory: `Quy tắc gọi tên ester: Tên gốc hydrocarbon $R'$ (gắn với nguyên tử O) + Tên gốc acid $RCOO^-$ (đuôi 'ate').`,
            explanation: `Gốc $R'$ là $-\\text{C}_2\\text{H}_5$ (ethyl). Gốc acid là $\\text{CH}_3\\text{COO}-$ (acetate hoặc ethanoate). Vậy tên là Ethyl acetate (ethyl ethanoate).`,
            tips: `Đọc tên từ đuôi lên đầu: đọc gốc ancol trước ($-\\text{C}_2\\text{H}_5$: ethyl), rồi mới đọc gốc acid ($\text{CH}_3\\text{COO}-$: acetate).`
          };
        }
      },
      {
        id: "c_p1_03",
        topic: "Phản ứng xà phòng hóa Ester",
        generate: () => {
          return {
            content: `Thủy phân hoàn toàn ethyl formate $\\text{HCOOC}_2\\text{H}_5$ trong dung dịch $\\text{NaOH}$ đun nóng thu được muối nào sau đây?`,
            options: [`$\\text{HCOONa}$`, `$\\text{CH}_3\\text{COONa}$`, `$\\text{C}_2\\text{H}_5\\text{COONa}$`, `$\\text{C}_2\\text{H}_5\\text{ONa}$`],
            correctIndex: 0,
            theory: `Phản ứng xà phòng hóa: $RCOOR' + \\text{NaOH} \\xrightarrow{t^\\circ} RCOONa + R'OH$. Phản ứng là một chiều.`,
            explanation: `$\\text{HCOOC}_2\\text{H}_5 + \\text{NaOH} \\xrightarrow{t^\\circ} \\text{HCOONa} + \\text{C}_2\\text{H}_5\\text{OH}$. Muối thu được là sodium formate $\\text{HCOONa}$.`,
            tips: `Cắt đứt liên kết giữa nhóm $C=O$ và $O$: phần acid nhận nhóm $-ONa$ tạo muối, phần alcohol nhận nhóm $-H$ tạo alcohol.`
          };
        }
      },
      {
        id: "c_p1_04",
        topic: "Chất béo (Lipid) - Tristearin",
        generate: () => {
          return {
            content: `Chất béo tristearin có công thức cấu tạo thu gọn là:`,
            options: [`$(\\text{C}_{17}\\text{H}_{35}\\text{COO})_3\\text{C}_3\\text{H}_5$`, `$(\\text{C}_{17}\\text{H}_{33}\\text{COO})_3\\text{C}_3\\text{H}_5$`, `$(\\text{C}_{15}\\text{H}_{31}\\text{COO})_3\\text{C}_3\\text{H}_5$`, `$(\\text{C}_{17}\\text{H}_{31}\\text{COO})_3\\text{C}_3\\text{H}_5$`],
            correctIndex: 0,
            theory: `Tristearin là triester của glycerol với stearic acid (acid no $\\text{C}_{17}\\text{H}_{35}\\text{COOH}$). Triolein: $(\\text{C}_{17}\\text{H}_{33}\\text{COO})_3\\text{C}_3\\text{H}_5$; Tripalmitin: $(\\text{C}_{15}\\text{H}_{31}\\text{COO})_3\\text{C}_3\\text{H}_5$.`,
            explanation: `Tristearin có công thức $(\\text{C}_{17}\\text{H}_{35}\\text{COO})_3\\text{C}_3\\text{H}_5$, là chất béo no, ở trạng thái rắn tại điều kiện thường (mỡ động vật).`,
            tips: `Nhớ 3 acid béo quen thuộc: Palmitic (15-31), Stearic (17-35, no), Oleic (17-33, có 1 nối đôi C=C).`
          };
        }
      },
      {
        id: "c_p1_05",
        topic: "Carbohydrate - Cấu trúc phân tử Glucose",
        generate: () => {
          return {
            content: `Ở dạng mạch hở, phân tử glucose chứa nhóm chức nào sau đây?`,
            options: [
              `1 nhóm aldehyde $(-\\text{CHO})$ và 5 nhóm alcohol $(-\\text{OH})$`,
              `1 nhóm ketone $(-\\text{CO}-)$ và 5 nhóm alcohol $(-\\text{OH})$`,
              `1 nhóm carboxyl $(-\\text{COOH})$ và 4 nhóm alcohol $(-\\text{OH})$`,
              `Chỉ chứa các nhóm chức alcohol bậc một`
            ],
            correctIndex: 0,
            theory: `Glucose có công thức cấu tạo dạng mạch hở: $\\text{CH}_2\\text{OH}-(\\text{CHOH})_4-\\text{CHO}$. Đây là một hợp chất tạp chức (aldehyde đơn chức và polyalcohol).`,
            explanation: `Phân tử glucose dạng mạch hở chứa một nhóm aldehyde ở vị trí carbon C1 và 5 nhóm hydroxyl ($-OH$) ở các carbon còn lại.`,
            tips: `Glucose có nhóm $-CHO$ nên tráng bạc được; Fructose có nhóm ketone $-CO-$ nhưng trong môi trường kiềm chuyển hóa thành glucose nên cũng tráng bạc.`
          };
        }
      },
      {
        id: "c_p1_06",
        topic: "Phản ứng tráng bạc của Glucose",
        generate: () => {
          return {
            content: `Khi cho glucose tác dụng hoàn toàn với lượng dư thuốc thử Tollens $[\\text{Ag}(\\text{NH}_3)_2]\\text{OH}$, tỉ lệ mol giữa glucose và bạc (Ag) kết tủa tạo thành là:`,
            options: [`$1 : 2$`, `$1 : 1$`, `$1 : 4$`, `$2 : 1$`],
            correctIndex: 0,
            theory: `Mỗi nhóm chức aldehyde $(-\\text{CHO})$ khi tham gia phản ứng tráng bạc khử 2 ion $\\text{Ag}^+$ thành 2 nguyên tử $\\text{Ag}$: $\\text{R-CHO} + 2\\text{Ag}^+ + \\dots \\rightarrow 2\\text{Ag}\\downarrow$.`,
            explanation: `Glucose có 1 nhóm $-CHO$ ở đầu mạch, do đó $1\\text{ mol glucose} \\rightarrow 2\\text{ mol Ag}$.`,
            tips: `Dùng Casio giải bài toán tráng bạc: $n_{\\text{Ag}} = 2 \\times n_{\\text{glucose}}$. Khối lượng kết tủa $m_{\\text{Ag}} = 2 \\times 108 \\times n_{\\text{glucose}} = 216 \\cdot n_{\\text{glucose}}$.`
          };
        }
      },
      {
        id: "c_p1_07",
        topic: "Carbohydrate - Thủy phân Tinh bột và Cellulose",
        generate: () => {
          return {
            content: `Khi thủy phân hoàn toàn tinh bột hoặc cellulose trong môi trường acid có đun nóng, sản phẩm cuối cùng thu được là:`,
            options: [`Glucose`, `Fructose`, `Sucrose`, `Maltose`],
            correctIndex: 0,
            theory: `Cả tinh bột $(\\text{C}_6\\text{H}_{10}\\text{O}_5)_n$ và cellulose $(\\text{C}_6\\text{H}_{10}\\text{O}_5)_m$ đều là polysaccharide, khi thủy phân hoàn toàn trong môi trường acid đều cho sản phẩm duy nhất là glucose.`,
            explanation: `$(\\text{C}_6\\text{H}_{10}\\text{O}_5)_n + n\\text{H}_2\\text{O} \\xrightarrow{H^+, t^\\circ} n\\text{C}_6\\text{H}_{12}\\text{O}_6$ (glucose).`,
            tips: `Tinh bột tạo bởi các mắt xích $\\alpha$-glucose; cellulose tạo bởi các mắt xích $\\beta$-glucose. Nhưng sản phẩm thủy phân cuối cùng đều là glucose.`
          };
        }
      },
      {
        id: "c_p1_08",
        topic: "Amin - Bậc của amin",
        generate: () => {
          return {
            content: `Chất nào sau đây là amin bậc hai?`,
            options: [`$\\text{CH}_3-\\text{NH}-\\text{CH}_3$`, `$\\text{CH}_3\\text{NH}_2$`, `$(\\text{CH}_3)_3\\text{N}$`, `$\\text{C}_2\\text{H}_5\\text{NH}_2$`],
            correctIndex: 0,
            theory: `Bậc của amin là số nguyên tử H trong phân tử $\\text{NH}_3$ bị thay thế bởi gốc hydrocarbon. Bậc 1: $R-\\text{NH}_2$; Bậc 2: $R-\\text{NH}-R'$; Bậc 3: $R-\\text{N}(R')-R''$.`,
            explanation: `$\\text{CH}_3-\\text{NH}-\\text{CH}_3$ (dimethylamine) có 2 gốc methyl thay thế 2 nguyên tử H của amoniac, do đó là amin bậc hai.`,
            tips: `Bẫy: Bậc của amin khác hoàn toàn bậc của alcohol (bậc alcohol tính theo bậc của nguyên tử C gắn với nhóm -OH). Bậc amin tính theo số gốc gắn vào N.`
          };
        }
      },
      {
        id: "c_p1_09",
        topic: "Amino acid - Tính lưỡng tính của Glycine",
        generate: () => {
          return {
            content: `Dung dịch chất nào sau đây vừa tác dụng được với dung dịch $\\text{HCl}$, vừa tác dụng được với dung dịch $\\text{NaOH}$?`,
            options: [`$\\text{H}_2\\text{N}-\\text{CH}_2-\\text{COOH}$ (Glycine)`, `$\\text{CH}_3\\text{COOH}$`, `$\\text{C}_2\\text{H}_5\\text{NH}_2$`, `$\\text{CH}_3\\text{COOCH}_3$`],
            correctIndex: 0,
            theory: `Amino acid chứa cả nhóm chức base $(-\\text{NH}_2)$ và nhóm chức acid $(-\\text{COOH})$ nên có tính chất lưỡng tính (amphoteric).`,
            explanation: `Glycine tác dụng với acid $\\text{HCl}$ qua nhóm $-\\text{NH}_2$, tác dụng với base $\\text{NaOH}$ qua nhóm $-\\text{COOH}$.`,
            tips: `Mọi $\\alpha$-amino acid đều có tính lưỡng tính. Dung dịch Glycine, Alanine có số nhóm $-\\text{NH}_2$ bằng số nhóm $-\\text{COOH}$ nên quỳ tím không đổi màu.`
          };
        }
      },
      {
        id: "c_p1_10",
        topic: "Peptide - Phản ứng màu Biuret",
        generate: () => {
          return {
            content: `Hợp chất nào sau đây KHÔNG cho phản ứng màu biuret với thuốc thử $\\text{Cu(OH)}_2$?`,
            options: [`Dipeptide Gly-Ala`, `Tripeptide Gly-Ala-Val`, `Tetrapeptide Ala-Gly-Gly-Val`, `Lòng trắng trứng (Albumin)`],
            correctIndex: 0,
            theory: `Quy tắc phản ứng Biuret: Các peptide có từ 2 liên kết peptide trở lên (tức là tripeptide trở lên) và protein mới có phản ứng màu biuret (tạo phức màu tím đặc trưng với $\\text{Cu(OH)}_2$). Dipeptide không có phản ứng này.`,
            explanation: `Dipeptide Gly-Ala chỉ có 1 liên kết peptide ($-CONH-$), do đó không đủ điều kiện tạo phức biuret màu tím với $\\text{Cu(OH)}_2$.`,
            tips: `Ghi nhớ điều kiện phản ứng Biuret: Phải từ TRIPEPTIDE trở lên (chứa $\\ge 2$ liên kết peptide). Dipeptide bị loại trừ.`
          };
        }
      },
      {
        id: "c_p1_11",
        topic: "Polymer - Phản ứng trùng hợp",
        generate: () => {
          return {
            content: `Polymer nào sau đây được điều chế bằng phản ứng trùng hợp?`,
            options: [`Polyethylene (PE)`, `Nylon-6,6`, `Tơ lapsan`, `Keo dán ure-formaldehyde`],
            correctIndex: 0,
            theory: `Phản ứng trùng hợp là quá trình kết hợp nhiều phân tử nhỏ (monomer) giống nhau hay tương tự nhau thành phân tử lớn (polymer). Điều kiện: monomer phải chứa liên kết đôi $C=C$ hoặc vòng kém bền.`,
            explanation: `Ethylene $\\text{CH}_2=\\text{CH}_2$ chứa liên kết đôi kém bền, tham gia phản ứng trùng hợp tạo ra polyethylene (PE): $n\\text{CH}_2=\\text{CH}_2 \\xrightarrow{t^\\circ, p, xt} -(\\text{CH}_2-\\text{CH}_2)_n-$. Nylon-6,6 và lapsan được điều chế bằng phản ứng trùng ngưng.`,
            tips: `Trùng hợp: monomer có nối đôi $C=C$ (PE, PVC, cao su Buna, tơ olon). Trùng ngưng: monomer có $\\ge 2$ nhóm chức phản ứng giải phóng phân tử nhỏ như $H_2O$ (Nylon-6,6).`
          };
        }
      },
      {
        id: "c_p1_12",
        topic: "Đại cương kim loại - Tính chất vật lý chung",
        generate: () => {
          return {
            content: `Tính chất vật lý chung của kim loại (dẫn điện, dẫn nhiệt, tính dẻo, ánh kim) gây nên chủ yếu bởi:`,
            options: [
              `Các electron tự do trong mạng tinh thể kim loại`,
              `Các ion dương kim loại ở nút mạng`,
              `Liên kết ion giữa các nguyên tử`,
              `Khối lượng riêng lớn của các nguyên tử kim loại`
            ],
            correctIndex: 0,
            theory: `Theo thuyết miền electron: Kim loại gồm các ion dương dao động tại nút mạng và các electron tự do chuyển động hỗn loạn. Chính sự có mặt của các electron tự do gây nên 4 tính chất vật lý chung.`,
            explanation: `Các electron tự do chuyển động có hướng tạo nên dòng điện (dẫn điện); truyền động năng tạo nên tính dẫn nhiệt; giúp các lớp mạng trượt lên nhau mà không gãy vỡ tạo tính dẻo; phản xạ ánh sáng tạo ánh kim.`,
            tips: `Kim loại dẫn điện tốt nhất: Bạc (Ag) > Đồng (Cu) > Vàng (Au) > Nhôm (Al) > Sắt (Fe). 'Bóng đồng vàng nhôm sắt'.`
          };
        }
      },
      {
        id: "c_p1_13",
        topic: "Dãy điện hóa kim loại - Quy tắc alpha",
        generate: () => {
          return {
            content: `Cho các kim loại: $\\text{Fe}, \\text{Cu}, \\text{Ag}, \\text{Al}$. Kim loại có tính khử mạnh nhất là:`,
            options: [`$\\text{Al}$`, `$\\text{Fe}$`, `$\\text{Cu}$`, `$\\text{Ag}$`],
            correctIndex: 0,
            theory: `Thứ tự tính khử giảm dần trong dãy điện hóa: $\\text{K} > \\text{Na} > \\text{Mg} > \\text{Al} > \\text{Zn} > \\text{Fe} > \\dots > \\text{Cu} > \\text{Ag} > \\text{Au}$.`,
            explanation: `Trong 4 kim loại trên, nhôm $(\\text{Al})$ đứng trước nhất trong dãy điện hóa nên có tính khử mạnh nhất. Bạc $(\\text{Ag})$ đứng sau nhất nên có tính khử yếu nhất.`,
            tips: `Thuộc câu vè: 'Khi nào may áo giáp sắt nhớ sang phố hỏi cửa hàng á phi âu'. Kim loại đứng càng trước tính khử càng mạnh.`
          };
        }
      },
      {
        id: "c_p1_14",
        topic: "Pin điện hóa Galvani - Chuẩn BGD 2025",
        generate: () => {
          return {
            content: `Biết thế điện cực chuẩn $E^\\circ_{\\text{Zn}^{2+}/\\text{Zn}} = -0{,}76\\text{ V}$ và $E^\\circ_{\\text{Cu}^{2+}/\\text{Cu}} = +0{,}34\\text{ V}$. Sức điện động chuẩn $E^\\circ_{\\text{pin}}$ của pin Galvani Zn - Cu là:`,
            options: [`$1{,}10\\text{ V}$`, `$0{,}42\\text{ V}$`, `$-1{,}10\\text{ V}$`, `$0{,}55\\text{ V}$`],
            correctIndex: 0,
            theory: `Công thức sức điện động chuẩn của pin điện hóa: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{catot}} - E^\\circ_{\\text{anot}} = E^\\circ_{\\text{dương}} - E^\\circ_{\\text{âm}}$. Điện cực có thế lớn hơn là catot (dương).`,
            explanation: `Ta có $E^\\circ_{\\text{Cu}^{2+}/\\text{Cu}} = +0{,}34\\text{ V} > E^\\circ_{\\text{Zn}^{2+}/\\text{Zn}} = -0{,}76\\text{ V}$. Do đó cực Cu là catot $(+)$, cực Zn là anot $(-)$. Sức điện động: $E^\\circ_{\\text{pin}} = +0{,}34 - (-0{,}76) = 1{,}10\\text{ V}$.`,
            tips: `Sức điện động của pin điện luôn luôn dương ($E^\\circ_{\\text{pin}} > 0$). Luôn lấy số lớn trừ số bé: $(+0.34) - (-0.76) = 1.10\\text{ V}$.`
          };
        }
      },
      {
        id: "c_p1_15",
        topic: "Hóa học phức chất - Trọng tâm mới 2025",
        generate: () => {
          return {
            content: `Trong ion phức chất $[\\text{Cu}(\\text{H}_2\\text{O})_4]^{2+}$, phối tử (ligand) là phân tử nào?`,
            options: [`$\\text{H}_2\\text{O}$`, `$\\text{Cu}^{2+}$`, `$\\text{OH}^-$`, `$\\text{O}^{2-}$`],
            correctIndex: 0,
            theory: `Cấu tạo phức chất: Gồm nguyên tử trung tâm (thường là ion kim loại chuyển tiếp có orbital trống) và các phối tử (phân tử hoặc anion có cặp electron chưa liên kết cho vào nguyên tử trung tâm).`,
            explanation: `Ion $\\text{Cu}^{2+}$ đóng vai trò nguyên tử trung tâm nhận cặp electron; 4 phân tử $\\text{H}_2\\text{O}$ đóng vai trò là các phối tử (ligand).`,
            tips: `Phức chất là nội dung mới xuất hiện trong kỳ thi THPTQG từ 2025: Ion kim loại ở giữa gọi là nguyên tử trung tâm, các phân tử/ion xung quanh là phối tử.`
          };
        }
      },
      {
        id: "c_p1_16",
        topic: "Cân bằng hóa học - Nguyên lí Le Chatelier",
        generate: () => {
          return {
            content: `Cho phản ứng thuận nghịch: $\\text{N}_2\\text{(k)} + 3\\text{H}_2\\text{(k)} \\rightleftharpoons 2\\text{NH}_3\\text{(k)};\\text{ }\\Delta_r H^\\circ_{298} = -92\\text{ kJ}$. Để cân bằng chuyển dịch theo chiều thuận (tạo ra nhiều $\\text{NH}_3$ hơn), cần:`,
            options: [
              `Tăng áp suất và giảm nhiệt độ`,
              `Giảm áp suất và tăng nhiệt độ`,
              `Tăng nhiệt độ và giữ nguyên áp suất`,
              `Sử dụng thêm chất xúc tác bột sắt`
            ],
            correctIndex: 0,
            theory: `Nguyên lí chuyển dịch cân bằng Le Chatelier: Một hệ đang ở trạng thái cân bằng nếu chịu một tác động từ bên ngoài (nhiệt độ, áp suất, nồng độ) thì cân bằng sẽ chuyển dịch theo chiều chống lại tác động đó.`,
            explanation: `Phản ứng tỏa nhiệt $(\\Delta H < 0)$, muốn chuyển dịch theo chiều thuận cần giảm nhiệt độ. Phía trước có 4 mol khí, phía sau có 2 mol khí (giảm số mol khí), muốn chuyển dịch theo chiều thuận cần tăng áp suất. Chất xúc tác không làm chuyển dịch cân bằng.`,
            tips: `Nhớ khẩu quyết Le Chatelier: Tăng nhiệt dịch chiều thu $(\\Delta H > 0)$, giảm nhiệt dịch chiều tỏa $(\\Delta H < 0)$. Tăng áp suất dịch về phía ít mol khí hơn.`
          };
        }
      },
      {
        id: "c_p1_17",
        topic: "Hằng số cân bằng hóa học Kc",
        generate: () => {
          return {
            content: `Biểu thức tính hằng số cân bằng $K_C$ của phản ứng $\\text{N}_2\\text{(k)} + 3\\text{H}_2\\text{(k)} \\rightleftharpoons 2\\text{NH}_3\\text{(k)}$ ở trạng thái cân bằng là:`,
            options: [
              `$K_C = \\frac{[\\text{NH}_3]^2}{[\\text{N}_2][\\text{H}_2]^3}$`,
              `$K_C = \\frac{[\\text{N}_2][\\text{H}_2]^3}{[\\text{NH}_3]^2}$`,
              `$K_C = \\frac{2[\\text{NH}_3]}{[\\text{N}_2] + 3[\\text{H}_2]}$`,
              `$K_C = \\frac{[\\text{NH}_3]}{[\\text{N}_2][\\text{H}_2]}$`
            ],
            correctIndex: 0,
            theory: `Biểu thức $K_C$ cho phản ứng $aA + bB \\rightleftharpoons cC + dD$ là $K_C = \\frac{[C]^c [D]^d}{[A]^a [B]^b}$. Hệ số tỉ lượng biến thành số mũ. Chỉ tính nồng độ của chất khí và chất tan trong dung dịch, không tính chất rắn.`,
            explanation: `Sản phẩm là $\\text{NH}_3$ có hệ số 2 nên tử số là $[\\text{NH}_3]^2$. Chất phản ứng là $\\text{N}_2$ (hệ số 1) và $\\text{H}_2$ (hệ số 3) nên mẫu số là $[\\text{N}_2][\\text{H}_2]^3$.`,
            tips: `Hệ số đứng trước chất nào thì trở thành lũy thừa của nồng độ chất đó trong biểu thức $K_C$.`
          };
        }
      },
      {
        id: "c_p1_18",
        topic: "Nhiệt phản ứng - Biến thiên Enthalpy",
        generate: () => {
          return {
            content: `Phản ứng tỏa nhiệt là phản ứng có biến thiên enthalpy chuẩn thỏa mãn điều kiện nào sau đây?`,
            options: [`$\\Delta_r H^\\circ_{298} < 0$`, `$\\Delta_r H^\\circ_{298} > 0$`, `$\\Delta_r H^\\circ_{298} = 0$`, `$\\Delta_r H^\\circ_{298} \\ge 100\\text{ kJ}$`],
            correctIndex: 0,
            theory: `Nhiệt hóa học SGK 2025: Phản ứng tỏa nhiệt (giải phóng năng lượng ra môi trường) có $\\Delta_r H^\\circ_{298} < 0$. Phản ứng thu nhiệt (hấp thụ năng lượng) có $\\Delta_r H^\\circ_{298} > 0$.`,
            explanation: `Kí hiệu dấu của biến thiên enthalpy: Tỏa nhiệt $\\Delta_r H < 0$; Thu nhiệt $\\Delta_r H > 0$.`,
            tips: `Quy tắc nhớ nhanh: 'Tỏa âm, Thu dương'. Ví dụ phản ứng cháy luôn là phản ứng tỏa nhiệt $(\\Delta H < 0)$.`
          };
        }
      }
    ],

    templates_part2: [
      {
        id: "c_p2_01",
        topic: "Thí nghiệm điều chế Ethyl acetate trong phòng thí nghiệm",
        generate: () => {
          return {
            content: `Tiến hành thí nghiệm điều chế ethyl acetate: Cho $2\\text{ mL}$ ethanol, $2\\text{ mL}$ acetic acid nguyên chất và vài giọt $\\text{H}_2\\text{SO}_4$ đặc vào ống nghiệm. Lắc đều, đun cách thủy trong nồi nước sôi khoảng $5 - 7\\text{ phút}$. Làm lạnh, sau đó thêm $2\\text{ mL}$ dung dịch $\\text{NaCl}$ bão hòa. Xét tính đúng/sai:`,
            statements: [
              { label: "a", text: "Acid $\\text{H}_2\\text{SO}_4$ đặc đóng vai trò vừa là chất xúc tác, vừa có tác dụng hút nước để cân bằng chuyển dịch theo chiều thuận.", isCorrect: true, exp: "$\\text{H}_2\\text{SO}_4$ đặc có tính háo nước mạnh, hút $\\text{H}_2\\text{O}$ sinh ra làm cân bằng chuyển dịch sang phía tạo ester và làm tăng tốc độ phản ứng. Mệnh đề ĐÚNG." },
              { label: "b", text: "Sau khi thêm dung dịch $\\text{NaCl}$ bão hòa, chất lỏng trong ống nghiệm tách thành hai lớp.", isCorrect: true, exp: "Ethyl acetate ít tan trong nước và có khối lượng riêng nhỏ hơn dung dịch $\\text{NaCl}$, do đó nổi lên trên tạo thành lớp chất lỏng phân tách rõ rệt. Mệnh đề ĐÚNG." },
              { label: "c", text: "Dung dịch $\\text{NaCl}$ bão hòa được thêm vào nhằm mục đích hòa tan hoàn toàn lượng ester sinh ra.", isCorrect: false, exp: "Mục đích thêm dung dịch $\\text{NaCl}$ bão hòa là làm tăng khối lượng riêng của lớp dung dịch phía dưới và giảm độ tan của ethyl acetate, giúp ester tách lớp dễ dàng hơn. Mệnh đề SAI." },
              { label: "d", text: "Phản ứng este hóa giữa ethanol và acetic acid là phản ứng thuận nghịch, không bao giờ đạt hiệu suất $100\\%$.", isCorrect: true, exp: "Phản ứng este hóa giữa alcohol và carboxylic acid là phản ứng thuận nghịch hai chiều. Mệnh đề ĐÚNG." }
            ],
            theory: `Thí nghiệm este hóa: $\\text{CH}_3\\text{COOH} + \\text{C}_2\\text{H}_5\\text{OH} \\xrightleftharpoons{\\text{H}_2\\text{SO}_4\\text{ đặc}, t^\\circ} \\text{CH}_3\\text{COOC}_2\\text{H}_5 + \\text{H}_2\\text{O}$. Vai trò của $\\text{H}_2\\text{SO}_4$ đặc là xúc tác và hút nước; $\\text{NaCl}$ bão hòa giúp tách lớp ester mùi thơm hoa quả.`,
            tips: `Bẫy kinh điển câu c: Rất nhiều câu hỏi trắc nghiệm BGD hỏi vai trò của $\\text{NaCl}$ bão hòa. Nhớ kĩ: $\\text{NaCl}$ giúp ester tách lớp tốt hơn chứ KHÔNG PHẢI để hòa tan ester!`
          };
        }
      },
      {
        id: "c_p2_02",
        topic: "Cân bằng hóa học và Hằng số Kc",
        generate: () => {
          return {
            content: `Xét phản ứng tổng hợp amoniac trong bình kín: $\\text{N}_2\\text{(k)} + 3\\text{H}_2\\text{(k)} \\rightleftharpoons 2\\text{NH}_3\\text{(k)};\\text{ }\\Delta_r H^\\circ_{298} = -92\\text{ kJ}$. Ở nhiệt độ $450^\\circ\\text{C}$ và áp suất $200\\text{ bar}$, nồng độ mol tại trạng thái cân bằng của các chất là $[\\text{N}_2] = 0{,}5\\text{ M}$; $[\\text{H}_2] = 1{,}0\\text{ M}$; $[\\text{NH}_3] = 0{,}4\\text{ M}$. Xét tính đúng/sai:`,
            statements: [
              { label: "a", text: "Hằng số cân bằng $K_C$ của phản ứng ở nhiệt độ này có giá trị bằng $0{,}32$.", isCorrect: true, exp: "$K_C = \\frac{[\\text{NH}_3]^2}{[\\text{N}_2][\\text{H}_2]^3} = \\frac{(0{,}4)^2}{0{,}5 \\times (1{,}0)^3} = \\frac{0{,}16}{0{,}5} = 0{,}32$. Mệnh đề ĐÚNG." },
              { label: "b", text: "Nếu tăng nhiệt độ của hệ lên $600^\\circ\\text{C}$ thì hằng số cân bằng $K_C$ sẽ tăng lên.", isCorrect: false, exp: "Vì phản ứng tỏa nhiệt $(\\Delta H < 0)$, khi tăng nhiệt độ cân bằng chuyển dịch theo chiều nghịch (thu nhiệt) $\\Rightarrow$ nồng độ $\\text{NH}_3$ giảm $\\Rightarrow K_C$ giảm. Mệnh đề SAI." },
              { label: "c", text: "Thêm chất xúc tác bột sắt $(\\text{Fe})$ làm tăng nồng độ của $\\text{NH}_3$ tại trạng thái cân bằng.", isCorrect: false, exp: "Chất xúc tác chỉ làm tăng tốc độ phản ứng thuận và nghịch như nhau (giúp hệ nhanh đạt tới trạng thái cân bằng), không làm thay đổi nồng độ các chất ở trạng thái cân bằng. Mệnh đề SAI." },
              { label: "d", text: "Nén bình để thể tích giảm đi một nửa thì cân bằng sẽ chuyển dịch theo chiều thuận.", isCorrect: true, exp: "Khi thể tích giảm đi một nửa, áp suất tăng gấp đôi. Cân bằng chuyển dịch theo chiều làm giảm áp suất (chiều giảm số mol khí: từ 4 mol khí về 2 mol khí, tức là chiều thuận). Mệnh đề ĐÚNG." }
            ],
            theory: `Hằng số cân bằng $K_C$ chỉ phụ thuộc vào bản chất phản ứng và nhiệt độ, không phụ thuộc vào nồng độ, áp suất hay chất xúc tác. Định luật Le Chatelier chi phối hướng chuyển dịch.`,
            tips: `Casio 570: Bấm $0.4^2 / (0.5 \\times 1^3) = 0.32$. Nhớ: Chất xúc tác KHÔNG BAO GIỜ làm thay đổi $K_C$ và nồng độ cân bằng.`
          };
        }
      },
      {
        id: "c_p2_03",
        topic: "Pin điện hóa Zn - Cu (Galvani)",
        generate: () => {
          return {
            content: `Thiết lập pin điện hóa Galvani gồm thanh kẽm $(\\text{Zn})$ nhúng trong dung dịch $\\text{ZnSO}_4\\text{ 1M}$ và thanh đồng $(\\text{Cu})$ nhúng trong dung dịch $\\text{CuSO}_4\\text{ 1M}$, nối với nhau bằng cầu muối chứa dung dịch $\\text{KCl}$ bão hòa. Cho $E^\\circ_{\\text{Zn}^{2+}/\\text{Zn}} = -0{,}76\\text{ V}$ và $E^\\circ_{\\text{Cu}^{2+}/\\text{Cu}} = +0{,}34\\text{ V}$. Xét tính đúng/sai:`,
            statements: [
              { label: "a", text: "Thanh kẽm đóng vai trò là cực âm (anot), tại đây xảy ra quá trình oxi hóa kẽm: $\\text{Zn} \\rightarrow \\text{Zn}^{2+} + 2e$.", isCorrect: true, exp: "Kẽm có thế điện cực chuẩn âm hơn nên có tính khử mạnh hơn, đóng vai trò là anot (cực âm) và bị oxi hóa thành ion $\\text{Zn}^{2+}$. Mệnh đề ĐÚNG." },
              { label: "b", text: "Thanh đồng đóng vai trò là cực dương (catot), tại đây xảy ra quá trình khử ion đồng: $\\text{Cu}^{2+} + 2e \\rightarrow \\text{Cu}$.", isCorrect: true, exp: "Ở catot (cực dương), ion $\\text{Cu}^{2+}$ trong dung dịch nhận electron tạo kim loại Cu bám vào thanh đồng. Mệnh đề ĐÚNG." },
              { label: "c", text: "Trong mạch ngoài, dòng electron di chuyển từ thanh kẽm sang thanh đồng.", isCorrect: true, exp: "Electron giải phóng ở anot (thanh Zn) chạy qua dây dẫn mạch ngoài sang catot (thanh Cu). Dòng điện quy ước đi ngược lại từ Cu sang Zn. Mệnh đề ĐÚNG." },
              { label: "d", text: "Sau một thời gian hoạt động, khối lượng của thanh kẽm tăng lên và khối lượng của thanh đồng giảm đi.", isCorrect: false, exp: "Kẽm bị tan ra thành $\\text{Zn}^{2+}$ nên khối lượng thanh Zn giảm; kim loại Cu bám vào thanh đồng nên khối lượng thanh Cu tăng. Mệnh đề SAI." }
            ],
            theory: `Quy tắc pin Galvani: Cực âm (Anot) xảy ra quá trình oxi hóa kim loại mạnh hơn; Cực dương (Catot) xảy ra quá trình khử ion kim loại yếu hơn. Cầu muối duy trì tính trung hòa điện tích.`,
            tips: `Nhớ mẹo: 'Anot tan, Catot bám'. Thanh nào làm cực âm (anot) sẽ tan dần (khối lượng giảm); thanh nào làm cực dương (catot) sẽ có kim loại bám vào (khối lượng tăng).`
          };
        }
      },
      {
        id: "c_p2_04",
        topic: "Khảo sát tính chất của Amino acid và Protein",
        generate: () => {
          return {
            content: `Cho 4 ống nghiệm chứa các dung dịch riêng biệt: (1) Glycine, (2) Lysine, (3) Glutamic acid, (4) Lòng trắng trứng (albumin). Xét tính đúng/sai của các mệnh đề sau:`,
            statements: [
              { label: "a", text: "Dung dịch Lysine làm quỳ tím chuyển sang màu xanh.", isCorrect: true, exp: "Lysine có công thức $\\text{H}_2\\text{N}-(\\text{CH}_2)_4-\\text{CH}(\\text{NH}_2)-\\text{COOH}$ (2 nhóm $-\\text{NH}_2$, 1 nhóm $-\\text{COOH}$) nên có tính base trội hơn, làm quỳ tím hóa xanh. Mệnh đề ĐÚNG." },
              { label: "b", text: "Dung dịch Glutamic acid làm quỳ tím chuyển sang màu đỏ.", isCorrect: true, exp: "Glutamic acid có 2 nhóm $-\\text{COOH}$ và 1 nhóm $-\\text{NH}_2$ nên có tính acid trội hơn, làm quỳ tím hóa đỏ. Mệnh đề ĐÚNG." },
              { label: "c", text: "Ống nghiệm chứa dung dịch Glycine làm quỳ tím chuyển sang màu hồng nhạt.", isCorrect: false, exp: "Glycine có 1 nhóm $-\\text{NH}_2$ và 1 nhóm $-\\text{COOH}$ cân bằng nhau về lực acid - base, do đó dung dịch gần như trung tính, quỳ tím KHÔNG ĐỔI MÀU. Mệnh đề SAI." },
              { label: "d", text: "Cho dung dịch $\\text{Cu(OH)}_2$ vào ống nghiệm chứa lòng trắng trứng xuất hiện màu tím đặc trưng.", isCorrect: true, exp: "Lòng trắng trứng chứa protein (chuỗi polypeptide dài), cho phản ứng màu biuret với $\\text{Cu(OH)}_2$ tạo phức màu tím. Mệnh đề ĐÚNG." }
            ],
            theory: `Tác dụng của amino acid lên quỳ tím: Nếu số nhóm $-\\text{NH}_2 >$ số nhóm $-\\text{COOH} \\Rightarrow$ quỳ tím hóa xanh (Lysine). Nếu số nhóm $-\\text{COOH} >$ số nhóm $-\\text{NH}_2 \\Rightarrow$ quỳ tím hóa đỏ (Glutamic acid). Nếu bằng nhau $\\Rightarrow$ không đổi màu (Gly, Ala, Val). Protein có phản ứng màu biuret.`,
            tips: `Mẹo nhớ: 'A-xít glutamic' $\\rightarrow$ chữ Acid $\\Rightarrow$ quỳ đỏ. 'Lysin' $\\rightarrow$ chữ L gần B (base) $\\Rightarrow$ quỳ xanh. 'Gly, Ala, Val' $\\rightarrow$ hòa bình, không đổi màu.`
          };
        }
      }
    ],

    templates_part3: [
      {
        id: "c_p3_01",
        topic: "Tính khối lượng muối khi xà phòng hóa este",
        generate: () => {
          const m_este = 8.8; // 0.1 mol ethyl acetate C4H8O2
          const m_muoi = 8.2; // 0.1 mol CH3COONa (M = 82)
          return {
            content: `Thủy phân hoàn toàn $8{,}8\\text{ gam}$ ethyl acetate $(\\text{CH}_3\\text{COOC}_2\\text{H}_5)$ bằng dung dịch $\\text{NaOH}$ vừa đủ, đun nóng. Cô cạn dung dịch sau phản ứng thu được bao nhiêu gam muối khan? (Nhập số thập phân).`,
            correctAnswer: `8.2`,
            theory: `Phương trình: $\\text{CH}_3\\text{COOC}_2\\text{H}_5 + \\text{NaOH} \\rightarrow \\text{CH}_3\\text{COONa} + \\text{C}_2\\text{H}_5\\text{OH}$. Khối lượng mol: $M(\\text{CH}_3\\text{COOC}_2\\text{H}_5) = 88\\text{ g/mol}$; $M(\\text{CH}_3\\text{COONa}) = 82\\text{ g/mol}$.`,
            explanation: `Số mol ethyl acetate: $n = \\frac{8{,}8}{88} = 0{,}1\\text{ mol}$. Theo phương trình phản ứng: $n_{\\text{muối}} = n_{\\text{este}} = 0{,}1\\text{ mol}$. Khối lượng muối $\\text{CH}_3\\text{COONa}$ khan: $m = 0{,}1 \\times 82 = 8{,}2\\text{ gam}$.`,
            tips: `Casio 570: Bấm $(8.8 / 88) \\times 82 = 8.2\\text{ gam}$.`
          };
        }
      },
      {
        id: "c_p3_02",
        topic: "Khối lượng Ag tạo thành trong phản ứng tráng bạc",
        generate: () => {
          const m_glu = 18; // 0.1 mol glucose C6H12O6
          const m_ag = 21.6; // 0.2 mol Ag (M = 108)
          return {
            content: `Đun nóng nhẹ dung dịch chứa $18\\text{ gam}$ glucose $(\\text{C}_6\\text{H}_{12}\\text{O}_6)$ với lượng dư thuốc thử Tollens. Giả sử phản ứng xảy ra hoàn toàn (hiệu suất $100\\%$). Khối lượng bạc $(\\text{Ag})$ kim loại thu được bằng bao nhiêu gam? (Nhập số thập phân).`,
            correctAnswer: `21.6`,
            theory: `Phương trình tráng bạc của glucose: $\\text{C}_6\\text{H}_{12}\\text{O}_6 \\xrightarrow{\\text{AgNO}_3/\\text{NH}_3} 2\\text{Ag}$. Khối lượng mol glucose là $180\\text{ g/mol}$, của Ag là $108\\text{ g/mol}$.`,
            explanation: `Số mol glucose: $n_{\\text{glucose}} = \\frac{18}{180} = 0{,}1\\text{ mol}$. Theo tỉ lệ phản ứng: $n_{\\text{Ag}} = 2 \\cdot n_{\\text{glucose}} = 0{,}2\\text{ mol}$. Khối lượng kết tủa bạc: $m_{\\text{Ag}} = 0{,}2 \\times 108 = 21{,}6\\text{ gam}$.`,
            tips: `Casio 570: Bấm $(18 / 180) \\times 2 \\times 108 = 21.6\\text{ gam}$.`
          };
        }
      },
      {
        id: "c_p3_03",
        topic: "Tính suất điện động chuẩn của pin Galvani",
        generate: () => {
          const E_anot = -0.44; // Fe2+/Fe
          const E_catot = 0.80; // Ag+/Ag
          const E_pin = (E_catot - E_anot).toFixed(2);
          return {
            content: `Biết thế điện cực chuẩn của các cặp oxi hóa - khử: $E^\\circ_{\\text{Fe}^{2+}/\\text{Fe}} = -0{,}44\\text{ V}$ và $E^\\circ_{\\text{Ag}^+/\\text{Ag}} = +0{,}80\\text{ V}$. Sức điện động chuẩn của pin điện hóa Fe - Ag là bao nhiêu Vôn (V)? (Nhập số thập phân).`,
            correctAnswer: `1.24`,
            theory: `Sức điện động chuẩn của pin: $E^\\circ_{\\text{pin}} = E^\\circ_{(+)} - E^\\circ_{(-)} = E^\\circ_{\\text{catot}} - E^\\circ_{\\text{anot}}$.`,
            explanation: `Ta có $E^\\circ_{\\text{Ag}^+/\\text{Ag}} = +0{,}80\\text{ V} > E^\\circ_{\\text{Fe}^{2+}/\\text{Fe}} = -0{,}44\\text{ V}$. Do đó catot $(+)$ là cực Ag, anot $(-)$ là cực Fe. Sức điện động của pin: $E^\\circ_{\\text{pin}} = 0{,}80 - (-0{,}44) = 1{,}24\\text{ V}$.`,
            tips: `Casio 570: Bấm $0.80 - (-0.44) = 1.24$. Không cần quan tâm hệ số cân bằng của electron khi tính $E^\\circ$.`
          };
        }
      },
      {
        id: "c_p3_04",
        topic: "Tính nồng độ cân bằng hoặc hằng số Kc",
        generate: () => {
          return {
            content: `Cho phản ứng ester hóa: $\\text{CH}_3\\text{COOH} + \\text{C}_2\\text{H}_5\\text{OH} \\rightleftharpoons \\text{CH}_3\\text{COOC}_2\\text{H}_5 + \\text{H}_2\\text{O}$. Ở nhiệt độ không đổi, nồng độ mol tại trạng thái cân bằng là $[\\text{CH}_3\\text{COOH}] = 0{,}2\\text{ M}$; $[\\text{C}_2\\text{H}_5\\text{OH}] = 0{,}2\\text{ M}$; $[\\text{CH}_3\\text{COOC}_2\\text{H}_5] = 0{,}4\\text{ M}$; $[\\text{H}_2\\text{O}] = 0{,}4\\text{ M}$. Giá trị của hằng số cân bằng $K_C$ bằng bao nhiêu? (Nhập số nguyên).`,
            correctAnswer: `4`,
            theory: `Biểu thức hằng số cân bằng phản ứng este hóa: $K_C = \\frac{[\\text{CH}_3\\text{COOC}_2\\text{H}_5][\\text{H}_2\\text{O}]}{[\\text{CH}_3\\text{COOH}][\\text{C}_2\\text{H}_5\\text{OH}]}$.`,
            explanation: `Thay các giá trị nồng độ vào biểu thức: $K_C = \\frac{0{,}4 \\times 0{,}4}{0{,}2 \\times 0{,}2} = \\frac{0{,}16}{0{,}04} = 4$.`,
            tips: `Casio 570: $(0.4 \\times 0.4) / (0.2 \\times 0.2) = 4$. Với phản ứng este hóa, nước cũng là sản phẩm nằm trong dung dịch đồng thể nên vẫn có mặt trong biểu thức $K_C$.`
          };
        }
      },
      {
        id: "c_p3_05",
        topic: "Tính thể tích CO2 trong lên men tinh bột",
        generate: () => {
          const m_glu = 36; // 0.2 mol glucose
          const V_co2 = (0.2 * 2 * 24.79).toFixed(2); // Ở điều kiện chuẩn 25°C, 1 bar (24.79 L/mol)
          return {
            content: `Lên men rượu hoàn toàn $36\\text{ gam}$ glucose theo phản ứng: $\\text{C}_6\\text{H}_{12}\\text{O}_6 \\xrightarrow{\\text{men}} 2\\text{C}_2\\text{H}_5\\text{OH} + 2\\text{CO}_2\\uparrow$. Thể tích khí $\\text{CO}_2$ thu được ở điều kiện chuẩn ($25^\\circ\\text{C}, 1\\text{ bar}$, $1\\text{ mol} = 24{,}79\\text{ lít}$) là bao nhiêu lít? (Làm tròn đến 2 chữ số thập phân).`,
            correctAnswer: `9.92`,
            theory: `Theo chương trình mới 2025: Thể tích mol chất khí ở điều kiện chuẩn ($25^\\circ\\text{C}, 1\\text{ bar}$, kí hiệu đkc) là $V_m = 24{,}79\\text{ lít/mol}$ (thay cho $22{,}4\\text{ lít/mol}$ ở đktc cũ).`,
            explanation: `Số mol glucose: $n = \\frac{36}{180} = 0{,}2\\text{ mol}$. Theo phương trình: $n_{\\text{CO}_2} = 2 \\cdot n_{\\text{glucose}} = 0{,}4\\text{ mol}$. Thể tích khí ở đkc: $V = 0{,}4 \\times 24{,}79 = 9{,}916 \\approx 9{,}92\\text{ lít}$.`,
            tips: `LƯU Ý QUAN TRỌNG KỲ THI 2025: Chương trình SGK mới dùng ĐIỀU KIỆN CHUẨN với $24{,}79\\text{ L/mol}$, KHÔNG dùng $22{,}4\\text{ L/mol}$ như trước đây.`
          };
        }
      },
      {
        id: "c_p3_06",
        topic: "Số liên kết peptide trong phân tử",
        generate: () => {
          return {
            content: `Một phân tử oligopeptide mạch hở $X$ có công thức cấu tạo là $\\text{Gly-Ala-Val-Gly-Ala}$. Phân tử peptide $X$ có bao nhiêu liên kết peptide? (Nhập số nguyên).`,
            correctAnswer: `4`,
            theory: `Khái niệm liên kết peptide: Là liên kết $-CONH-$ giữa nhóm $\\alpha$-carboxyl của amino acid này với nhóm $\\alpha$-amino của amino acid kế tiếp. Một phân tử n-peptide mạch hở chứa đúng $(n - 1)$ liên kết peptide.`,
            explanation: `Phân tử $\\text{Gly-Ala-Val-Gly-Ala}$ tạo thành từ 5 gốc $\\alpha$-amino acid, do đó là một pentapeptide ($n = 5$). Số liên kết peptide là $n - 1 = 5 - 1 = 4$ liên kết.`,
            tips: `Bẫy: Đề bài hỏi 'số liên kết peptide' (bằng $n - 1$), không phải hỏi 'số gốc amino acid' ($n$). Với pentapeptide có 5 gốc nhưng chỉ có 4 liên kết.`
          };
        }
      }
    ]
  }
};
