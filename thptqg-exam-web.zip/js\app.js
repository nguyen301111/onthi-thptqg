// Ứng dụng Quản lý Ôn thi THPT Quốc Gia & Luyện đề chuẩn BGD 2025
// Tác giả: Antigravity Coding Assistant

// Biến trạng thái toàn cục
window.CurrentTab = 'docs';
window.CurrentExam = null;
window.UserAnswers = { part1: {}, part2: {}, part3: {} };
window.TimerInterval = null;
window.TimeRemaining = 0; // giây

// Helper formatMath: Tự động phát hiện và bọc công thức Toán/Lí/Hóa để KaTeX luôn render chính xác
function formatMath(text) {
  if (text === null || text === undefined) return '';
  let str = String(text);

  // Nếu đã có delimiter KaTeX ($ hoặc $$ hoặc \( hoặc \[), giữ nguyên
  if (str.includes('$') || str.includes('\\(') || str.includes('\\[') || str.includes('<table') || str.includes('<div')) {
    return str;
  }

  // Nhận diện mã lệnh LaTeX hoặc ký tự toán học đặc thù
  const hasLatex = /\\[a-zA-Z]+/.test(str);
  const hasMathSymbols = /[\^_{}\\]/.test(str);
  const hasVietnamese = /[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]/i.test(str);

  // Trường hợp 1: Biểu thức toán học thuần túy (ví dụ: (-\sqrt{2}; +\infty), [-2; 2], \frac{a}{b})
  if ((hasLatex || hasMathSymbols) && !hasVietnamese) {
    return `$${str.trim()}$`;
  }

  // Trường hợp 2: Câu văn chứa lệnh LaTeX chưa bọc $ (ví dụ: "kết quả bằng \sqrt{2}")
  if (hasLatex && hasVietnamese) {
    return str.replace(/(\\[a-zA-Z]+(?:\{[^{}]*\}|\[[^[\]]*\])*)/g, '$$$1$');
  }

  return str;
}
window.formatMath = formatMath;

// Khởi chạy khi tài liệu tải xong
document.addEventListener("DOMContentLoaded", () => {
  renderDocuments();
  renderHistory();
  renderRoadmap();
  updateCountdown();
  
  // Khởi động KaTeX auto render sau khi tải thư viện
  setTimeout(() => {
    triggerMathRender();
  }, 300);
});

// Chuyển đổi Tab chính
function switchTab(tabId) {
  window.CurrentTab = tabId;
  const tabs = ['docs', 'generator', 'exam', 'roadmap', 'history', 'review'];
  tabs.forEach(t => {
    const el = document.getElementById(`tab-${t}`);
    const btn = document.getElementById(`nav-btn-${t}`);
    if (el) {
      if (t === tabId) {
        el.classList.remove('hidden');
      } else {
        el.classList.add('hidden');
      }
    }
    if (btn) {
      if (t === tabId) {
        btn.classList.add('text-blue-600', 'bg-blue-50');
        btn.classList.remove('text-slate-600', 'hover:bg-slate-50');
      } else {
        btn.classList.remove('text-blue-600', 'bg-blue-50');
        btn.classList.add('text-slate-600', 'hover:bg-slate-50');
      }
    }
  });

  // Hiển thị nút Tab Xem Lại khi đang ở chế độ xem lại
  const reviewBtn = document.getElementById('nav-btn-review');
  if (reviewBtn) {
    if (tabId === 'review' || window.CurrentReviewExam) {
      reviewBtn.classList.remove('hidden');
    }
  }

  if (tabId === 'history') {
    renderHistory();
  }
  if (tabId === 'roadmap') {
    renderRoadmap();
  }

  // Tái tạo lại Lucide Icons
  if (window.lucide) lucide.createIcons();
}

// ==========================================
// 1. QUẢN LÝ KHO TÀI LIỆU (DOCUMENTS REPO)
// ==========================================
function renderDocuments() {
  const container = document.getElementById('docs-grid');
  if (!container) return;

  const searchQuery = (document.getElementById('doc-search-input')?.value || '').toLowerCase().trim();
  const filterSubject = document.getElementById('doc-filter-subject')?.value || 'all';
  const filterGrade = document.getElementById('doc-filter-grade')?.value || 'all';
  const filterCat = document.getElementById('doc-filter-category')?.value || 'all';
  const filterYear = document.getElementById('doc-filter-year')?.value || 'all';

  const docs = window.DOCUMENTS_DATA || [];

  const filtered = docs.filter(doc => {
    const matchSubject = filterSubject === 'all' || doc.subject === filterSubject;
    const matchGrade = filterGrade === 'all' || (doc.grade && doc.grade.toString() === filterGrade);
    const matchCat = filterCat === 'all' || doc.category === filterCat;
    const matchYear = filterYear === 'all' || (doc.year && doc.year.toString() === filterYear);
    const matchQuery = !searchQuery || 
      doc.title.toLowerCase().includes(searchQuery) || 
      doc.description.toLowerCase().includes(searchQuery) ||
      (doc.tags && doc.tags.some(tag => tag.toLowerCase().includes(searchQuery)));

    return matchSubject && matchGrade && matchCat && matchYear && matchQuery;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="col-span-full py-16 text-center text-slate-400">
        <i data-lucide="folder-search" class="w-12 h-12 mx-auto stroke-1 mb-3"></i>
        <p class="text-base font-medium">Không tìm thấy tài liệu phù hợp với bộ lọc.</p>
        <button onclick="resetDocFilters()" class="mt-3 text-sm text-blue-600 font-semibold hover:underline">Đặt lại bộ lọc</button>
      </div>
    `;
    if (window.lucide) lucide.createIcons();
    return;
  }

  const subjectBadges = {
    toan: { name: "Toán Học", color: "bg-blue-100 text-blue-700" },
    ly: { name: "Vật Lí", color: "bg-indigo-100 text-indigo-700" },
    hoa: { name: "Hóa Học", color: "bg-emerald-100 text-emerald-700" }
  };

  container.innerHTML = filtered.map(doc => {
    const subInfo = subjectBadges[doc.subject] || { name: doc.subject, color: "bg-slate-100 text-slate-700" };
    const hasSpecialFiles = doc.fileDe || doc.fileVietTay || doc.video;

    // Category badges
    let catBadgeHtml = '';
    if (doc.category === 'chuyen-de-10-11') {
      catBadgeHtml = '<span class="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-200">📘 Nền Tảng 10-11</span>';
    } else if (doc.category === '1000-cau-ly') {
      catBadgeHtml = '<span class="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-purple-100 text-purple-800 border border-purple-200">⚛️ 1000 Câu Lý Thuyết</span>';
    } else if (doc.category === '1000-cau-toan') {
      catBadgeHtml = '<span class="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">🔢 1000 Câu Đúng Sai</span>';
    } else if (doc.category === 've-dich-ly') {
      catBadgeHtml = '<span class="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-sky-100 text-sky-800 border border-sky-200">🎯 14 Ngày Tổng Ôn</span>';
    } else if (doc.category === 'imo-hoa') {
      catBadgeHtml = '<span class="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-teal-100 text-teal-800 border border-teal-200">🧪 Live M Hóa 2025</span>';
    } else if (doc.category === 've-dich-hoa') {
      catBadgeHtml = '<span class="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200">⚡ 14 Ngày Về Đích</span>';
    }

    const gradeBadgeHtml = doc.grade ? `
      <span class="px-2 py-0.5 rounded-lg text-[11px] font-bold ${doc.grade === 10 ? 'bg-amber-50 text-amber-700 border border-amber-200' : doc.grade === 11 ? 'bg-purple-50 text-purple-700 border border-purple-200' : 'bg-slate-100 text-slate-600'}">
        Lớp ${doc.grade}
      </span>
    ` : '';

    return `
      <div class="bg-white rounded-2xl border ${hasSpecialFiles ? 'border-emerald-200 hover:border-emerald-400' : 'border-slate-200'} p-6 shadow-sm hover:shadow-md transition flex flex-col justify-between space-y-4">
        <div class="space-y-3">
          <div class="flex items-center justify-between gap-2">
            <div class="flex items-center gap-1.5 flex-wrap">
              <span class="px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider ${subInfo.color}">
                ${subInfo.name}
              </span>
              ${gradeBadgeHtml}
              ${catBadgeHtml}
            </div>
            <span class="text-xs text-slate-400 font-medium flex items-center gap-1">
              <i data-lucide="download" class="w-3.5 h-3.5"></i> ${(doc.downloads || 5000).toLocaleString()} lượt tải
            </span>
          </div>

          <h3 class="font-bold text-base text-slate-900 leading-snug hover:text-blue-600 transition">
            ${doc.title}
          </h3>

          ${doc.buoiHoc ? `
            <div class="flex items-center gap-2 text-xs font-semibold text-slate-600 bg-slate-50 p-2 rounded-xl border border-slate-100">
              <span class="text-blue-700 font-bold">${doc.buoiHoc}</span>
              ${doc.caLive ? `<span class="text-slate-400">•</span> <span>Ca ${doc.caLive}</span>` : ''}
              ${doc.ngayLive ? `<span class="text-slate-400">•</span> <span class="text-slate-500">${doc.ngayLive}</span>` : ''}
            </div>
          ` : ''}

          <p class="text-slate-500 text-xs line-clamp-2 leading-relaxed">
            ${doc.description}
          </p>

          <div class="flex flex-wrap gap-1.5 pt-1">
            ${(doc.tags || []).map(t => `<span class="bg-slate-100 text-slate-600 text-[11px] px-2 py-0.5 rounded-md font-medium">#${t}</span>`).join('')}
          </div>
        </div>

        <div class="pt-3 border-t border-slate-100 space-y-2.5">
          ${hasSpecialFiles ? `
            <div class="flex flex-wrap items-center gap-1.5 pb-2 border-b border-dashed border-slate-100">
              ${doc.fileDe ? `
                <a href="${doc.fileDe}" target="_blank" class="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-2.5 py-1 rounded-lg transition" title="Mở File Đề (Google Drive / Online)">
                  <i data-lucide="file-text" class="w-3 h-3"></i> File Đề
                </a>
              ` : ''}
              ${doc.fileVietTay ? `
                <a href="${doc.fileVietTay}" target="_blank" class="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded-lg transition" title="Mở File Lời Giải Viết Tay / Bảng Điểm">
                  <i data-lucide="check-circle" class="w-3 h-3 text-emerald-600"></i> Lời Giải Viết Tay
                </a>
              ` : ''}
              ${doc.video ? `
                <a href="${doc.video}" target="_blank" class="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 px-2 py-1 rounded-lg transition" title="Mở Video Chữa Đề">
                  <i data-lucide="video" class="w-3 h-3"></i> Video
                </a>
              ` : ''}
            </div>
          ` : ''}

          <div class="flex flex-wrap items-center justify-between gap-2">
            <button onclick="openDocStudyModal('${doc.id}')" class="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-sm transition">
              <i data-lucide="book-open" class="w-3.5 h-3.5"></i> Đọc & Ôn Tập
            </button>
            <div class="flex items-center gap-1.5">
              <a href="${doc.link || '#'}" target="_blank" class="inline-flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-blue-600 px-2.5 py-2 rounded-xl hover:bg-slate-50 transition" title="Mở liên kết nguồn">
                <i data-lucide="external-link" class="w-3.5 h-3.5"></i> Nguồn
              </a>
              <button onclick="startGeneratedExam('${doc.subject}')" class="inline-flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-xs px-3 py-2 rounded-xl transition" title="Thi thử trắc nghiệm môn này">
                <i data-lucide="shuffle" class="w-3.5 h-3.5"></i> Thi Thử
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');

  if (window.lucide) lucide.createIcons();
  setTimeout(() => {
    triggerMathRender(container);
  }, 100);
}

function resetDocFilters() {
  const sInput = document.getElementById('doc-search-input');
  const fSubj = document.getElementById('doc-filter-subject');
  const fGrade = document.getElementById('doc-filter-grade');
  const fCat = document.getElementById('doc-filter-category');
  const fYear = document.getElementById('doc-filter-year');

  if (sInput) sInput.value = '';
  if (fSubj) fSubj.value = 'all';
  if (fGrade) fGrade.value = 'all';
  if (fCat) fCat.value = 'all';
  if (fYear) fYear.value = 'all';
  renderDocuments();
}

function openAddDocModal() {
  const title = prompt("Nhập tiêu đề tài liệu mới:");
  if (!title) return;
  const subject = prompt("Môn học (toan / ly / hoa):", "toan");
  const link = prompt("Đường dẫn xem tài liệu (URL/Google Drive):", "https://");
  
  if (title && subject) {
    window.DOCUMENTS_DATA.unshift({
      id: "user-" + Date.now(),
      subject: subject.toLowerCase(),
      title: title,
      grade: 12,
      category: "de-thi",
      source: "Người dùng thêm",
      year: 2025,
      description: "Tài liệu được thêm vào bởi thí sinh ôn thi.",
      link: link || "#",
      tags: ["Đóng góp", "Tài liệu cá nhân"],
      downloads: 1
    });
    renderDocuments();
    alert("Đã thêm tài liệu thành công vào kho!");
  }
}

// ==========================================
// 2. SINH ĐỀ VÀ PHÒNG THI THỬ (EXAM ENGINE)
// ==========================================
function startQuickExam(subject) {
  startGeneratedExam(subject);
}

function startGeneratedExam(subject) {
  const exam = window.ExamGenerator.generateExam(subject);
  if (!exam) return;

  window.CurrentExam = exam;
  window.UserAnswers = { part1: {}, part2: {}, part3: {} };

  // Đổi tiêu đề và badge môn học
  const badgeEl = document.getElementById('exam-subject-badge');
  const titleEl = document.getElementById('exam-title-text');
  if (badgeEl) badgeEl.textContent = `${exam.subjectName} (${exam.totalQuestions} câu - ${exam.duration} phút)`;
  if (titleEl) titleEl.textContent = `Đề Thi Thử Tốt Nghiệp THPT 2025 - 2026 Chuẩn BGD - Môn ${exam.subjectName} (${exam.totalQuestions} câu - Mã đề: ${exam.id.slice(-4)})`;

  // Render câu hỏi ra giao diện
  renderExamQuestions(exam);

  // Render bảng điều hướng ma trận
  renderNavMatrix(exam);

  // Khởi động đồng hồ đếm ngược
  startTimer(exam.duration * 60);

  // Chuyển sang Tab phòng thi
  switchTab('exam');
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Tái kích hoạt render công thức Toán học KaTeX
  setTimeout(() => {
    triggerMathRender();
  }, 100);
}

// Khởi tạo đồng hồ đếm ngược
function startTimer(totalSeconds) {
  if (window.TimerInterval) clearInterval(window.TimerInterval);
  window.TimeRemaining = totalSeconds;

  updateTimerDisplay();

  window.TimerInterval = setInterval(() => {
    window.TimeRemaining--;
    updateTimerDisplay();

    if (window.TimeRemaining <= 0) {
      clearInterval(window.TimerInterval);
      alert("Hết giờ làm bài! Hệ thống sẽ tự động thu bài và chấm điểm.");
      submitExam();
    }
  }, 1000);
}

function updateTimerDisplay() {
  const timerEl = document.getElementById('exam-timer');
  if (!timerEl) return;

  const mins = Math.floor(window.TimeRemaining / 60);
  const secs = window.TimeRemaining % 60;
  timerEl.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

  // Đổi màu cảnh báo nếu dưới 5 phút
  if (window.TimeRemaining < 300) {
    timerEl.parentElement.classList.add('bg-rose-600', 'text-white');
    timerEl.parentElement.classList.remove('bg-slate-900');
  } else {
    timerEl.parentElement.classList.remove('bg-rose-600');
    timerEl.parentElement.classList.add('bg-slate-900');
  }
}

// Render nội dung toàn bộ đề thi (3 phần chuẩn BGD 2025)
function renderExamQuestions(exam) {
  const container = document.getElementById('exam-questions-container');
  if (!container) return;

  let html = '';

  // ------------------------------------------
  // PHẦN I: TRẮC NGHIỆM 4 LỰA CHỌN
  // ------------------------------------------
  html += `
    <div class="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
      <div class="border-b border-slate-200 pb-4">
        <span class="text-xs font-bold text-blue-600 uppercase tracking-wider">Cấu trúc Bộ GD&ĐT 2025</span>
        <h3 class="text-xl font-black text-slate-900 mt-1">PHẦN I. CÂU TRẮC NGHIỆM NHIỀU PHƯƠNG ÁN LỰA CHỌN</h3>
        <p class="text-xs text-slate-500 mt-1">Thí sinh trả lời từ câu 1 đến câu ${exam.part1.length}. Mỗi câu hỏi thí sinh chỉ chọn một phương án.</p>
      </div>

      <div class="space-y-8">
        ${exam.part1.map(q => `
          <div id="q-p1-${q.num}" class="p-5 rounded-2xl border border-slate-100 bg-slate-50/50 space-y-4 scroll-mt-28">
            <div class="flex items-start gap-3">
              <span class="bg-blue-600 text-white font-bold text-xs px-2.5 py-1 rounded-lg shrink-0 mt-0.5">
                Câu ${q.num}
              </span>
              <div class="text-base text-slate-800 font-medium leading-relaxed math-content">
                ${formatMath(q.content)}
              </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              ${q.options.map(opt => `
                <label onclick="handleSelectPart1(${q.num}, '${opt.label}')" class="flex items-center gap-3 p-3.5 rounded-xl border border-slate-200 bg-white hover:border-blue-400 hover:bg-blue-50/30 transition cursor-pointer select-none">
                  <input type="radio" name="p1_q${q.num}" value="${opt.label}" class="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500">
                  <span class="font-bold text-sm text-slate-700 w-5">${opt.label}.</span>
                  <span class="text-sm text-slate-800 math-content">${formatMath(opt.text)}</span>
                </label>
              `).join('')}
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  // ------------------------------------------
  // PHẦN II: TRẮC NGHIỆM ĐÚNG / SAI
  // ------------------------------------------
  html += `
    <div class="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
      <div class="border-b border-slate-200 pb-4">
        <span class="text-xs font-bold text-indigo-600 uppercase tracking-wider">Cấu trúc Bộ GD&ĐT 2025</span>
        <h3 class="text-xl font-black text-slate-900 mt-1">PHẦN II. CÂU TRẮC NGHIỆM ĐÚNG SAI</h3>
        <p class="text-xs text-slate-500 mt-1">Thí sinh trả lời từ câu 1 đến câu ${exam.part2.length}. Trong mỗi ý a), b), c), d) ở mỗi câu, thí sinh chọn đúng hoặc sai.</p>
      </div>

      <div class="space-y-8">
        ${exam.part2.map(q => `
          <div id="q-p2-${q.num}" class="p-5 rounded-2xl border border-slate-100 bg-slate-50/50 space-y-4 scroll-mt-28">
            <div class="flex items-start gap-3">
              <span class="bg-indigo-600 text-white font-bold text-xs px-2.5 py-1 rounded-lg shrink-0 mt-0.5">
                Câu ${q.num}
              </span>
              <div class="text-base text-slate-800 font-medium leading-relaxed math-content">
                ${formatMath(q.content)}
              </div>
            </div>

            <!-- Bảng chọn Đúng/Sai từng mệnh đề a, b, c, d -->
            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse border border-slate-200 rounded-xl overflow-hidden bg-white">
                <thead>
                  <tr class="bg-slate-100 text-slate-700 text-xs font-bold uppercase">
                    <th class="p-3 w-16 text-center">Lệnh</th>
                    <th class="p-3">Nội dung mệnh đề</th>
                    <th class="p-3 w-20 text-center">Đúng</th>
                    <th class="p-3 w-20 text-center">Sai</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-sm">
                  ${q.statements.map(st => `
                    <tr class="hover:bg-slate-50/60 transition">
                      <td class="p-3 font-bold text-slate-900 text-center">${st.label})</td>
                      <td class="p-3 text-slate-800 math-content">${formatMath(st.text)}</td>
                      <td class="p-3 text-center">
                        <input type="radio" name="p2_q${q.num}_${st.label}" onchange="handleSelectPart2(${q.num}, '${st.label}', true)" value="true" class="w-4 h-4 text-emerald-600 focus:ring-emerald-500 cursor-pointer">
                      </td>
                      <td class="p-3 text-center">
                        <input type="radio" name="p2_q${q.num}_${st.label}" onchange="handleSelectPart2(${q.num}, '${st.label}', false)" value="false" class="w-4 h-4 text-rose-600 focus:ring-rose-500 cursor-pointer">
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  // ------------------------------------------
  // PHẦN III: TRẢ LỜI NGẮN (ĐIỀN SỐ)
  // ------------------------------------------
  html += `
    <div class="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
      <div class="border-b border-slate-200 pb-4">
        <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Cấu trúc Bộ GD&ĐT 2025</span>
        <h3 class="text-xl font-black text-slate-900 mt-1">PHẦN III. CÂU TRẮC NGHIỆM TRẢ LỜI NGẮN</h3>
        <p class="text-xs text-slate-500 mt-1">Thí sinh trả lời từ câu 1 đến câu ${exam.part3.length}. Thí sinh tính toán và điền kết quả vào ô tương ứng.</p>
      </div>

      <div class="space-y-8">
        ${exam.part3.map(q => `
          <div id="q-p3-${q.num}" class="p-5 rounded-2xl border border-slate-100 bg-slate-50/50 space-y-4 scroll-mt-28">
            <div class="flex items-start gap-3">
              <span class="bg-purple-600 text-white font-bold text-xs px-2.5 py-1 rounded-lg shrink-0 mt-0.5">
                Câu ${q.num}
              </span>
              <div class="text-base text-slate-800 font-medium leading-relaxed math-content">
                ${formatMath(q.content)}
              </div>
            </div>

            <div class="flex items-center gap-3 pt-2">
              <label class="text-sm font-bold text-slate-700 whitespace-nowrap">Đáp số:</label>
              <input type="text" oninput="handleInputPart3(${q.num}, this.value)" placeholder="Nhập số..." class="w-48 px-4 py-2 rounded-xl border border-slate-200 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white">
              <span class="text-xs text-slate-400">(Số nguyên hoặc số thập phân)</span>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  container.innerHTML = html;
}

// Render Ma trận điều hướng câu hỏi bên cột phải
function renderNavMatrix(exam) {
  const p1Container = document.getElementById('nav-matrix-p1');
  const p2Container = document.getElementById('nav-matrix-p2');
  const p3Container = document.getElementById('nav-matrix-p3');

  if (p1Container) {
    p1Container.innerHTML = exam.part1.map(q => `
      <button id="pill-p1-${q.num}" onclick="scrollToQuestion('q-p1-${q.num}')" class="nav-pill w-8 h-8 rounded-lg border border-slate-200 bg-white text-slate-700 text-xs font-bold flex items-center justify-center hover:border-blue-500">
        ${q.num}
      </button>
    `).join('');
  }

  if (p2Container) {
    p2Container.innerHTML = exam.part2.map(q => `
      <button id="pill-p2-${q.num}" onclick="scrollToQuestion('q-p2-${q.num}')" class="nav-pill w-8 h-8 rounded-lg border border-slate-200 bg-white text-slate-700 text-xs font-bold flex items-center justify-center hover:border-indigo-500">
        ${q.num}
      </button>
    `).join('');
  }

  if (p3Container) {
    p3Container.innerHTML = exam.part3.map(q => `
      <button id="pill-p3-${q.num}" onclick="scrollToQuestion('q-p3-${q.num}')" class="nav-pill w-8 h-8 rounded-lg border border-slate-200 bg-white text-slate-700 text-xs font-bold flex items-center justify-center hover:border-purple-500">
        ${q.num}
      </button>
    `).join('');
  }

  updateAnsweredCounter();
}

function scrollToQuestion(elementId) {
  const el = document.getElementById(elementId);
  if (el) {
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

// Xử lý câu trả lời của người dùng
function handleSelectPart1(qNum, choice) {
  window.UserAnswers.part1[qNum] = choice;
  const pill = document.getElementById(`pill-p1-${qNum}`);
  if (pill) {
    pill.classList.add('bg-blue-600', 'text-white', 'border-blue-600');
    pill.classList.remove('bg-white', 'text-slate-700');
  }
  updateAnsweredCounter();
}

function handleSelectPart2(qNum, label, boolVal) {
  if (!window.UserAnswers.part2[qNum]) window.UserAnswers.part2[qNum] = {};
  window.UserAnswers.part2[qNum][label] = boolVal;

  const answeredStatements = Object.keys(window.UserAnswers.part2[qNum]).length;
  const pill = document.getElementById(`pill-p2-${qNum}`);
  if (pill && answeredStatements === 4) {
    pill.classList.add('bg-indigo-600', 'text-white', 'border-indigo-600');
    pill.classList.remove('bg-white', 'text-slate-700');
  }
  updateAnsweredCounter();
}

function handleInputPart3(qNum, value) {
  const clean = value.trim();
  if (clean) {
    window.UserAnswers.part3[qNum] = clean;
  } else {
    delete window.UserAnswers.part3[qNum];
  }

  const pill = document.getElementById(`pill-p3-${qNum}`);
  if (pill) {
    if (clean) {
      pill.classList.add('bg-purple-600', 'text-white', 'border-purple-600');
      pill.classList.remove('bg-white', 'text-slate-700');
    } else {
      pill.classList.remove('bg-purple-600', 'text-white', 'border-purple-600');
      pill.classList.add('bg-white', 'text-slate-700');
    }
  }
  updateAnsweredCounter();
}

function updateAnsweredCounter() {
  const counterEl = document.getElementById('answered-counter');
  if (!counterEl || !window.CurrentExam) return;

  const countP1 = Object.keys(window.UserAnswers.part1).length;
  const countP2 = Object.values(window.UserAnswers.part2).filter(item => Object.keys(item).length === 4).length;
  const countP3 = Object.keys(window.UserAnswers.part3).length;

  const total = countP1 + countP2 + countP3;
  counterEl.textContent = `${total}/${window.CurrentExam.totalQuestions} đã làm`;
}

// ==========================================
// 3. NỘP BÀI VÀ XEM LỜI GIẢI CHI TIẾT
// ==========================================
function submitExamPrompt() {
  if (confirm("Bạn có chắc chắn muốn nộp bài thi ngay bây giờ không?")) {
    submitExam();
  }
}

function submitExam() {
  if (window.TimerInterval) clearInterval(window.TimerInterval);
  const exam = window.CurrentExam;
  if (!exam) return;

  const results = window.ExamGenerator.gradeExam(exam, window.UserAnswers);

  // Lưu vào localStorage đầy đủ dữ liệu đề và câu trả lời
  saveToHistory(results, exam, window.UserAnswers);

  // Hiển thị Modal Kết quả
  showResultsModal(exam, results);
}

function showResultsModal(exam, results) {
  const modal = document.getElementById('results-modal');
  if (!modal) return;

  window.CurrentlyViewingExam = exam;

  // Cập nhật nhãn kết quả (Thi thử hay Thi lại)
  const badgeEl = document.getElementById('result-badge-text');
  if (badgeEl) {
    if (exam.id && exam.id.includes('-retake')) {
      badgeEl.textContent = 'Kết Quả Thi Lại THPTQG 2025 - 2026';
    } else {
      badgeEl.textContent = 'Kết Quả Thi Thử THPTQG 2025 - 2026';
    }
  }

  document.getElementById('result-subject-text').textContent = `Môn ${exam.subjectName} (Mã đề: ${exam.id.slice(-6)})`;
  document.getElementById('result-total-score').textContent = results.totalScore.toFixed(2);
  
  const p1Max = exam.subject === 'toan' ? 3.0 : 4.5;
  const p3Max = exam.subject === 'toan' ? 3.0 : 1.5;
  document.getElementById('result-p1-score').textContent = `${results.scorePart1.toFixed(2)} / ${p1Max}`;
  document.getElementById('result-p2-score').textContent = `${results.scorePart2.toFixed(2)} / 4.0`;
  document.getElementById('result-p3-score').textContent = `${results.scorePart3.toFixed(2)} / ${p3Max}`;

  // Render danh sách giải chi tiết
  const solutionsContainer = document.getElementById('result-solutions-container');
  if (solutionsContainer) {
    let solHtml = '<div class="space-y-8">';

    // ==========================================
    // PHẦN I: TRẮC NGHIỆM 4 LỰA CHỌN
    // ==========================================
    solHtml += `
      <div class="border-b border-slate-200 pb-3 flex items-center justify-between">
        <div>
          <span class="text-xs font-bold text-blue-600 uppercase tracking-wider">Cấu trúc BGD 2025 - 2026</span>
          <h4 class="font-black text-xl text-slate-900">Lời Giải & Cơ Sở Lý Thuyết - Phần I</h4>
        </div>
        <span class="text-xs bg-blue-50 text-blue-700 px-3 py-1 rounded-xl font-bold border border-blue-200">${results.part1.length} câu hỏi</span>
      </div>
      <div class="space-y-6">
    `;

    results.part1.forEach(item => {
      const q = exam.part1.find(x => x.num === item.num);
      solHtml += `
        <div class="p-5 rounded-2xl border ${item.isCorrect ? 'border-emerald-200 bg-emerald-50/20' : 'border-rose-200 bg-rose-50/20'} space-y-4 shadow-sm">
          <!-- Header câu hỏi -->
          <div class="flex items-center justify-between text-xs font-bold pb-2 border-b ${item.isCorrect ? 'border-emerald-200' : 'border-rose-200'}">
            <div class="flex items-center gap-2">
              <span class="px-2.5 py-1 rounded-lg ${item.isCorrect ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'}">
                Câu ${item.num}
              </span>
              <span class="text-slate-600 font-semibold">[Chuyên đề: ${item.topic || 'Tổng hợp'}]</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="${item.isCorrect ? 'text-emerald-700' : 'text-rose-700'} text-sm font-black">
                ${item.isCorrect ? `✓ Đúng (+${item.points}đ)` : '✗ Chưa đúng (0đ)'}
              </span>
            </div>
          </div>

          <!-- Nội dung đề bài -->
          <div class="text-sm font-medium text-slate-900 math-content leading-relaxed">
            ${formatMath(q.content)}
          </div>

          <!-- Đối chiếu đáp án -->
          <div class="text-xs p-3 rounded-xl bg-white border border-slate-200 flex flex-wrap items-center gap-4">
            <div>Lựa chọn của bạn: <strong class="${item.isCorrect ? 'text-emerald-700' : 'text-rose-700'} text-sm">${item.userChoice}</strong></div>
            <div>Đáp án chuẩn BGD: <strong class="text-emerald-700 text-sm">${item.correctOption}</strong></div>
          </div>

          <!-- 1. Cơ sở lý thuyết & Công thức trọng tâm -->
          ${(item.theory || q.theory) ? `
            <div class="bg-blue-50/80 border border-blue-200 rounded-xl p-3.5 space-y-1.5">
              <div class="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                <i data-lucide="book-open" class="w-4 h-4 text-blue-600"></i>
                <span>Cơ Sở Lý Thuyết & Công Thức Trọng Tâm:</span>
              </div>
              <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                ${formatMath(item.theory || q.theory)}
              </div>
            </div>
          ` : ''}

          <!-- 2. Phương pháp & Lời giải chi tiết -->
          <div class="bg-white border border-slate-200 rounded-xl p-3.5 space-y-1.5">
            <div class="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
              <i data-lucide="file-check-2" class="w-4 h-4 text-emerald-600"></i>
              <span>Các Bước Giải Chi Tiết:</span>
            </div>
            <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
              ${formatMath(item.explanation || q.explanation)}
            </div>
          </div>

          <!-- 3. Mẹo bấm Casio fx-570 & Bẫy cần tránh -->
          ${(item.tips || q.tips) ? `
            <div class="bg-amber-50/80 border border-amber-200 rounded-xl p-3 space-y-1">
              <div class="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                <i data-lucide="calculator" class="w-4 h-4 text-amber-600"></i>
                <span>Mẹo Bấm Máy Casio fx-570 & Bẫy Cần Tránh:</span>
              </div>
              <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                ${formatMath(item.tips || q.tips)}
              </div>
            </div>
          ` : ''}
        </div>
      `;
    });
    solHtml += '</div>';

    // ==========================================
    // PHẦN II: TRẮC NGHIỆM ĐÚNG / SAI
    // ==========================================
    solHtml += `
      <div class="border-b border-slate-200 pb-3 pt-6 flex items-center justify-between">
        <div>
          <span class="text-xs font-bold text-indigo-600 uppercase tracking-wider">Cấu trúc BGD 2025 - 2026</span>
          <h4 class="font-black text-xl text-slate-900">Lời Giải & Cơ Sở Lý Thuyết - Phần II (Đúng/Sai)</h4>
        </div>
        <span class="text-xs bg-indigo-50 text-indigo-700 px-3 py-1 rounded-xl font-bold border border-indigo-200">${results.part2.length} câu hỏi (Barem 0.1 - 0.25 - 0.5 - 1.0)</span>
      </div>
      <div class="space-y-6">
    `;

    results.part2.forEach(item => {
      const q = exam.part2.find(x => x.num === item.num);
      solHtml += `
        <div class="p-5 rounded-2xl border border-slate-200 bg-white space-y-4 shadow-sm">
          <div class="flex items-center justify-between text-xs font-bold pb-2 border-b border-slate-100">
            <div class="flex items-center gap-2">
              <span class="px-2.5 py-1 rounded-lg bg-indigo-600 text-white">Câu ${item.num}</span>
              <span class="text-slate-600 font-semibold">[Chuyên đề: ${item.topic || 'Đúng/Sai'}]</span>
            </div>
            <span class="text-indigo-700 text-sm font-black">
              Đạt ${item.points} điểm (${item.correctCount}/4 ý chính xác)
            </span>
          </div>

          <div class="text-sm font-medium text-slate-900 math-content leading-relaxed">
            ${formatMath(q.content)}
          </div>

          <!-- Chi tiết 4 mệnh đề a, b, c, d kèm lý thuyết & lời giải -->
          <div class="space-y-3 pt-2">
            ${item.statements.map(st => `
              <div class="p-3.5 rounded-xl border ${st.isMatched ? 'border-emerald-200 bg-emerald-50/20' : 'border-rose-200 bg-rose-50/20'} space-y-2">
                <div class="flex items-center justify-between text-xs">
                  <span class="font-bold text-slate-900">Mệnh đề ${st.label})</span>
                  <span class="font-bold ${st.isMatched ? 'text-emerald-700' : 'text-rose-700'}">
                    ${st.isMatched ? '✓ Chính xác' : '✗ Chưa đúng'} (Bạn chọn: ${st.userChoice} | Đáp án: ${st.correctAnswer})
                  </span>
                </div>
                <div class="text-xs text-slate-800 math-content font-medium">${formatMath(st.text)}</div>
                
                <div class="bg-white p-2.5 rounded-lg border border-slate-200/80 text-xs space-y-1">
                  <div class="font-semibold text-slate-700 flex items-center gap-1">
                    <i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-blue-600"></i> Hướng dẫn & Lý thuyết:
                  </div>
                  <div class="math-content text-slate-600 leading-relaxed">${formatMath(st.explanation)}</div>
                </div>
              </div>
            `).join('')}
          </div>

          ${(item.tips || q.tips) ? `
            <div class="bg-amber-50/80 border border-amber-200 rounded-xl p-3 text-xs space-y-1">
              <div class="font-bold text-amber-900 flex items-center gap-1.5">
                <i data-lucide="calculator" class="w-4 h-4 text-amber-600"></i>
                <span>Mẹo Bấm Máy Casio fx-570 & Bẫy Cần Tránh:</span>
              </div>
              <div class="math-content text-slate-800 leading-relaxed pl-1">${formatMath(item.tips || q.tips)}</div>
            </div>
          ` : ''}
        </div>
      `;
    });
    solHtml += '</div>';

    // ==========================================
    // PHẦN III: TRẢ LỜI NGẮN (ĐIỀN SỐ)
    // ==========================================
    solHtml += `
      <div class="border-b border-slate-200 pb-3 pt-6 flex items-center justify-between">
        <div>
          <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Cấu trúc BGD 2025 - 2026</span>
          <h4 class="font-black text-xl text-slate-900">Lời Giải & Cơ Sở Lý Thuyết - Phần III (Trả Lời Ngắn)</h4>
        </div>
        <span class="text-xs bg-purple-50 text-purple-700 px-3 py-1 rounded-xl font-bold border border-purple-200">${results.part3.length} câu tính toán</span>
      </div>
      <div class="space-y-6">
    `;

    results.part3.forEach(item => {
      const q = exam.part3.find(x => x.num === item.num);
      solHtml += `
        <div class="p-5 rounded-2xl border ${item.isCorrect ? 'border-emerald-200 bg-emerald-50/20' : 'border-rose-200 bg-rose-50/20'} space-y-4 shadow-sm">
          <div class="flex items-center justify-between text-xs font-bold pb-2 border-b ${item.isCorrect ? 'border-emerald-200' : 'border-rose-200'}">
            <div class="flex items-center gap-2">
              <span class="px-2.5 py-1 rounded-lg ${item.isCorrect ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'}">Câu ${item.num}</span>
              <span class="text-slate-600 font-semibold">[Chuyên đề: ${item.topic || 'Tính toán thực tế'}]</span>
            </div>
            <span class="${item.isCorrect ? 'text-emerald-700' : 'text-rose-700'} text-sm font-black">
              ${item.isCorrect ? `✓ Đúng (+${item.points}đ)` : '✗ Chưa đúng (0đ)'}
            </span>
          </div>

          <div class="text-sm font-medium text-slate-900 math-content leading-relaxed">
            ${formatMath(q.content)}
          </div>

          <div class="text-xs p-3 rounded-xl bg-white border border-slate-200 flex flex-wrap items-center gap-4">
            <div>Bạn đã điền: <strong class="${item.isCorrect ? 'text-emerald-700' : 'text-rose-700'} font-mono text-sm">${item.userAns}</strong></div>
            <div>Đáp số chuẩn BGD: <strong class="text-emerald-700 font-mono text-sm">${formatMath(item.correctAns)}</strong></div>
          </div>

          <!-- 1. Cơ sở lý thuyết -->
          ${(item.theory || q.theory) ? `
            <div class="bg-blue-50/80 border border-blue-200 rounded-xl p-3.5 space-y-1.5">
              <div class="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                <i data-lucide="book-open" class="w-4 h-4 text-blue-600"></i>
                <span>Cơ Sở Lý Thuyết & Công Thức Áp Dụng:</span>
              </div>
              <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                ${formatMath(item.theory || q.theory)}
              </div>
            </div>
          ` : ''}

          <!-- 2. Phương pháp giải chi tiết -->
          <div class="bg-white border border-slate-200 rounded-xl p-3.5 space-y-1.5">
            <div class="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
              <i data-lucide="file-check-2" class="w-4 h-4 text-emerald-600"></i>
              <span>Các Bước Tính Toán Chi Tiết:</span>
            </div>
            <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
              ${formatMath(item.explanation || q.explanation)}
            </div>
          </div>

          <!-- 3. Hướng dẫn bấm Casio fx-570 -->
          ${(item.tips || q.tips) ? `
            <div class="bg-amber-50/80 border border-amber-200 rounded-xl p-3 space-y-1">
              <div class="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                <i data-lucide="calculator" class="w-4 h-4 text-amber-600"></i>
                <span>Mẹo Bấm Máy Casio fx-570 Nhanh:</span>
              </div>
              <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                ${formatMath(item.tips || q.tips)}
              </div>
            </div>
          ` : ''}
        </div>
      `;
    });
    solHtml += '</div>';

    solHtml += '</div>';
    solutionsContainer.innerHTML = solHtml;
  }

  modal.classList.remove('hidden');
  if (window.lucide) lucide.createIcons();
  setTimeout(() => {
    triggerMathRender(modal);
  }, 100);
}

function closeResultsModal() {
  const modal = document.getElementById('results-modal');
  if (modal) modal.classList.add('hidden');
}

// ==========================================
// 4. LỊCH SỬ LÀM BÀI & LOCALSTORAGE
// ==========================================
function saveToHistory(results, exam, userAnswers) {
  try {
    const history = JSON.parse(localStorage.getItem('thptqg_exam_history') || '[]');
    const record = {
      id: results.examId || ('exam_' + Date.now()),
      subject: results.subject,
      subjectName: exam ? exam.subjectName : (results.subject === 'toan' ? 'Toán Học' : (results.subject === 'ly' ? 'Vật Lí' : 'Hóa Học')),
      totalScore: Number(results.totalScore.toFixed(2)),
      scorePart1: Number(results.scorePart1.toFixed(2)),
      scorePart2: Number(results.scorePart2.toFixed(2)),
      scorePart3: Number(results.scorePart3.toFixed(2)),
      date: new Date().toLocaleString('vi-VN'),
      examData: exam ? JSON.parse(JSON.stringify(exam)) : null,
      resultsData: results ? JSON.parse(JSON.stringify(results)) : null,
      userAnswers: userAnswers ? JSON.parse(JSON.stringify(userAnswers)) : null
    };

    // Nếu đã có bản ghi trùng id (ví dụ thi lại), tạo ID nhánh mới để theo dõi tiến độ
    const existingIndex = history.findIndex(h => h.id === record.id);
    if (existingIndex >= 0) {
      record.id = record.id + '_r' + Date.now().toString().slice(-4);
    }

    history.unshift(record);
    // Giữ lại 25 bài thi gần nhất đầy đủ dữ liệu
    localStorage.setItem('thptqg_exam_history', JSON.stringify(history.slice(0, 25)));
  } catch (err) {
    console.error("Lỗi lưu lịch sử:", err);
    try {
      const history = JSON.parse(localStorage.getItem('thptqg_exam_history') || '[]');
      localStorage.setItem('thptqg_exam_history', JSON.stringify(history.slice(0, 10)));
    } catch (e2) {}
  }
}

function renderHistory() {
  const container = document.getElementById('history-table-container');
  if (!container) return;

  try {
    const history = JSON.parse(localStorage.getItem('thptqg_exam_history') || '[]');
    if (history.length === 0) {
      container.innerHTML = `
        <div class="p-12 text-center text-slate-400">
          <i data-lucide="clipboard-list" class="w-12 h-12 mx-auto stroke-1 mb-2"></i>
          <p class="text-sm font-medium">Bạn chưa thực hiện bài thi thử nào.</p>
          <button onclick="switchTab('generator')" class="mt-3 text-xs bg-blue-600 text-white font-semibold px-4 py-2 rounded-xl hover:bg-blue-700 transition">
            Làm bài thi thử đầu tiên
          </button>
        </div>
      `;
      if (window.lucide) lucide.createIcons();
      return;
    }

    const subjectNames = { toan: "Toán Học", ly: "Vật Lí", hoa: "Hóa Học" };

    container.innerHTML = `
      <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-sm">
          <thead>
            <tr class="bg-slate-100 text-slate-700 text-xs font-bold uppercase border-b border-slate-200">
              <th class="p-4">Thời gian</th>
              <th class="p-4">Môn thi</th>
              <th class="p-4 text-center">Phần I (4 lựa chọn)</th>
              <th class="p-4 text-center">Phần II (Đúng/Sai)</th>
              <th class="p-4 text-center">Phần III (Điền số)</th>
              <th class="p-4 text-center">Tổng Điểm</th>
              <th class="p-4 text-center">Hành Động</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100">
            ${history.map(item => {
              const hasFullData = !!item.examData;
              const isRetake = item.id && item.id.includes('_r');
              return `
                <tr class="hover:bg-slate-50 transition">
                  <td class="p-4 text-slate-500 font-mono text-xs whitespace-nowrap">
                    ${item.date}
                    ${isRetake ? '<span class="ml-1.5 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">Thi lại</span>' : ''}
                  </td>
                  <td class="p-4 font-bold text-slate-900 whitespace-nowrap">
                    ${item.subjectName || subjectNames[item.subject] || item.subject}
                  </td>
                  <td class="p-4 text-center text-slate-600 font-mono font-medium">${typeof item.scorePart1 === 'number' ? item.scorePart1.toFixed(2) : item.scorePart1}</td>
                  <td class="p-4 text-center text-slate-600 font-mono font-medium">${typeof item.scorePart2 === 'number' ? item.scorePart2.toFixed(2) : item.scorePart2}</td>
                  <td class="p-4 text-center text-slate-600 font-mono font-medium">${typeof item.scorePart3 === 'number' ? item.scorePart3.toFixed(2) : item.scorePart3}</td>
                  <td class="p-4 text-center font-black text-base ${item.totalScore >= 8 ? 'text-emerald-600' : (item.totalScore >= 5 ? 'text-blue-600' : 'text-rose-600')} font-mono">
                    ${typeof item.totalScore === 'number' ? item.totalScore.toFixed(2) : item.totalScore}
                  </td>
                  <td class="p-4 text-center whitespace-nowrap">
                    ${hasFullData ? `
                      <div class="inline-flex items-center gap-1.5">
                        <button onclick="viewHistoryExam('${item.id}')" class="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs rounded-xl border border-blue-200 transition shadow-sm active:scale-95" title="Xem lại bài thi & toàn bộ lời giải chi tiết">
                          <i data-lucide="eye" class="w-3.5 h-3.5"></i> Xem lại
                        </button>
                        <button onclick="retakeHistoryExam('${item.id}')" class="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs rounded-xl border border-emerald-200 transition shadow-sm active:scale-95" title="Thi lại chính xác đề thi này">
                          <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Thi lại
                        </button>
                      </div>
                    ` : `
                      <span class="text-xs text-slate-400 italic">Bản cũ</span>
                    `}
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
    if (window.lucide) lucide.createIcons();
  } catch (err) {
    console.error("Lỗi đọc lịch sử:", err);
  }
}

window.CurrentReviewExam = null;
window.CurrentReviewResults = null;

function viewHistoryExam(examId) {
  try {
    const history = JSON.parse(localStorage.getItem('thptqg_exam_history') || '[]');
    const item = history.find(h => h.id === examId);
    if (!item) {
      alert("Không tìm thấy dữ liệu bài thi này trong lịch sử!");
      return;
    }
    if (!item.examData || !item.resultsData) {
      alert("Bài thi này được làm từ phiên bản cũ trước khi hệ thống hỗ trợ lưu toàn bộ đề. Hãy làm một bài thi mới để trải nghiệm đầy đủ tính năng!");
      return;
    }

    // Mở phòng xem lại toàn màn hình giống hệt lúc thi
    openExamReviewRoom(item.examData, item.resultsData, item.date);
  } catch (err) {
    console.error("Lỗi khi xem lại bài thi:", err);
    alert("Có lỗi xảy ra: " + err.message);
  }
}
window.viewHistoryExam = viewHistoryExam;

function openReviewFromCurrentModal() {
  if (!window.CurrentlyViewingExam) return;
  const exam = window.CurrentlyViewingExam;
  try {
    const history = JSON.parse(localStorage.getItem('thptqg_exam_history') || '[]');
    const item = history.find(h => h.id === exam.id || (h.examData && h.examData.id === exam.id));
    if (item && item.resultsData) {
      closeResultsModal();
      openExamReviewRoom(item.examData, item.resultsData, item.date);
    } else {
      closeResultsModal();
      openExamReviewRoom(exam, window.ExamGenerator.gradeExam(exam, window.UserAnswers), new Date().toLocaleString('vi-VN'));
    }
  } catch (e) {
    closeResultsModal();
    openExamReviewRoom(exam, window.ExamGenerator.gradeExam(exam, window.UserAnswers), new Date().toLocaleString('vi-VN'));
  }
}
window.openReviewFromCurrentModal = openReviewFromCurrentModal;

function openExamReviewRoom(exam, results, date) {
  window.CurrentReviewExam = exam;
  window.CurrentReviewResults = results;
  window.CurrentlyViewingExam = exam;

  closeResultsModal();
  renderExamReviewRoom(exam, results, date);
  switchTab('review');
  window.scrollTo({ top: 0, behavior: 'smooth' });

  setTimeout(() => {
    triggerMathRender();
  }, 100);
}
window.openExamReviewRoom = openExamReviewRoom;

function retakeCurrentReviewingExam() {
  if (!window.CurrentReviewExam) return;
  const exam = window.CurrentReviewExam;
  if (confirm(`Bạn có chắc chắn muốn THI LẠI đề môn ${exam.subjectName} này?\n\n• Toàn bộ câu hỏi và bộ số liệu gốc sẽ được giữ nguyên 100%.\n• Giúp bạn kiểm tra xem mình đã khắc phục được các câu sai trước đó chưa!`)) {
    retakeExamObject(exam);
  }
}
window.retakeCurrentReviewingExam = retakeCurrentReviewingExam;

function renderExamReviewRoom(exam, results, date) {
  // 1. Cập nhật thanh tiêu đề & điểm số
  const subjectBadge = document.getElementById('review-subject-badge');
  const titleText = document.getElementById('review-title-text');
  const metaText = document.getElementById('review-meta-text');
  const headerScore = document.getElementById('review-header-score');
  const matrixScoreBadge = document.getElementById('review-matrix-score-badge');

  if (subjectBadge) subjectBadge.textContent = `${exam.subjectName} (${exam.totalQuestions} câu - ${exam.duration} phút)`;
  if (titleText) titleText.textContent = `[XEM LẠI ĐỀ] Đề Thi Tốt Nghiệp THPT - Môn ${exam.subjectName} (Mã đề: ${exam.id.slice(-6)})`;
  if (metaText) metaText.textContent = `Nộp bài lúc: ${date || new Date().toLocaleString('vi-VN')} • P1: ${results.scorePart1.toFixed(2)}đ | P2: ${results.scorePart2.toFixed(2)}đ | P3: ${results.scorePart3.toFixed(2)}đ`;
  if (headerScore) headerScore.textContent = `${results.totalScore.toFixed(2)} / 10`;
  if (matrixScoreBadge) matrixScoreBadge.textContent = `${results.totalScore.toFixed(2)} điểm`;

  // Cập nhật số câu đúng từng phần
  const p1Counter = document.getElementById('review-nav-p1-counter');
  const p2Counter = document.getElementById('review-nav-p2-counter');
  const p3Counter = document.getElementById('review-nav-p3-counter');
  if (p1Counter) p1Counter.textContent = `${results.part1.filter(x => x.isCorrect).length}/${results.part1.length} câu đúng`;
  if (p2Counter) p2Counter.textContent = `${results.part2.filter(x => x.correctCount === 4).length}/${results.part2.length} câu hoàn hảo`;
  if (p3Counter) p3Counter.textContent = `${results.part3.filter(x => x.isCorrect).length}/${results.part3.length} câu đúng`;

  // 2. Render danh sách câu hỏi xem lại
  const container = document.getElementById('review-questions-container');
  if (!container) return;

  let html = '';

  // ------------------------------------------
  // PHẦN I: TRẮC NGHIỆM 4 LỰA CHỌN
  // ------------------------------------------
  html += `
    <div class="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
      <div class="border-b border-slate-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <span class="text-xs font-bold text-blue-600 uppercase tracking-wider">Cấu trúc Bộ GD&ĐT 2025</span>
          <h3 class="text-xl font-black text-slate-900 mt-1">PHẦN I. CÂU TRẮC NGHIỆM NHIỀU PHƯƠNG ÁN LỰA CHỌN</h3>
          <p class="text-xs text-slate-500 mt-1">Thí sinh trả lời từ câu 1 đến câu ${exam.part1.length}. Mỗi câu hỏi chỉ chọn 1 phương án.</p>
        </div>
        <div class="text-right shrink-0">
          <span class="text-xs font-bold px-3 py-1.5 rounded-xl bg-blue-50 text-blue-700 border border-blue-200">
            Đạt: ${results.scorePart1.toFixed(2)} / ${exam.subject === 'toan' ? '3.0' : '4.5'} điểm
          </span>
        </div>
      </div>

      <div class="space-y-8">
        ${results.part1.map(item => {
          const q = exam.part1.find(x => x.num === item.num);
          const isCorrect = item.isCorrect;
          return `
            <div id="review-q-p1-${item.num}" class="p-5 rounded-2xl border ${isCorrect ? 'border-emerald-200 bg-emerald-50/15' : 'border-rose-200 bg-rose-50/15'} space-y-4 scroll-mt-28">
              <!-- Question Header -->
              <div class="flex items-center justify-between text-xs pb-3 border-b ${isCorrect ? 'border-emerald-100' : 'border-rose-100'}">
                <div class="flex items-center gap-2">
                  <span class="px-2.5 py-1 rounded-lg ${isCorrect ? 'bg-emerald-600' : 'bg-rose-600'} text-white font-bold text-xs">
                    Câu ${item.num}
                  </span>
                  <span class="text-slate-600 font-semibold text-xs">[Chuyên đề: ${item.topic || 'Tổng hợp'}]</span>
                </div>
                <div>
                  <span class="px-3 py-1 rounded-xl text-xs font-bold ${isCorrect ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-rose-100 text-rose-800 border border-rose-300'}">
                    ${isCorrect ? `✓ Đúng (+${item.points}đ)` : '✗ Chưa đúng (0đ)'}
                  </span>
                </div>
              </div>

              <!-- Question Content -->
              <div class="text-base text-slate-800 font-medium leading-relaxed math-content">
                ${formatMath(q.content)}
              </div>

              <!-- Options Grid (2 Columns giống lúc thi) -->
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                ${q.options.map(opt => {
                  const isUserChoice = (opt.label === item.userChoice);
                  const isCorrectChoice = (opt.label === item.correctOption);

                  let optClass = "border border-slate-200 bg-white text-slate-700";
                  let badge = "";

                  if (isUserChoice && isCorrect) {
                    optClass = "border-2 border-emerald-500 bg-emerald-50 text-emerald-950 font-bold shadow-sm";
                    badge = `<span class="ml-auto text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full shrink-0">✓ Lựa chọn của bạn</span>`;
                  } else if (isUserChoice && !isCorrect) {
                    optClass = "border-2 border-rose-500 bg-rose-50 text-rose-950 font-bold shadow-sm";
                    badge = `<span class="ml-auto text-[11px] font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full shrink-0">✗ Lựa chọn của bạn</span>`;
                  } else if (isCorrectChoice && !isCorrect) {
                    optClass = "border-2 border-dashed border-emerald-600 bg-emerald-50/50 text-emerald-900 font-bold";
                    badge = `<span class="ml-auto text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full shrink-0">⭐ Đáp án chuẩn BGD</span>`;
                  }

                  return `
                    <div class="flex items-center gap-3 p-3.5 rounded-xl transition ${optClass}">
                      <span class="font-bold text-sm w-5 shrink-0">${opt.label}.</span>
                      <span class="text-sm math-content leading-snug">${formatMath(opt.text)}</span>
                      ${badge}
                    </div>
                  `;
                }).join('')}
              </div>

              <!-- Explanations & Theory -->
              <div class="space-y-3 pt-2">
                ${(item.theory || q.theory) ? `
                  <div class="bg-blue-50/80 border border-blue-200 rounded-xl p-3.5 space-y-1">
                    <div class="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                      <i data-lucide="book-open" class="w-3.5 h-3.5 text-blue-600"></i>
                      <span>Cơ Sở Lý Thuyết & Công Thức Trọng Tâm:</span>
                    </div>
                    <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                      ${formatMath(item.theory || q.theory)}
                    </div>
                  </div>
                ` : ''}

                <div class="bg-white border border-slate-200 rounded-xl p-3.5 space-y-1">
                  <div class="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
                    <i data-lucide="file-check-2" class="w-3.5 h-3.5 text-emerald-600"></i>
                    <span>Các Bước Giải Chi Tiết:</span>
                  </div>
                  <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                    ${formatMath(item.explanation || q.explanation)}
                  </div>
                </div>

                ${(item.tips || q.tips) ? `
                  <div class="bg-amber-50/80 border border-amber-200 rounded-xl p-3 space-y-1">
                    <div class="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                      <i data-lucide="calculator" class="w-4 h-4 text-amber-600"></i>
                      <span>Mẹo Bấm Máy Casio fx-570 & Bẫy Cần Tránh:</span>
                    </div>
                    <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                      ${formatMath(item.tips || q.tips)}
                    </div>
                  </div>
                ` : ''}
              </div>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;

  // ------------------------------------------
  // PHẦN II: TRẮC NGHIỆM ĐÚNG / SAI
  // ------------------------------------------
  html += `
    <div class="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
      <div class="border-b border-slate-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <span class="text-xs font-bold text-indigo-600 uppercase tracking-wider">Cấu trúc Bộ GD&ĐT 2025</span>
          <h3 class="text-xl font-black text-slate-900 mt-1">PHẦN II. CÂU TRẮC NGHIỆM ĐÚNG SAI</h3>
          <p class="text-xs text-slate-500 mt-1">Thí sinh trả lời từ câu 1 đến câu ${exam.part2.length}. Barem điểm lũy tiến 0.1 - 0.25 - 0.5 - 1.0.</p>
        </div>
        <div class="text-right shrink-0">
          <span class="text-xs font-bold px-3 py-1.5 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-200">
            Đạt: ${results.scorePart2.toFixed(2)} / 4.0 điểm
          </span>
        </div>
      </div>

      <div class="space-y-8">
        ${results.part2.map(item => {
          const q = exam.part2.find(x => x.num === item.num);
          return `
            <div id="review-q-p2-${item.num}" class="p-5 rounded-2xl border border-slate-200 bg-white space-y-4 shadow-sm scroll-mt-28">
              <div class="flex items-center justify-between text-xs pb-3 border-b border-slate-100">
                <div class="flex items-center gap-2">
                  <span class="bg-indigo-600 text-white font-bold text-xs px-2.5 py-1 rounded-lg">
                    Câu ${item.num}
                  </span>
                  <span class="text-slate-600 font-semibold">[Chuyên đề: ${item.topic || 'Đúng/Sai'}]</span>
                </div>
                <span class="text-indigo-700 font-black text-xs bg-indigo-50 px-3 py-1 rounded-xl border border-indigo-200">
                  Đạt ${item.points} điểm (${item.correctCount}/4 ý chính xác)
                </span>
              </div>

              <div class="text-base text-slate-800 font-medium leading-relaxed math-content">
                ${formatMath(q.content)}
              </div>

              <!-- Statements Table giống lúc thi nhưng có kết quả đối chiếu -->
              <div class="space-y-3 pt-2">
                ${item.statements.map(st => `
                  <div class="p-3.5 rounded-xl border ${st.isMatched ? 'border-emerald-200 bg-emerald-50/20' : 'border-rose-200 bg-rose-50/20'} space-y-2">
                    <div class="flex items-center justify-between text-xs">
                      <span class="font-bold text-slate-900">Mệnh đề ${st.label})</span>
                      <span class="font-bold ${st.isMatched ? 'text-emerald-700' : 'text-rose-700'}">
                        ${st.isMatched ? '✓ Chính xác' : '✗ Chưa đúng'} (Bạn chọn: ${st.userChoice} | Đáp án: ${st.correctAnswer})
                      </span>
                    </div>
                    <div class="text-xs text-slate-800 math-content font-medium">${formatMath(st.text)}</div>
                    
                    <div class="bg-white p-2.5 rounded-lg border border-slate-200/80 text-xs space-y-1">
                      <div class="font-semibold text-slate-700 flex items-center gap-1">
                        <i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-blue-600"></i> Hướng dẫn & Lý thuyết:
                      </div>
                      <div class="math-content text-slate-600 leading-relaxed">${formatMath(st.explanation)}</div>
                    </div>
                  </div>
                `).join('')}
              </div>

              ${(item.tips || q.tips) ? `
                <div class="bg-amber-50/80 border border-amber-200 rounded-xl p-3 text-xs space-y-1">
                  <div class="font-bold text-amber-900 flex items-center gap-1.5">
                    <i data-lucide="calculator" class="w-4 h-4 text-amber-600"></i>
                    <span>Mẹo Bấm Máy Casio fx-570 & Bẫy Cần Tránh:</span>
                  </div>
                  <div class="math-content text-slate-800 leading-relaxed pl-1">${formatMath(item.tips || q.tips)}</div>
                </div>
              ` : ''}
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;

  // ------------------------------------------
  // PHẦN III: TRẢ LỜI NGẮN (ĐIỀN SỐ)
  // ------------------------------------------
  html += `
    <div class="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
      <div class="border-b border-slate-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <span class="text-xs font-bold text-purple-600 uppercase tracking-wider">Cấu trúc Bộ GD&ĐT 2025</span>
          <h3 class="text-xl font-black text-slate-900 mt-1">PHẦN III. CÂU TRẮC NGHIỆM TRẢ LỜI NGẮN</h3>
          <p class="text-xs text-slate-500 mt-1">Thí sinh trả lời từ câu 1 đến câu ${exam.part3.length}. Điền số nguyên hoặc số thập phân.</p>
        </div>
        <div class="text-right shrink-0">
          <span class="text-xs font-bold px-3 py-1.5 rounded-xl bg-purple-50 text-purple-700 border border-purple-200">
            Đạt: ${results.scorePart3.toFixed(2)} / ${exam.subject === 'toan' ? '3.0' : '1.5'} điểm
          </span>
        </div>
      </div>

      <div class="space-y-8">
        ${results.part3.map(item => {
          const q = exam.part3.find(x => x.num === item.num);
          const isCorrect = item.isCorrect;
          return `
            <div id="review-q-p3-${item.num}" class="p-5 rounded-2xl border ${isCorrect ? 'border-emerald-200 bg-emerald-50/15' : 'border-rose-200 bg-rose-50/15'} space-y-4 scroll-mt-28">
              <div class="flex items-center justify-between text-xs pb-3 border-b ${isCorrect ? 'border-emerald-100' : 'border-rose-100'}">
                <div class="flex items-center gap-2">
                  <span class="bg-purple-600 text-white font-bold text-xs px-2.5 py-1 rounded-lg">Câu ${item.num}</span>
                  <span class="text-slate-600 font-semibold">[Chuyên đề: ${item.topic || 'Tính toán thực tế'}]</span>
                </div>
                <span class="${isCorrect ? 'text-emerald-700' : 'text-rose-700'} text-xs font-black px-3 py-1 rounded-xl ${isCorrect ? 'bg-emerald-100 border border-emerald-300' : 'bg-rose-100 border border-rose-300'}">
                  ${isCorrect ? `✓ Đúng (+${item.points}đ)` : '✗ Chưa đúng (0đ)'}
                </span>
              </div>

              <div class="text-base text-slate-800 font-medium leading-relaxed math-content">
                ${formatMath(q.content)}
              </div>

              <!-- Ô đáp số đối chiếu -->
              <div class="text-xs p-3 rounded-xl bg-white border border-slate-200 flex flex-wrap items-center gap-4">
                <div>Bạn đã điền: <strong class="${isCorrect ? 'text-emerald-700' : 'text-rose-700'} font-mono text-sm">${item.userAns || '(bỏ trống)'}</strong></div>
                <div>Đáp số chuẩn BGD: <strong class="text-emerald-700 font-mono text-sm">${formatMath(item.correctAns)}</strong></div>
              </div>

              <div class="space-y-3 pt-2">
                ${(item.theory || q.theory) ? `
                  <div class="bg-blue-50/80 border border-blue-200 rounded-xl p-3.5 space-y-1">
                    <div class="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                      <i data-lucide="book-open" class="w-3.5 h-3.5 text-blue-600"></i>
                      <span>Cơ Sở Lý Thuyết & Công Thức Áp Dụng:</span>
                    </div>
                    <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                      ${formatMath(item.theory || q.theory)}
                    </div>
                  </div>
                ` : ''}

                <div class="bg-white border border-slate-200 rounded-xl p-3.5 space-y-1">
                  <div class="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
                    <i data-lucide="file-check-2" class="w-3.5 h-3.5 text-emerald-600"></i>
                    <span>Các Bước Tính Toán Chi Tiết:</span>
                  </div>
                  <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                    ${formatMath(item.explanation || q.explanation)}
                  </div>
                </div>

                ${(item.tips || q.tips) ? `
                  <div class="bg-amber-50/80 border border-amber-200 rounded-xl p-3 space-y-1">
                    <div class="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                      <i data-lucide="calculator" class="w-4 h-4 text-amber-600"></i>
                      <span>Mẹo Bấm Máy Casio fx-570 Nhanh:</span>
                    </div>
                    <div class="text-xs text-slate-800 math-content leading-relaxed pl-1">
                      ${formatMath(item.tips || q.tips)}
                    </div>
                  </div>
                ` : ''}
              </div>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;

  container.innerHTML = html;

  // 3. Render Ma Trận Điều Hướng Review bên cột phải (Giống hệt lúc thi)
  renderReviewNavMatrix(results);

  if (window.lucide) lucide.createIcons();
  setTimeout(() => {
    triggerMathRender(container);
  }, 100);
}

function renderReviewNavMatrix(results) {
  const p1Container = document.getElementById('review-nav-matrix-p1');
  const p2Container = document.getElementById('review-nav-matrix-p2');
  const p3Container = document.getElementById('review-nav-matrix-p3');

  if (p1Container) {
    p1Container.innerHTML = results.part1.map(item => {
      const isCorrect = item.isCorrect;
      const colorClass = isCorrect ? 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 text-white border-rose-600 hover:bg-rose-700';
      return `
        <button id="review-pill-p1-${item.num}" onclick="scrollToQuestion('review-q-p1-${item.num}')" class="nav-pill w-8 h-8 rounded-lg border text-xs font-bold flex items-center justify-center transition shadow-sm ${colorClass}">
          ${item.num}
        </button>
      `;
    }).join('');
  }

  if (p2Container) {
    p2Container.innerHTML = results.part2.map(item => {
      let colorClass = 'bg-rose-600 text-white border-rose-600';
      if (item.correctCount === 4) {
        colorClass = 'bg-emerald-600 text-white border-emerald-600';
      } else if (item.correctCount > 0) {
        colorClass = 'bg-amber-500 text-white border-amber-500';
      }
      return `
        <button id="review-pill-p2-${item.num}" onclick="scrollToQuestion('review-q-p2-${item.num}')" class="nav-pill w-8 h-8 rounded-lg border text-xs font-bold flex items-center justify-center transition shadow-sm ${colorClass}">
          ${item.num}
        </button>
      `;
    }).join('');
  }

  if (p3Container) {
    p3Container.innerHTML = results.part3.map(item => {
      const isCorrect = item.isCorrect;
      const colorClass = isCorrect ? 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 text-white border-rose-600 hover:bg-rose-700';
      return `
        <button id="review-pill-p3-${item.num}" onclick="scrollToQuestion('review-q-p3-${item.num}')" class="nav-pill w-8 h-8 rounded-lg border text-xs font-bold flex items-center justify-center transition shadow-sm ${colorClass}">
          ${item.num}
        </button>
      `;
    }).join('');
  }
}

function retakeHistoryExam(examId) {
  try {
    const history = JSON.parse(localStorage.getItem('thptqg_exam_history') || '[]');
    const item = history.find(h => h.id === examId);
    if (!item) {
      alert("Không tìm thấy dữ liệu bài thi này!");
      return;
    }
    if (!item.examData) {
      alert("Bài thi này không có dữ liệu câu hỏi để thi lại. Hãy chọn 'Sinh đề mới' để bắt đầu!");
      return;
    }

    const subName = item.subjectName || (item.subject === 'toan' ? 'Toán Học' : (item.subject === 'ly' ? 'Vật Lí' : 'Hóa Học'));
    if (confirm(`Bạn có chắc muốn THI LẠI đề môn ${subName} (Đã làm ngày ${item.date})?\n\n• Toàn bộ câu hỏi và bộ số liệu gốc sẽ được giữ nguyên 100%.\n• Giúp bạn kiểm tra xem mình đã khắc phục được các câu sai trước đó chưa!`)) {
      retakeExamObject(item.examData);
    }
  } catch (err) {
    console.error("Lỗi khi thi lại bài thi:", err);
    alert("Có lỗi xảy ra: " + err.message);
  }
}
window.retakeHistoryExam = retakeHistoryExam;

function retakeCurrentViewingExam() {
  if (!window.CurrentlyViewingExam) return;
  const exam = window.CurrentlyViewingExam;
  if (confirm(`Bạn có muốn THI LẠI đề môn ${exam.subjectName} này ngay bây giờ không?\n\nToàn bộ câu hỏi và các thông số số liệu sẽ được giữ nguyên để bạn luyện tập lại!`)) {
    closeResultsModal();
    retakeExamObject(exam);
  }
}
window.retakeCurrentViewingExam = retakeCurrentViewingExam;


function retakeExamObject(examData) {
  const exam = JSON.parse(JSON.stringify(examData));
  exam.id = exam.id.includes('-retake') ? exam.id : `${exam.id}-retake-${Date.now().toString().slice(-4)}`;

  window.CurrentExam = exam;
  window.CurrentlyViewingExam = exam;
  window.UserAnswers = { part1: {}, part2: {}, part3: {} };

  // Đổi tiêu đề và badge môn học
  const badgeEl = document.getElementById('exam-subject-badge');
  const titleEl = document.getElementById('exam-title-text');
  if (badgeEl) badgeEl.textContent = `${exam.subjectName} (${exam.totalQuestions} câu - ${exam.duration} phút)`;
  if (titleEl) titleEl.textContent = `[THI LẠI] Đề Thi Thử Tốt Nghiệp THPT - Môn ${exam.subjectName} (${exam.totalQuestions} câu - Mã: ${exam.id.slice(-6)})`;

  // Render câu hỏi ra giao diện
  renderExamQuestions(exam);

  // Render bảng điều hướng ma trận
  renderNavMatrix(exam);

  // Khởi động đồng hồ đếm ngược
  startTimer(exam.duration * 60);

  // Chuyển sang Tab phòng thi
  switchTab('exam');
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Tái kích hoạt KaTeX
  setTimeout(() => {
    triggerMathRender();
  }, 100);
}
window.retakeExamObject = retakeExamObject;

function clearHistory() {
  if (confirm("Bạn có chắc chắn muốn xóa toàn bộ lịch sử làm bài?")) {
    localStorage.removeItem('thptqg_exam_history');
    renderHistory();
  }
}

// Hàm kích hoạt render công thức KaTeX
function triggerMathRender(rootEl = document.body) {
  if (window.renderMathInElement) {
    try {
      window.renderMathInElement(rootEl, {
        delimiters: [
          { left: '$$', right: '$$', display: true },
          { left: '$', right: '$', display: false },
          { left: '\\(', right: '\\)', display: false },
          { left: '\\[', right: '\\]', display: true }
        ],
        ignoredTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code'],
        throwOnError: false
      });
    } catch (e) {
      console.warn("KaTeX render error:", e);
    }
  }
}
window.triggerMathRender = triggerMathRender;

// ==========================================
// 5. LỘ TRÌNH ÔN THI 2K9 (THPTQG 2027)
// ==========================================
window.CurrentRoadmapTrack = 'standard'; // 'standard' | 'free'
window.CurrentRoadmapPhase = 'all';

function switchRoadmapTrack(track) {
  window.CurrentRoadmapTrack = track;
  window.CurrentRoadmapPhase = 'all';

  const btnStandard = document.getElementById('track-btn-standard');
  const btnFree = document.getElementById('track-btn-free');
  const badgeText = document.getElementById('roadmap-track-badge-text');
  const heroBadge = document.getElementById('roadmap-hero-badge');
  const heroTitle = document.getElementById('roadmap-hero-title');
  const heroDesc = document.getElementById('roadmap-hero-desc');

  const fP1 = document.getElementById('filter-btn-p1');
  const fP2 = document.getElementById('filter-btn-p2');
  const fP3 = document.getElementById('filter-btn-p3');
  const fP4 = document.getElementById('filter-btn-p4');

  if (track === 'free') {
    if (btnFree) {
      btnFree.className = "px-4 py-2 rounded-lg text-xs font-bold transition bg-emerald-600 text-white shadow-sm flex items-center gap-1.5";
    }
    if (btnStandard) {
      btnStandard.className = "px-4 py-2 rounded-lg text-xs font-bold transition text-slate-600 hover:text-slate-900 flex items-center gap-1.5";
    }
    if (badgeText) badgeText.textContent = "Đang xem: Lộ trình Thí Sinh Tự Do (Ôn lại từ đầu • 0 → 9+)";
    if (heroBadge) heroBadge.textContent = "Dành Riêng Cho Thí Sinh Tự Do • Ôn Lại Từ Con Số 0";
    if (heroTitle) heroTitle.textContent = "Lộ Trình Thí Sinh Tự Do Ôn Lại Từ Đầu - Bứt Phá Điểm 9+";
    if (heroDesc) heroDesc.textContent = "Lộ trình 4 chặng thiết kế chuyên sâu cho thí sinh tự do, mất gốc hoặc muốn ôn lại từ đầu. Quét sạch kiến thức nền tảng, bứt phá chuyên đề SGK mới 2018, rèn phản xạ Casio 570 và làm chủ cấu trúc 3 phần BGD!";

    if (fP1) fP1.textContent = "Chặng 1: Xóa Mất Gốc (0 - 5.5đ)";
    if (fP2) fP2.textContent = "Chặng 2: Bứt Phá Chuyên Đề (5.5 - 7.5đ)";
    if (fP3) fP3.textContent = "Chặng 3: Luyện Đề & Casio (7.5 - 8.8đ)";
    if (fP4) fP4.textContent = "Chặng 4: Tổng Lực Về Đích (9+)";
  } else {
    if (btnStandard) {
      btnStandard.className = "px-4 py-2 rounded-lg text-xs font-bold transition bg-white text-blue-700 shadow-sm flex items-center gap-1.5";
    }
    if (btnFree) {
      btnFree.className = "px-4 py-2 rounded-lg text-xs font-bold transition text-slate-600 hover:text-slate-900 flex items-center gap-1.5";
    }
    if (badgeText) badgeText.textContent = "Đang xem: Lộ trình niên khóa chuẩn 2026 - 2027";
    if (heroBadge) heroBadge.textContent = "Dành Riêng Cho 2k9 • Chương Trình GDPT 2018";
    if (heroTitle) heroTitle.textContent = "Lộ Trình Ôn Thi THPT Quốc Gia 2027 Toàn Diện";
    if (heroDesc) heroDesc.textContent = "Kế hoạch 4 giai đoạn bám sát 100% nội dung Bộ Giáo Dục & Đào Tạo công bố cho lứa học sinh 2009. Quét sạch kiến thức Lớp 12, Lớp 11 và làm chủ định dạng đề thi mới 3 phần!";

    if (fP1) fP1.textContent = "Giai Đoạn 1 (HK1 2026)";
    if (fP2) fP2.textContent = "Giai Đoạn 2 (HK2 2027)";
    if (fP3) fP3.textContent = "Giai Đoạn 3 (Luyện Đề)";
    if (fP4) fP4.textContent = "Giai Đoạn 4 (Về Đích)";
  }

  // Reset nút filter phase về All
  document.querySelectorAll('.roadmap-filter-btn').forEach(btn => {
    if (btn.getAttribute('data-phase') === 'all') {
      btn.classList.add('bg-blue-600', 'text-white');
      btn.classList.remove('bg-slate-100', 'text-slate-700', 'hover:bg-slate-200');
    } else {
      btn.classList.remove('bg-blue-600', 'text-white');
      btn.classList.add('bg-slate-100', 'text-slate-700', 'hover:bg-slate-200');
    }
  });

  renderRoadmap();
}
window.switchRoadmapTrack = switchRoadmapTrack;

function getActiveRoadmap() {
  if (window.CurrentRoadmapTrack === 'free' && window.ROADMAP_FREE_CANDIDATE_2K9) {
    return window.ROADMAP_FREE_CANDIDATE_2K9;
  }
  return window.ROADMAP_2K9 || [];
}

function updateCountdown() {
  const countdownEl = document.getElementById('countdown-days');
  if (!countdownEl) return;

  // Kỳ thi THPT Quốc Gia năm 2027 dự kiến vào ngày 25/06/2027
  const targetDate = new Date('2027-06-25T07:30:00');
  const now = new Date();
  const diffTime = targetDate - now;
  const diffDays = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
  countdownEl.textContent = diffDays.toString();
}

function filterRoadmap(phaseId) {
  window.CurrentRoadmapPhase = phaseId;

  // Cập nhật giao diện nút lọc
  document.querySelectorAll('.roadmap-filter-btn').forEach(btn => {
    if (btn.getAttribute('data-phase') === phaseId) {
      btn.classList.add('bg-blue-600', 'text-white');
      btn.classList.remove('bg-slate-100', 'text-slate-700', 'hover:bg-slate-200');
    } else {
      btn.classList.remove('bg-blue-600', 'text-white');
      btn.classList.add('bg-slate-100', 'text-slate-700', 'hover:bg-slate-200');
    }
  });

  renderRoadmap();
}
window.filterRoadmap = filterRoadmap;

function getCheckedItems() {
  try {
    return JSON.parse(localStorage.getItem('thptqg_roadmap_checked') || '[]');
  } catch (e) {
    return [];
  }
}

function toggleChecklistItem(itemId) {
  let checked = getCheckedItems();
  const idx = checked.indexOf(itemId);
  if (idx >= 0) {
    checked.splice(idx, 1);
  } else {
    checked.push(itemId);
  }
  localStorage.setItem('thptqg_roadmap_checked', JSON.stringify(checked));

  renderRoadmap();
  updateRoadmapProgress();
}
window.toggleChecklistItem = toggleChecklistItem;
window.renderRoadmap = renderRoadmap;
window.renderHistory = renderHistory;

function updateRoadmapProgress() {
  const textEl = document.getElementById('roadmap-progress-text');
  const barEl = document.getElementById('roadmap-progress-bar');
  const activeRoadmap = getActiveRoadmap();
  if (!textEl || !barEl || !activeRoadmap) return;

  const checked = getCheckedItems();
  let totalItems = 0;
  let trackCheckedCount = 0;

  activeRoadmap.forEach(phase => {
    phase.subjects.forEach(sub => {
      sub.items.forEach(it => {
        totalItems++;
        if (checked.includes(it.id)) trackCheckedCount++;
      });
    });
  });

  const percent = totalItems > 0 ? Math.round((trackCheckedCount / totalItems) * 100) : 0;
  textEl.textContent = `${trackCheckedCount} / ${totalItems} mục tiêu (${percent}%)`;
  barEl.style.width = `${percent}%`;
}

function renderRoadmap() {
  const container = document.getElementById('roadmap-phases-container');
  const activeRoadmap = getActiveRoadmap();
  if (!container || !activeRoadmap) return;

  const subjectFilter = document.getElementById('roadmap-subject-select')?.value || 'all';
  const currentPhase = window.CurrentRoadmapPhase;
  const checked = getCheckedItems();

  const phases = activeRoadmap.filter(p => currentPhase === 'all' || p.phaseId === currentPhase);

  container.innerHTML = phases.map(phase => {
    const isOngoing = phase.status === 'Đang diễn ra' || phase.status === 'Bắt đầu ngay';
    const statusBg = isOngoing ? 'bg-emerald-100 text-emerald-800 border-emerald-200' : (phase.status === 'Sắp tới' ? 'bg-indigo-100 text-indigo-800 border-indigo-200' : 'bg-slate-100 text-slate-700 border-slate-200');

    // Lọc môn học
    const filteredSubjects = phase.subjects.filter(sub => {
      if (subjectFilter === 'all') return true;
      return sub.subjectName === subjectFilter || sub.subjectName.includes(subjectFilter);
    });

    if (filteredSubjects.length === 0) return '';

    return `
      <div class="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
        <!-- Phase Header -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-5">
          <div class="space-y-1">
            <div class="flex items-center gap-2.5">
              <span class="px-3 py-1 rounded-full text-xs font-bold border ${statusBg}">
                ${phase.status}
              </span>
              <span class="text-xs font-semibold text-slate-500 font-mono flex items-center gap-1">
                <i data-lucide="calendar" class="w-3.5 h-3.5"></i> ${phase.timeframe}
              </span>
            </div>
            <h3 class="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              ${phase.phaseName}
            </h3>
            <p class="text-slate-600 text-sm leading-relaxed">${phase.description}</p>
          </div>
          <div class="text-xs bg-amber-50 text-amber-900 px-4 py-2.5 rounded-xl font-medium border border-amber-200 shrink-0 self-start sm:self-center">
            ${phase.target}
          </div>
        </div>

        <!-- Subjects Grid -->
        <div class="grid grid-cols-1 ${filteredSubjects.length > 1 ? 'md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-6">
          ${filteredSubjects.map(sub => `
            <div class="bg-slate-50/70 rounded-2xl p-5 border border-slate-200 flex flex-col justify-between space-y-4">
              <div class="space-y-3">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2 font-bold text-base text-slate-900">
                    <span class="w-7 h-7 rounded-lg ${sub.color} flex items-center justify-center text-sm font-bold shadow-sm">
                      ${sub.icon}
                    </span>
                    ${sub.subjectName}
                  </div>
                  <span class="text-[11px] font-semibold text-slate-400">
                    ${sub.items.filter(it => checked.includes(it.id)).length}/${sub.items.length} đã xong
                  </span>
                </div>

                <!-- Checklist Items -->
                <div class="space-y-2 pt-1">
                  ${sub.items.map(it => {
                    const isDone = checked.includes(it.id);
                    return `
                      <label class="flex items-start gap-3 p-2.5 rounded-xl border ${isDone ? 'bg-emerald-50/50 border-emerald-200' : 'bg-white border-slate-200'} hover:border-blue-400 transition cursor-pointer select-none">
                        <input type="checkbox" onchange="toggleChecklistItem('${it.id}')" ${isDone ? 'checked' : ''} class="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500 mt-0.5 cursor-pointer">
                        <div class="flex-1 space-y-1">
                          <span class="text-xs font-medium leading-snug block ${isDone ? 'line-through text-slate-400 font-normal' : 'text-slate-800'}">
                            ${it.text}
                          </span>
                          <span class="inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600">
                            ${it.tag}
                          </span>
                        </div>
                      </label>
                    `;
                  }).join('')}
                </div>
              </div>

              <!-- Quick action to generate exam -->
              <div class="pt-2 border-t border-slate-200">
                <button onclick="startGeneratedExam('${sub.subjectName.includes('Toán') ? 'toan' : (sub.subjectName.includes('Lí') ? 'ly' : (sub.subjectName.includes('Hóa') ? 'hoa' : 'toan'))}')" class="w-full text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 py-2 rounded-xl transition flex items-center justify-center gap-1.5 shadow-sm">
                  <i data-lucide="play-circle" class="w-3.5 h-3.5"></i> Thi Thử Chuyên Đề Này (Đổi Số)
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');

  updateRoadmapProgress();

  if (window.lucide) lucide.createIcons();
  setTimeout(() => {
    triggerMathRender();
  }, 100);
}

// Helper for Google Drive preview
function getDrivePreviewUrl(url) {
  if (!url) return '';
  const m = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (m && m[1]) {
    return `https://drive.google.com/file/d/${m[1]}/preview`;
  }
  return url;
}
window.getDrivePreviewUrl = getDrivePreviewUrl;

function switchModalDocPreview(url, tabType) {
  const iframe = document.getElementById('modal-doc-preview-frame');
  const btnDe = document.getElementById('btn-tab-preview-de');
  const btnVietTay = document.getElementById('btn-tab-preview-viettay');
  if (iframe) iframe.src = url;
  if (tabType === 'de') {
    if (btnDe) btnDe.className = "px-3.5 py-1.5 rounded-lg text-xs font-bold transition bg-blue-600 text-white shadow-sm";
    if (btnVietTay) btnVietTay.className = "px-3.5 py-1.5 rounded-lg text-xs font-bold transition text-slate-600 hover:bg-slate-100";
  } else {
    if (btnDe) btnDe.className = "px-3.5 py-1.5 rounded-lg text-xs font-bold transition text-slate-600 hover:bg-slate-100";
    if (btnVietTay) btnVietTay.className = "px-3.5 py-1.5 rounded-lg text-xs font-bold transition bg-emerald-600 text-white shadow-sm";
  }
}
window.switchModalDocPreview = switchModalDocPreview;

// ==========================================
// 6. XEM & ÔN TẬP TÀI LIỆU TRỰC TIẾP (STUDY MODAL)
// ==========================================
function openDocStudyModal(docId) {
  const docs = window.DOCUMENTS_DATA || [];
  const doc = docs.find(d => d.id === docId);
  if (!doc) return;

  const modal = document.getElementById('doc-study-modal');
  if (!modal) return;

  const subjectBadges = {
    toan: { name: "Toán Học" },
    ly: { name: "Vật Lí" },
    hoa: { name: "Hóa Học" }
  };
  const subInfo = subjectBadges[doc.subject] || { name: doc.subject };

  const badgeEl = document.getElementById('doc-modal-badge');
  const yearEl = document.getElementById('doc-modal-year');
  const titleEl = document.getElementById('doc-modal-title');
  const descEl = document.getElementById('doc-modal-desc');

  if (badgeEl) badgeEl.textContent = subInfo.name;
  if (yearEl) yearEl.textContent = `Lớp ${doc.grade} • Năm ${doc.year} • Nguồn: ${doc.source}`;
  if (titleEl) titleEl.textContent = doc.title;
  if (descEl) descEl.textContent = doc.description;

  const sourceLink = document.getElementById('doc-modal-source-link');
  if (sourceLink) {
    sourceLink.href = doc.link || '#';
  }

  const genBtn = document.getElementById('doc-modal-generate-btn');
  if (genBtn) {
    genBtn.onclick = () => {
      closeDocStudyModal();
      startGeneratedExam(doc.subject);
    };
  }

  const contentContainer = document.getElementById('doc-modal-content');
  if (contentContainer) {
    let html = '';

    // Khối 1: Tệp đính kèm khóa học (File Đề, Lời Giải Viết Tay, Video, Preview Trực Tiếp)
    const hasSpecialFiles = doc.fileDe || doc.fileVietTay || doc.video;
    if (hasSpecialFiles) {
      const defaultPreview = doc.fileVietTay ? getDrivePreviewUrl(doc.fileVietTay) : getDrivePreviewUrl(doc.fileDe);
      let courseBadgeText = "Tài Liệu Khóa Học & Đề Thi";
      let courseBadgeColor = "bg-emerald-600";
      if (doc.category === "mapstudy-ly" || doc.category === "ve-dich-ly") {
        courseBadgeText = "Khóa 14 Ngày Tổng Ôn - Mapstudy (Thầy Vũ Ngọc Anh)";
        courseBadgeColor = "bg-sky-600";
      } else if (doc.category === "toan-1000-dung-sai" || doc.category === "1000-cau-toan") {
        courseBadgeText = "Khóa 1000 Câu Đúng Sai - Thầy Đỗ Văn Đức (IMO)";
        courseBadgeColor = "bg-indigo-600";
      } else if (doc.category === "ly-thuyet-ly-1000" || doc.category === "1000-cau-ly") {
        courseBadgeText = "1000 Câu Lý Thuyết Vật Lí 10 - 11 - 12 Trọng Tâm (Chuẩn BGD)";
        courseBadgeColor = "bg-purple-600";
      } else if (doc.category === "imo-hoa") {
        courseBadgeText = "Khóa Live M - Thầy Phạm Thắng (Hóa Học 2025)";
        courseBadgeColor = "bg-teal-600";
      } else if (doc.category === "ve-dich-hoa") {
        courseBadgeText = "Khóa 14 Ngày Về Đích Hóa Học (59 Buổi Thầy Phạm Thắng)";
        courseBadgeColor = "bg-emerald-600";
      } else if (doc.category === "chuyen-de-10-11") {
        courseBadgeText = `Chuyên Đề Trọng Tâm Lớp ${doc.grade} Chuẩn GDPT 2018`;
        courseBadgeColor = "bg-blue-600";
      } else {
        courseBadgeText = doc.source || "Tài Liệu Ôn Thi Chuẩn BGD";
        courseBadgeColor = "bg-indigo-600";
      }

      html += `
        <div class="bg-gradient-to-br from-emerald-50 via-teal-50 to-blue-50 border border-emerald-200/80 rounded-3xl p-6 space-y-5 shadow-sm">
          <div class="flex flex-wrap items-center justify-between gap-3">
            <div>
              <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black ${courseBadgeColor} text-white uppercase tracking-wider mb-1.5 shadow-sm">
                <i data-lucide="zap" class="w-3.5 h-3.5"></i> ${courseBadgeText}
              </span>
              <h4 class="font-black text-slate-900 text-lg flex items-center gap-2">
                <i data-lucide="file-check-2" class="w-5 h-5 text-emerald-600"></i>
                Tài Liệu Đính Kèm Buổi Học (File Đề & Lời Giải Viết Tay)
              </h4>
            </div>
            ${doc.buoiHoc ? `
              <div class="px-3.5 py-1.5 bg-white border border-emerald-200 text-emerald-800 rounded-2xl font-bold text-xs shadow-sm flex items-center gap-2">
                <span>${doc.buoiHoc}</span>
                ${doc.caLive ? `<span class="text-slate-300">•</span> <span>Ca ${doc.caLive}</span>` : ''}
                ${doc.ngayLive ? `<span class="text-slate-300">•</span> <span class="text-slate-500">${doc.ngayLive}</span>` : ''}
              </div>
            ` : ''}
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            ${doc.fileDe ? `
              <a href="${doc.fileDe}" target="_blank" class="flex items-center justify-between p-4 bg-white hover:bg-blue-50 border border-blue-200 rounded-2xl text-blue-900 font-bold text-xs shadow-sm hover:shadow transition group">
                <span class="flex items-center gap-2.5">
                  <div class="w-8 h-8 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                    <i data-lucide="file-text" class="w-4 h-4"></i>
                  </div>
                  <span>
                    <span class="block text-[11px] text-slate-500 font-medium">Bản in chuẩn</span>
                    📄 Mở File Đề (Drive)
                  </span>
                </span>
                <i data-lucide="external-link" class="w-4 h-4 text-blue-400 group-hover:text-blue-600"></i>
              </a>
            ` : ''}
            ${doc.fileVietTay ? `
              <a href="${doc.fileVietTay}" target="_blank" class="flex items-center justify-between p-4 bg-white hover:bg-emerald-50 border-2 border-emerald-300 rounded-2xl text-emerald-900 font-bold text-xs shadow-sm hover:shadow transition group">
                <span class="flex items-center gap-2.5">
                  <div class="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                    <i data-lucide="check-circle" class="w-4 h-4"></i>
                  </div>
                  <span>
                    <span class="block text-[11px] text-emerald-600 font-semibold">Lời giải cụ thể</span>
                    ✍️ Lời Giải Viết Tay (Drive)
                  </span>
                </span>
                <i data-lucide="external-link" class="w-4 h-4 text-emerald-500 group-hover:text-emerald-700"></i>
              </a>
            ` : ''}
            ${doc.video ? `
              <a href="${doc.video}" target="_blank" class="flex items-center justify-between p-4 bg-white hover:bg-rose-50 border border-rose-200 rounded-2xl text-rose-900 font-bold text-xs shadow-sm hover:shadow transition group">
                <span class="flex items-center gap-2.5">
                  <div class="w-8 h-8 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                    <i data-lucide="video" class="w-4 h-4"></i>
                  </div>
                  <span>
                    <span class="block text-[11px] text-slate-500 font-medium">Livestream chữa</span>
                    🎬 Video Chữa Đề
                  </span>
                </span>
                <i data-lucide="external-link" class="w-4 h-4 text-rose-400 group-hover:text-rose-600"></i>
              </a>
            ` : ''}
          </div>

          <!-- Trình xem trước file Google Drive trực tiếp trong trang -->
          ${(doc.fileDe || doc.fileVietTay) ? `
            <div class="mt-4 pt-4 border-t border-emerald-200/60 space-y-3">
              <div class="flex flex-wrap items-center justify-between gap-2">
                <div class="flex items-center gap-2 text-xs font-bold text-slate-800">
                  <i data-lucide="monitor" class="w-4 h-4 text-emerald-600"></i>
                  <span>Trình xem tài liệu trực tiếp trên web:</span>
                </div>
                <div class="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 shadow-sm">
                  ${doc.fileVietTay ? `
                    <button id="btn-tab-preview-viettay" onclick="switchModalDocPreview('${getDrivePreviewUrl(doc.fileVietTay)}', 'viettay')" class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition bg-emerald-600 text-white shadow-sm">
                      ✍️ Lời Giải Viết Tay
                    </button>
                  ` : ''}
                  ${doc.fileDe ? `
                    <button id="btn-tab-preview-de" onclick="switchModalDocPreview('${getDrivePreviewUrl(doc.fileDe)}', 'de')" class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition text-slate-600 hover:bg-slate-100">
                      📄 File Đề
                    </button>
                  ` : ''}
                </div>
              </div>
              <div class="w-full bg-slate-900 rounded-2xl overflow-hidden shadow-md border border-slate-300 relative" style="height: 520px;">
                <iframe id="modal-doc-preview-frame" src="${defaultPreview}" class="w-full h-full border-0" allow="autoplay"></iframe>
              </div>
              <div class="text-[11px] text-slate-500 flex items-center justify-between">
                <span>💡 Nếu tài liệu không tải trong khung, bấm nút liên kết mở trên Drive ở trên để xem toàn màn hình.</span>
                <span class="font-medium text-emerald-700">Đã đồng bộ Google Drive</span>
              </div>
            </div>
          ` : ''}
        </div>
      `;
    }

    if (doc.studyContent) {
      const sc = doc.studyContent;

      // 1. Lý thuyết trọng tâm
      if (sc.theory && sc.theory.length > 0) {
        html += `
          <div class="space-y-4">
            <div class="flex items-center gap-2 text-blue-700 font-bold text-lg border-b border-blue-100 pb-2">
              <i data-lucide="file-text" class="w-5 h-5"></i>
              <h4>1. Tóm Tắt Lý Thuyết Trọng Tâm</h4>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              ${sc.theory.map(t => `
                <div class="bg-blue-50/50 border border-blue-100 rounded-2xl p-4 space-y-2">
                  <h5 class="font-bold text-sm text-blue-900 flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-blue-600"></span>
                    ${t.title}
                  </h5>
                  <ul class="text-xs text-slate-700 space-y-1.5 list-disc list-inside">
                    ${t.points.map(pt => `<li class="math-content leading-relaxed">${formatMath(pt)}</li>`).join('')}
                  </ul>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }

      // 2. Bảng công thức trọng tâm / Ghi nhớ
      if (sc.keyFormulas && sc.keyFormulas.length > 0) {
        html += `
          <div class="space-y-4">
            <div class="flex items-center gap-2 text-indigo-700 font-bold text-lg border-b border-indigo-100 pb-2">
              <i data-lucide="function-square" class="w-5 h-5"></i>
              <h4>Cấu Trúc & Trọng Tâm Kiến Thức Cần Ghi Nhớ</h4>
            </div>
            <div class="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-5 space-y-2.5">
              <ul class="text-xs text-slate-800 space-y-2 list-disc list-inside">
                ${sc.keyFormulas.map(kf => `<li class="math-content leading-relaxed font-medium">${formatMath(kf)}</li>`).join('')}
              </ul>
            </div>
          </div>
        `;
      }

      if (sc.formulas && sc.formulas.length > 0) {
        html += `
          <div class="space-y-4">
            <div class="flex items-center gap-2 text-indigo-700 font-bold text-lg border-b border-indigo-100 pb-2">
              <i data-lucide="function-square" class="w-5 h-5"></i>
              <h4>Bảng Công Thức Cần Ghi Nhớ</h4>
            </div>
            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse border border-slate-200 rounded-xl overflow-hidden bg-white text-xs">
                <thead>
                  <tr class="bg-slate-100 text-slate-700 font-bold uppercase">
                    <th class="p-3 w-1/4">Tên quy tắc / Đại lượng</th>
                    <th class="p-3 w-2/5">Công thức toán / Định luật</th>
                    <th class="p-3">Ghi chú & Điều kiện áp dụng</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                  ${sc.formulas.map(f => `
                    <tr class="hover:bg-slate-50 transition">
                      <td class="p-3 font-bold text-slate-900">${f.name}</td>
                      <td class="p-3 text-indigo-700 font-medium math-content text-sm">${formatMath(f.formula)}</td>
                      <td class="p-3 text-slate-600 math-content">${formatMath(f.note)}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        `;
      }

      // 3. Ví dụ mẫu & Phương pháp giải
      if (sc.examples && sc.examples.length > 0) {
        html += `
          <div class="space-y-4">
            <div class="flex items-center gap-2 text-purple-700 font-bold text-lg border-b border-purple-100 pb-2">
              <i data-lucide="help-circle" class="w-5 h-5"></i>
              <h4>Ví Dụ Điển Hình & Phương Pháp Giải</h4>
            </div>
            <div class="space-y-4">
              ${sc.examples.map((ex, idx) => `
                <div class="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-3">
                  <div class="flex items-center gap-2">
                    <span class="bg-purple-600 text-white font-bold text-xs px-2.5 py-0.5 rounded-lg">Ví dụ ${idx + 1}</span>
                    <span class="text-xs font-semibold text-slate-500">Dạng bài thi chuẩn</span>
                  </div>
                  <div class="text-sm font-semibold text-slate-900 math-content leading-relaxed">
                    ${formatMath(ex.q)}
                  </div>
                  <div class="bg-white p-4 rounded-xl border border-slate-200/80 text-xs text-slate-700 space-y-1.5 math-content leading-relaxed">
                    <div class="font-bold text-emerald-700 flex items-center gap-1.5">
                      <i data-lucide="check-circle" class="w-4 h-4"></i> Hướng dẫn giải chi tiết:
                    </div>
                    <div class="pl-2 border-l-2 border-emerald-400 mt-2 whitespace-pre-line">
                      ${formatMath(ex.a)}
                    </div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }

      // 4. Lời khuyên ôn tập / studyTips
      if (sc.studyTips && sc.studyTips.length > 0) {
        html += `
          <div class="space-y-3">
            <div class="flex items-center gap-2 text-amber-700 font-bold text-lg border-b border-amber-100 pb-2">
              <i data-lucide="lightbulb" class="w-5 h-5"></i>
              <h4>Chiến Thuật & Lời Khuyên Ôn Luyện</h4>
            </div>
            <div class="bg-amber-50/60 border border-amber-200 rounded-2xl p-5 space-y-2">
              <ul class="text-xs text-slate-700 space-y-2 list-disc list-inside">
                ${sc.studyTips.map(st => `<li class="font-medium leading-relaxed">${st}</li>`).join('')}
              </ul>
            </div>
          </div>
        `;
      }
    }

    if (!html) {
      html = `
        <div class="p-8 text-center text-slate-500 space-y-4">
          <p>Tài liệu này liên kết trực tiếp với tài liệu gốc bên ngoài.</p>
          <a href="${doc.link}" target="_blank" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm px-6 py-3 rounded-xl transition">
            <i data-lucide="external-link" class="w-4 h-4"></i> Mở Liên Kết Tài Liệu
          </a>
        </div>
      `;
    }

    contentContainer.innerHTML = html;
  }

  modal.classList.remove('hidden');
  if (window.lucide) lucide.createIcons();
  setTimeout(() => {
    triggerMathRender(modal);
  }, 100);
}
window.openDocStudyModal = openDocStudyModal;

function closeDocStudyModal() {
  const modal = document.getElementById('doc-study-modal');
  if (modal) modal.classList.add('hidden');
}
window.closeDocStudyModal = closeDocStudyModal;

function copyDocLink() {
  const sourceLink = document.getElementById('doc-modal-source-link')?.href || window.location.href;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(sourceLink).then(() => {
      alert("Đã sao chép liên kết tài liệu!");
    }).catch(() => {
      prompt("Sao chép liên kết:", sourceLink);
    });
  } else {
    prompt("Sao chép liên kết:", sourceLink);
  }
}
window.copyDocLink = copyDocLink;


