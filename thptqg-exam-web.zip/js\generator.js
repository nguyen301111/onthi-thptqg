// Bộ máy sinh đề thi tham số hóa (Parametric Exam Generator)
// Đổi số liệu tự động theo đúng khuôn mẫu chuẩn của Bộ GD&ĐT 2025 và 2026
// Chuẩn số lượng câu:
// - Môn Toán: 12 câu Phần I, 4 câu Phần II, 6 câu Phần III (Tổng 22 câu - 90 phút - Thang điểm 10)
// - Môn Vật Lí: 18 câu Phần I, 4 câu Phần II, 6 câu Phần III (Tổng 28 câu - 50 phút - Thang điểm 10)
// - Môn Hóa Học: 18 câu Phần I, 4 câu Phần II, 6 câu Phần III (Tổng 28 câu - 50 phút - Thang điểm 10)

window.ExamGenerator = {
  // Tạo một đề thi mới với các số liệu được đổi ngẫu nhiên
  generateExam: function(subjectKey) {
    const subjectTemplates = window.EXAM_TEMPLATES[subjectKey];
    if (!subjectTemplates) {
      console.error("Không tìm thấy mẫu đề cho môn:", subjectKey);
      return null;
    }

    const exam = {
      id: "EXAM_" + subjectKey.toUpperCase() + "_" + Date.now(),
      subject: subjectKey,
      subjectName: subjectKey === "toan" ? "Toán Học" : (subjectKey === "ly" ? "Vật Lí" : "Hóa Học"),
      duration: subjectTemplates.duration, // phút
      createdAt: new Date().toISOString(),
      part1: [], // Trắc nghiệm 4 lựa chọn
      part2: [], // Trắc nghiệm Đúng / Sai
      part3: [], // Trắc nghiệm trả lời ngắn
      totalQuestions: 0
    };

    // Số lượng câu chuẩn theo quy định của BGD 2025/2026
    const countP1 = subjectTemplates.part1_count || (subjectKey === "toan" ? 12 : 18);
    const countP2 = subjectTemplates.part2_count || 4;
    const countP3 = subjectTemplates.part3_count || 6;

    // 1. Sinh Phần I: Trắc nghiệm 4 lựa chọn
    const p1List = subjectTemplates.templates_part1;
    const p1Selected = p1List.slice(0, countP1);
    for (let i = 0; i < p1Selected.length; i++) {
      const t = p1Selected[i];
      const qData = t.generate();
      
      // Xáo trộn 4 đáp án A, B, C, D
      const optionsWithIndices = qData.options.map((opt, idx) => ({ text: opt, isOriginalCorrect: idx === qData.correctIndex }));
      // Fisher-Yates shuffle
      for (let j = optionsWithIndices.length - 1; j > 0; j--) {
        const k = Math.floor(Math.random() * (j + 1));
        [optionsWithIndices[j], optionsWithIndices[k]] = [optionsWithIndices[k], optionsWithIndices[j]];
      }

      const correctIndex = optionsWithIndices.findIndex(item => item.isOriginalCorrect);
      const labels = ["A", "B", "C", "D"];

      exam.part1.push({
        num: i + 1,
        part: 1,
        topic: t.topic || "Trắc nghiệm tổng hợp",
        content: qData.content,
        options: optionsWithIndices.map((item, idx) => ({ label: labels[idx], text: item.text })),
        correctOption: labels[correctIndex],
        correctIndex: correctIndex,
        theory: qData.theory || "",
        explanation: qData.explanation || "",
        tips: qData.tips || ""
      });
    }

    // 2. Sinh Phần II: Trắc nghiệm Đúng / Sai
    const p2List = subjectTemplates.templates_part2;
    const p2Selected = p2List.slice(0, countP2);
    for (let i = 0; i < p2Selected.length; i++) {
      const t = p2Selected[i];
      const qData = t.generate();
      exam.part2.push({
        num: i + 1,
        part: 2,
        topic: t.topic || "Chuyên đề Đúng/Sai",
        content: qData.content,
        theory: qData.theory || "",
        tips: qData.tips || "",
        statements: qData.statements.map(s => ({
          label: s.label,
          text: s.text,
          isCorrect: s.isCorrect,
          explanation: s.exp || s.explanation || "",
          theory: s.theory || qData.theory || ""
        }))
      });
    }

    // 3. Sinh Phần III: Trả lời ngắn
    const p3List = subjectTemplates.templates_part3;
    const p3Selected = p3List.slice(0, countP3);
    for (let i = 0; i < p3Selected.length; i++) {
      const t = p3Selected[i];
      const qData = t.generate();
      exam.part3.push({
        num: i + 1,
        part: 3,
        topic: t.topic || "Trả lời ngắn tính toán",
        content: qData.content,
        correctAnswer: qData.correctAnswer,
        theory: qData.theory || "",
        explanation: qData.explanation || "",
        tips: qData.tips || ""
      });
    }

    exam.totalQuestions = exam.part1.length + exam.part2.length + exam.part3.length;
    return exam;
  },

  // Barem chấm điểm chính xác theo quy chuẩn Bộ Giáo Dục & Đào Tạo năm 2025 và 2026
  gradeExam: function(exam, userAnswers) {
    let scorePart1 = 0;
    let scorePart2 = 0;
    let scorePart3 = 0;

    const results = {
      examId: exam.id,
      subject: exam.subject,
      subjectName: exam.subjectName,
      part1: [],
      part2: [],
      part3: [],
      scorePart1: 0,
      scorePart2: 0,
      scorePart3: 0,
      totalScore: 0,
      maxScore: 10
    };

    // Hệ số điểm từng câu:
    // Toán (22 câu): P1 = 12 * 0.25 = 3.0đ; P2 = 4 * 1.0 = 4.0đ; P3 = 6 * 0.5 = 3.0đ. Tổng = 10đ.
    // Lí / Hóa (28 câu): P1 = 18 * 0.25 = 4.5đ; P2 = 4 * 1.0 = 4.0đ; P3 = 6 * 0.25 = 1.5đ. Tổng = 10đ.
    const p1Weight = 0.25;
    const p3Weight = exam.subject === "toan" ? 0.5 : 0.25;

    // Chấm Phần I
    exam.part1.forEach(q => {
      const userChoice = userAnswers.part1[q.num];
      const isCorrect = userChoice === q.correctOption;
      if (isCorrect) {
        scorePart1 += p1Weight;
      }
      results.part1.push({
        num: q.num,
        topic: q.topic,
        userChoice: userChoice || "Chưa chọn",
        correctOption: q.correctOption,
        isCorrect: isCorrect,
        points: isCorrect ? p1Weight : 0,
        theory: q.theory,
        explanation: q.explanation,
        tips: q.tips
      });
    });

    // Chấm Phần II (Quy chuẩn tích lũy điểm BGD 2025/2026: Đúng 1 ý = 0.1; 2 ý = 0.25; 3 ý = 0.5; 4 ý = 1.0)
    const part2Rubric = { 0: 0.0, 1: 0.1, 2: 0.25, 3: 0.5, 4: 1.0 };
    exam.part2.forEach(q => {
      let correctCount = 0;
      const statementDetails = [];

      q.statements.forEach(st => {
        const userChoice = userAnswers.part2 && userAnswers.part2[q.num] ? userAnswers.part2[q.num][st.label] : null;
        const isMatched = userChoice === st.isCorrect;
        if (isMatched) correctCount++;

        statementDetails.push({
          label: st.label,
          text: st.text,
          userChoice: userChoice !== null ? (userChoice ? "Đúng" : "Sai") : "Chưa chọn",
          correctAnswer: st.isCorrect ? "Đúng" : "Sai",
          isMatched: isMatched,
          explanation: st.explanation,
          theory: st.theory
        });
      });

      const qPoints = part2Rubric[correctCount] || 0;
      scorePart2 += qPoints;

      results.part2.push({
        num: q.num,
        topic: q.topic,
        correctCount: correctCount,
        points: qPoints,
        statements: statementDetails,
        theory: q.theory,
        tips: q.tips
      });
    });

    // Chấm Phần III: So sánh chuỗi số (bỏ khoảng trắng và chuẩn hóa dấu chấm/phẩy)
    exam.part3.forEach(q => {
      const rawUserAns = userAnswers.part3 ? userAnswers.part3[q.num] : "";
      const cleanUser = (rawUserAns || "").toString().trim().replace(/,/g, '.');
      const cleanCorrect = q.correctAnswer.toString().trim().replace(/,/g, '.');

      let isCorrect = cleanUser === cleanCorrect;
      // Hỗ trợ kiểm tra số thực với dung sai sai số nhỏ 0.05
      if (!isCorrect && !isNaN(parseFloat(cleanUser)) && !isNaN(parseFloat(cleanCorrect))) {
        if (Math.abs(parseFloat(cleanUser) - parseFloat(cleanCorrect)) < 0.05) {
          isCorrect = true;
        }
      }

      if (isCorrect) {
        scorePart3 += p3Weight;
      }

      results.part3.push({
        num: q.num,
        topic: q.topic,
        userAns: cleanUser || "Chưa nhập",
        correctAns: q.correctAnswer,
        isCorrect: isCorrect,
        points: isCorrect ? p3Weight : 0,
        theory: q.theory,
        explanation: q.explanation,
        tips: q.tips
      });
    });

    results.scorePart1 = Math.round(scorePart1 * 100) / 100;
    results.scorePart2 = Math.round(scorePart2 * 100) / 100;
    results.scorePart3 = Math.round(scorePart3 * 100) / 100;
    results.totalScore = Math.min(10, Math.round((scorePart1 + scorePart2 + scorePart3) * 100) / 100);

    return results;
  }
};
