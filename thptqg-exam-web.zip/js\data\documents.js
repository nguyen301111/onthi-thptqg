﻿// Kho dữ liệu tài liệu ôn thi THPT Quốc Gia môn Toán - Lí - Hóa chuẩn GDPT 2018
// Tích hợp tóm tắt lý thuyết, công thức cốt lõi và bài tập mẫu đọc trực tiếp không sợ lỗi link
// Bổ sung đầy đủ tài liệu ôn tập lớp 10, lớp 11 và ngân hàng đề thi chuẩn BGD từ các khóa học uy tín

window.DOCUMENTS_DATA = [
  {
    id: "toan-01",
    subject: "toan",
    title: "Đề Minh Họa Tốt Nghiệp THPT 2025 Môn Toán - Bộ GD&ĐT",
    grade: 12,
    category: "de-thi",
    source: "Bộ Giáo Dục & Đào Tạo",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Đề thi minh họa chính thức của Bộ GD&ĐT theo cấu trúc mới: 12 câu trắc nghiệm nhiều lựa chọn, 4 câu Đúng/Sai, 6 câu trả lời ngắn.",
    link: "https://moet.gov.vn/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Đề minh họa", "Chuẩn BGD", "Toán 12", "Cấu trúc 2025"],
    downloads: 18450,
    featured: true,
    studyContent: {
        summary: "Đề thi đánh giá năng lực tư duy toán học toàn diện, tập trung vào khả năng mô hình hóa toán học các hiện tượng thực tế, giải quyết vấn đề và tính toán chính xác.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Đạo hàm: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Tiệm cận xiên: y = ax + b với a = lim f(x)/x, b = lim [f(x) - ax]",
          "Khoảng cách điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "15 phút cho 12 câu TN, 35 phút cho 4 câu Đúng/Sai, 40 phút cho 6 câu Trả lời ngắn."
        ]
      }
  },
  {
    id: "toan-02",
    subject: "toan",
    title: "Chuyên Đề Ứng Dụng Đạo Hàm Khảo Sát & Vẽ Đồ Thị Hàm Số (SGK Mới)",
    grade: 12,
    category: "chuyen-de",
    source: "Nhóm Giáo Viên Toán THPT Chuyên KHTN",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Hệ thống toàn bộ dạng toán về tính đơn điệu, cực trị, giá trị lớn nhất - nhỏ nhất và các bài toán thực tế tối ưu hóa chi phí, dung tích.",
    link: "https://toanmath.com/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Khảo sát hàm số", "Bài toán thực tế", "Lý thuyết & Bài tập"],
    downloads: 14200,
    featured: true,
    studyContent: {
        summary: "Hàm số đồng biến trên K khi y' >= 0, nghịch biến khi y' <= 0. Cực trị xảy ra tại điểm đạo hàm đổi dấu.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Hàm bậc nhất / bậc nhất: (ax + b)/(cx + d)' = (ad - bc) / (cx + d)^2",
          "Độ lệch chuẩn: s = sqrt(s^2)"
        ],
        studyTips: [
          "Lập bảng biến thiên rõ ràng trước khi kết luận GTLN, GTNN."
        ]
      }
  },
  {
    id: "toan-03",
    subject: "toan",
    title: "Chuyên Đề Nguyên Hàm, Tích Phân & Ứng Dụng Thực Tiễn Tính Diện Tích, Thể Tích",
    grade: 12,
    category: "chuyen-de",
    source: "Tổ Toán THPT Chuyên Amsterdam",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Đầy đủ các phương pháp đổi biến số, từng phần và các bài toán mô hình hóa hình học thực tiễn: tính thể tích bồn nước, diện tích cánh buồm.",
    link: "https://toanmath.com/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Tích phân", "Nguyên hàm", "Ứng dụng hình học", "Toán 12"],
    downloads: 16100,
    featured: false,
    studyContent: {
        summary: "Tích phân xác định diện tích hình phẳng giới hạn bởi đồ thị hàm số và trục hoành, cũng như thể tích vật thể tròn xoay.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Diện tích hình phẳng: S = tích phân |f(x) - g(x)| dx",
          "Thể tích tròn xoay: V = pi * tích phân f(x)^2 dx"
        ],
        studyTips: [
          "Tìm hoành độ giao điểm trước khi phá dấu giá trị tuyệt đối."
        ]
      }
  },
  {
    id: "toan-04",
    subject: "toan",
    title: "Chuyên Đề Phương Pháp Tọa Độ Trong Không Gian Oxyz (Chương Trình 2018)",
    grade: 12,
    category: "chuyen-de",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Hệ tọa độ không gian, vectơ, phương trình mặt phẳng, phương trình đường thẳng, mặt cầu và các bài toán cực trị hình học Oxyz.",
    link: "https://toanmath.com/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Oxyz", "Hình học không gian", "Mặt phẳng", "Đường thẳng", "Mặt cầu"],
    downloads: 19500,
    featured: true,
    studyContent: {
        summary: "Phương pháp tọa độ hóa giúp chuyển các bài toán hình học không gian phức tạp thành đại số tính toán qua tích có hướng.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Tích có hướng: [u, v] = (y1*z2 - z1*y2, z1*x2 - x1*z2, x1*y2 - y1*x2)",
          "Mặt phẳng qua M0 có VTPT n(A;B;C): A(x - x0) + B(y - y0) + C(z - z0) = 0"
        ],
        studyTips: [
          "Kiểm tra tính đồng phẳng bằng điều kiện [a, b] . c = 0."
        ]
      }
  },
  {
    id: "ly-01",
    subject: "ly",
    title: "Đề Minh Họa Tốt Nghiệp THPT 2025 Môn Vật Lí - Bộ GD&ĐT",
    grade: 12,
    category: "de-thi",
    source: "Bộ Giáo Dục & Đào Tạo",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Đề minh họa theo cấu trúc mới của Bộ GD&ĐT: 18 câu nhiều phương án lựa chọn, 4 câu Đúng/Sai, 6 câu Trả lời ngắn.",
    link: "https://moet.gov.vn/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Đề minh họa", "Vật lí 12", "Cấu trúc 2025", "Bộ GD&ĐT"],
    downloads: 17800,
    featured: true,
    studyContent: {
        summary: "Đề thi nhấn mạnh vào kiến thức Vật lý nhiệt, Khí lý tưởng, Từ trường và Vật lý hạt nhân theo chương trình giáo dục phổ thông mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Nhiệt lượng: Q = mc*deltaT = mL = m*lambda",
          "Phương trình khí lý tưởng: pV = nRT = (m/mu)RT",
          "Lực từ: F = BIl*sin(alpha)"
        ],
        studyTips: [
          "Đổi nhiệt độ sang Kelvin T = t + 273.15."
        ]
      }
  },
  {
    id: "ly-02",
    subject: "ly",
    title: "Chuyên Đề Vật Lý Nhiệt & Nội Năng, Các Định Luật Nhiệt Động Lực Học",
    grade: 12,
    category: "chuyen-de",
    source: "Khoa Vật Lí ĐH Sư Phạm Hà Nội",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Mô hình động học phân tử, nhiệt dung riêng, nhiệt nóng chảy riêng, nhiệt hóa hơi riêng và nguyên lý I nhiệt động lực học.",
    link: "https://thuvienvatly.com/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lý nhiệt", "Nội năng", "Nhiệt động lực học", "Kiến thức mới 2025"],
    downloads: 14900,
    featured: true,
    studyContent: {
        summary: "Nội năng của vật phụ thuộc vào nhiệt độ và thể tích. Nhiệt lượng truyền cho vật làm tăng nội năng và thực hiện công.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Nguyên lý I: Delta U = A + Q (Q > 0 nhận nhiệt, A > 0 nhận công)",
          "Đẳng áp: A = -p*Delta V"
        ],
        studyTips: [
          "Nắm chắc quy ước dấu của A và Q."
        ]
      }
  },
  {
    id: "ly-03",
    subject: "ly",
    title: "Chuyên Đề Khí Lý Tưởng & Phương Trình Trạng Thái Khí Lý Tưởng",
    grade: 12,
    category: "chuyen-de",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Định luật Boyle (đẳng nhiệt), Charles (đẳng áp), Gay-Lussac (đẳng tích) và phương trình Clapeyron - Mendeleev.",
    link: "https://mapstudy.edu.vn/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Khí lý tưởng", "Boyle", "Charles", "Clapeyron", "Vật lí 12"],
    downloads: 16200,
    featured: true,
    studyContent: {
        summary: "Khí lý tưởng là mô hình khí mà các phân tử được coi là chất điểm và chỉ tương tác khi va chạm.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Đẳng nhiệt: p1*V1 = p2*V2",
          "Đẳng áp: V1/T1 = V2/T2",
          "Phương trình trạng thái: (p1*V1)/T1 = (p2*V2)/T2"
        ],
        studyTips: [
          "Vẽ đúng đồ thị biến đổi trạng thái trong các hệ tọa độ p-V, p-T, V-T."
        ]
      }
  },
  {
    id: "ly-04",
    subject: "ly",
    title: "Chuyên Đề Từ Trường, Cảm Ứng Điện Từ & Sóng Điện Từ",
    grade: 12,
    category: "chuyen-de",
    source: "Tổ Vật Lí THPT Chuyên KHTN",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Từ trường của dòng điện trong dây dẫn thẳng, tròn, ống dây; lực Lorentz; từ thông và hiện tượng cảm ứng điện từ.",
    link: "https://vatly247.com/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Từ trường", "Lực từ", "Cảm ứng điện từ", "Sóng điện từ"],
    downloads: 13800,
    featured: false,
    studyContent: {
        summary: "Từ trường tác dụng lực lên nam châm hoặc dòng điện đặt trong nó. Biến thiên từ thông sinh ra suất điện động cảm ứng.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Từ thông: Phi = B*S*cos(alpha)",
          "Suất điện động cảm ứng: ec = -Delta Phi / Delta t",
          "Lực Lorentz: f = |q|*v*B*sin(alpha)"
        ],
        studyTips: [
          "Quy tắc bàn tay phải cho dòng điện, bàn tay trái cho lực từ."
        ]
      }
  },
  {
    id: "hoa-01",
    subject: "hoa",
    title: "Đề Minh Họa Tốt Nghiệp THPT 2025 Môn Hóa Học - Bộ GD&ĐT",
    grade: 12,
    category: "de-thi",
    source: "Bộ Giáo Dục & Đào Tạo",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Đề minh họa chính thức môn Hóa học năm 2025 gồm 18 câu trắc nghiệm nhiều lựa chọn, 4 câu trắc nghiệm Đúng/Sai, 6 câu trả lời ngắn.",
    link: "https://moet.gov.vn/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Đề minh họa", "Hóa học 12", "Cấu trúc 2025", "Bộ GD&ĐT"],
    downloads: 16900,
    featured: true,
    studyContent: {
        summary: "Đề thi đánh giá cao năng lực đọc hiểu quy trình thí nghiệm, bảng số liệu, giải thích hiện tượng hóa học gắn liền với đời sống sản xuất thực tế.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Hiệu suất: H% = (m thực tế / m lý thuyết) * 100%",
          "Sức điện động pin: E pin = E cathode - E anode",
          "Định luật Faraday: m = (A*I*t) / (n*F)"
        ],
        studyTips: [
          "Đọc kỹ đề bài về chất giới hạn và chất dư trong các bài toán hiệu suất."
        ]
      }
  },
  {
    id: "hoa-02",
    subject: "hoa",
    title: "Chuyên Đề Ester - Lipid & Xà Phòng, Chất Giặt Rửa Tổng Hợp",
    grade: 12,
    category: "chuyen-de",
    source: "Thầy Phạm Thắng",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Hệ thống cấu trúc phân tử, tính chất hóa học, bài tập xà phòng hóa, chỉ số este, ứng dụng thực tiễn của chất béo và chất giặt rửa.",
    link: "https://vietjack.com/hoa-hoc-12/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Ester", "Lipid", "Hóa hữu cơ 12", "Lý thuyết & Bài tập"],
    downloads: 12400,
    featured: true,
    studyContent: {
        summary: "Ester có nhiệt độ sôi thấp hơn acid và alcohol có cùng phân tử khối vì không có liên kết hydro liên phân tử.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Tripalmitin: (C15H31COO)3C3H5 (M = 806)",
          "Tristearin: (C17H35COO)3C3H5 (M = 890)",
          "Triolein: (C17H33COO)3C3H5 (M = 884)"
        ],
        studyTips: [
          "Thủy phân este trong môi trường acid là thuận nghịch, môi trường kiềm là một chiều."
        ]
      }
  },
  {
    id: "hoa-03",
    subject: "hoa",
    title: "Chuyên Đề Trọng Tâm 2025: Kim Loại Chuyển Tiếp Dãy Thứ Nhất & Phức Chất",
    grade: 12,
    category: "chuyen-de",
    source: "Viện Khoa Học Giáo Dục Việt Nam",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Phần kiến thức mới của chương trình 2018: Cấu hình electron kim loại chuyển tiếp, số phối trí, phối tử đơn/đa càng, danh pháp và phản ứng thế phối tử.",
    link: "https://hoahocngaynay.com/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Phức chất", "Kim loại chuyển tiếp", "Kiến thức mới 2025"],
    downloads: 15300,
    featured: true,
    studyContent: {
        summary: "Phức chất gồm nguyên tử/ion trung tâm liên kết phối trí với các phối tử xung quanh. Số phối trí là số liên kết sigma.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Phức cation: [Ag(NH3)2]+ (số phối trí 2)",
          "Phức bát diện: [Fe(CN)6]4- (số phối trí 6)",
          "Phức tứ diện: [CuCl4]2- (số phối trí 4)"
        ],
        studyTips: [
          "Xác định đúng điện tích phối tử để suy ra số oxi hóa ion trung tâm."
        ]
      }
  },
  {
    id: "hoa-04",
    subject: "hoa",
    title: "Chuyên Đề Pin Điện Hóa, Thế Điện Cực Chuẩn & Quá Trình Ăn Mòn Kim Loại",
    grade: 12,
    category: "chuyen-de",
    source: "Khoa Hóa ĐH Sư Phạm Hà Nội",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Cơ chế hoạt động của pin Galvani, ắc quy, pin nhiên liệu, chiều phản ứng oxi hóa - khử theo quy tắc alpha và các biện pháp chống ăn mòn.",
    link: "https://hoahoc.org/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Pin điện hóa", "Điện phân", "Ăn mòn"],
    downloads: 10900,
    featured: false,
    studyContent: {
        summary: "Tại cực âm (anode) xảy ra quá trình oxi hóa; tại cực dương (cathode) xảy ra quá trình khử. Sức điện động chuẩn luôn dương.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Sức điện động: E pin = E cathode - E anode",
          "Quy tắc alpha: Dạng oxi hóa có thế điện cực lớn hơn oxi hóa dạng khử có thế điện cực nhỏ hơn"
        ],
        studyTips: [
          "Cực âm pin điện hóa là Anode (ngược lại với bình điện phân)."
        ]
      }
  },
  {
    id: "hoa-vd-01",
    subject: "hoa",
    title: "BUỔI SỐ 1 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 1",
    caLive: "5h00",
    ngayLive: "05/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 05/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1tCZ9vAPnKKul8KX8FlF4vUpG4p7oZGcu/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16AeDM1CLp/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 1", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 4141,
    featured: true,
    studyContent: null
  },
  {
    id: "hoa-vd-02",
    subject: "hoa",
    title: "BUỔI SỐ 1 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 01",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 1",
    caLive: "9h30",
    ngayLive: "05/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 05/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1baxslKIv9HYOGuKCDpekqbEGjrwglyCX/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1EfhqoReLx/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 1", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3063,
    featured: true,
    studyContent: null
  },
  {
    id: "hoa-vd-03",
    subject: "hoa",
    title: "BUỔI SỐ 1 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 01",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 1",
    caLive: "18h00",
    ngayLive: "05/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 05/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/180BUqMyEvgetB3eMiWsYMhHJa27HnQDl/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/180BUqMyEvgetB3eMiWsYMhHJa27HnQDl/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1nmsFRnyMH-YxcpVjT_V_5WF-N2injDua/view?usp=sharing",
    video: "https://www.facebook.com/share/v/15vJyeHGqJ/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 1", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 3549,
    featured: true,
    studyContent: null
  },
  {
    id: "hoa-vd-04",
    subject: "hoa",
    title: "BUỔI SỐ 1 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 201",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 1",
    caLive: "22h00",
    ngayLive: "05/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 05/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1AHSXRv3d-hMKTTIDQWdC3urLFJ59xdVv/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1JHK4grfbF/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 1", "Ca 22h00", "Lời giải viết tay"],
    downloads: 4291,
    featured: true,
    studyContent: null
  },
  {
    id: "hoa-vd-05",
    subject: "hoa",
    title: "BUỔI SỐ 2 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 2",
    caLive: "5h00",
    ngayLive: "06/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 06/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1AYQivxjnT9vE7mh4LAzCWG5kqIh-n0ux/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1AbzbVrpiZ/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 2", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3799,
    featured: true,
    studyContent: null
  },
  {
    id: "hoa-vd-06",
    subject: "hoa",
    title: "BUỔI SỐ 2 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 02",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 2",
    caLive: "9h30",
    ngayLive: "06/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 06/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1I4thELh_c3Ek7opS_Yjh3c21_JC0ujYy/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1FcnNXrVdr/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 2", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 4042,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-07",
    subject: "hoa",
    title: "BUỔI SỐ 2 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 02",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 2",
    caLive: "18h00",
    ngayLive: "06/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 06/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1Io6xVzCQA1nLEF_HcbcHkDvZu7uQ9oTF/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Io6xVzCQA1nLEF_HcbcHkDvZu7uQ9oTF/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1PvExFJlHgJEvVh7X2s4PRMuYQpY2DIMc/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16fZvDCUUf/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 2", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 3201,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-08",
    subject: "hoa",
    title: "BUỔI SỐ 2 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 202",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 2",
    caLive: "22h00",
    ngayLive: "06/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 06/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1NYUL9Ym1OTrxCj7NzS6ERLXq70lhpdWk/view?usp=sharing",
    video: "https://www.facebook.com/share/v/19LG7isnti/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 2", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3617,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-09",
    subject: "hoa",
    title: "BUỔI SỐ 3 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 3",
    caLive: "5h00",
    ngayLive: "07/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 07/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1v1fDqmwe1n310alfawxk6PTAkWAoLPiY/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16eoDayMMq/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 3", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3958,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-10",
    subject: "hoa",
    title: "BUỔI SỐ 3 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 03",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 3",
    caLive: "9h30",
    ngayLive: "07/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 07/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1Jw8STJUDpErr3cdoPs1cCi2DqTuyLgD8/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1Hp3irpVNV/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 3", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 4191,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-11",
    subject: "hoa",
    title: "BUỔI SỐ 3 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 03",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 3",
    caLive: "18h00",
    ngayLive: "07/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 07/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1ueyMe0xtlOST2FquUG9z2xx8b2UjUaz1/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1ueyMe0xtlOST2FquUG9z2xx8b2UjUaz1/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1WbbqGA7cfAkON7whEfDQzRfrsejfGSgL/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1Ay1mMDG6S/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 3", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 3204,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-12",
    subject: "hoa",
    title: "BUỔI SỐ 3 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 203",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 3",
    caLive: "22h00",
    ngayLive: "07/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 07/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1R27Djuie64LwIAhXM2yos-FRnOq21Axc/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16Dye4jfh2/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 3", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3714,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-13",
    subject: "hoa",
    title: "BUỔI SỐ 4 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 4",
    caLive: "5h00",
    ngayLive: "08/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 08/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1e0I5yh3_x__279YUfOL_dI3VBeCz1e3z/view?usp=sharing",
    video: "https://www.facebook.com/share/v/127P7w3XTfj/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 4", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3634,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-14",
    subject: "hoa",
    title: "BUỔI SỐ 4 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 04",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 4",
    caLive: "9h30",
    ngayLive: "08/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 08/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1N79jBgkNe7uwuXV4TeRrGACaBecs3a1t/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1Ai1tJhTFF/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 4", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 4008,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-15",
    subject: "hoa",
    title: "BUỔI SỐ 4 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 04",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 4",
    caLive: "18h00",
    ngayLive: "08/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 08/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/11dE2XlwdMidfCYujvwKSCyZmHtjoiNhI/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/11dE2XlwdMidfCYujvwKSCyZmHtjoiNhI/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1vQMqBD3RTaEmshtZHI8_z6BfkggTfy_R/view?usp=sharing",
    video: "https://www.facebook.com/share/v/15UL9HWZMc/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 4", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 4149,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-16",
    subject: "hoa",
    title: "BUỔI SỐ 4 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 204",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 4",
    caLive: "22h00",
    ngayLive: "08/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 08/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1AXbQn22Z7EsrwY40rXUMDYwjX3M4AfOv/view?usp=sharing",
    video: "https://www.facebook.com/share/v/19AiAVokiT/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 4", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3143,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-17",
    subject: "hoa",
    title: "BUỔI SỐ 5 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 5",
    caLive: "5h00",
    ngayLive: "09/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 09/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1xtEzyGewyCJG4knLYGOUSd6T7iVjBmHQ/view?usp=sharing",
    video: "https://www.facebook.com/share/p/16nddD7n7G/?mibextid=lOuIew",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 5", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3395,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-18",
    subject: "hoa",
    title: "BUỔI SỐ 5 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 05",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 5",
    caLive: "9h30",
    ngayLive: "09/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 09/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1PN4GMruvGP2gUMnK8KjipfqQ8pQpfsii/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1AS24gUk6x/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 5", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3618,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-19",
    subject: "hoa",
    title: "BUỔI SỐ 5 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 05",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 5",
    caLive: "18h00",
    ngayLive: "09/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 09/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1FrHeaCim7frJEegvB3zHc1LxPsZRBsrZ/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1FrHeaCim7frJEegvB3zHc1LxPsZRBsrZ/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1-TLyp46UEkkQiewV9lEdy2rF_ARcajtB/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1Di3xs2Kgj/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 5", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 4293,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-20",
    subject: "hoa",
    title: "BUỔI SỐ 5 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 205",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 5",
    caLive: "22h00",
    ngayLive: "09/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 09/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1HyJ9whEeYzkxZao9-6WdaKqJxzDccYja/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1EdCRiAjHa/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 5", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3408,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-21",
    subject: "hoa",
    title: "BUỔI SỐ 6 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 6",
    caLive: "5h00",
    ngayLive: "10/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 10/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1lT1L_Vk6fQr9dr4stluKaWpuT7ji7WPt/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16Rrn5fp2A/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 6", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3160,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-22",
    subject: "hoa",
    title: "BUỔI SỐ 6 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 06",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 6",
    caLive: "9h30",
    ngayLive: "10/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 10/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/18HS8sslBX-Il6MTkS591bNLMyjVrbfMy/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1AhvoL36RG/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 6", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 4235,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-23",
    subject: "hoa",
    title: "BUỔI SỐ 6 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 06",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 6",
    caLive: "18h00",
    ngayLive: "10/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 10/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/14fYYYiU7wCRdC5A-xtX_5pxXHfylaTt_/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/14fYYYiU7wCRdC5A-xtX_5pxXHfylaTt_/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1B4u3pN8B5wRmpxrSk2guy9PT7l8VQF6n/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1AUnmg2Tqp/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 6", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 3074,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-24",
    subject: "hoa",
    title: "BUỔI SỐ 6 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 206",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 6",
    caLive: "22h00",
    ngayLive: "10/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 10/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/12QWsXHFJxTK-GdSlMXPmyjTy1O7Z_SEF/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1LRD8gVWbf/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 6", "Ca 22h00", "Lời giải viết tay"],
    downloads: 4277,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-25",
    subject: "hoa",
    title: "BUỔI SỐ 7 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 7",
    caLive: "5h00",
    ngayLive: "11/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 11/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1EyYxJbSjVyi4UdkRYHgH_hekZp8X9oig/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1Aq68RxcfM/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 7", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3419,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-26",
    subject: "hoa",
    title: "BUỔI SỐ 7 (9h00) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 07",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 7",
    caLive: "9h00",
    ngayLive: "11/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 11/06/2025 • Ca live: 9h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1A2BaflIyUa9SNDWYNT7wX7ckpDCoVPV1/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16hi5oDnKp/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 7", "Ca 9h00", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3814,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-27",
    subject: "hoa",
    title: "BUỔI SỐ 7 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 07",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 7",
    caLive: "18h00",
    ngayLive: "11/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 11/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/14mSjZIQZ2hZIyxRo09QxaX_smW34TvN8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/14mSjZIQZ2hZIyxRo09QxaX_smW34TvN8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/14nk38Efk1ExAexExNNOpmRQHTxA4vukn/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1BmFZM89Gz/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 7", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 4072,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-28",
    subject: "hoa",
    title: "BUỔI SỐ 7 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 207",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 7",
    caLive: "22h00",
    ngayLive: "11/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 11/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1pI21gNJTKlIZTv-gmUKTGI8Rs0CL5KSv/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1Brrrhx1Em/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 7", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3676,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-29",
    subject: "hoa",
    title: "BUỔI SỐ 8 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 8",
    caLive: "5h00",
    ngayLive: "12/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 12/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/10FUyWrBb-NttdKJ8OoQga2frI3WWRuan/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1EN1iKniyA/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 8", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3059,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-30",
    subject: "hoa",
    title: "BUỔI SỐ 8 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 08",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 8",
    caLive: "9h30",
    ngayLive: "12/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 12/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1RKxYp9s206BiFisRQjrGPiSQK0z_TuZA/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1BXQaApDDf/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 8", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3936,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-31",
    subject: "hoa",
    title: "BUỔI SỐ 8 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 08",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 8",
    caLive: "18h00",
    ngayLive: "12/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 12/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1llbJZ-JxFl0lF3UctDLwmopZzILL1IZO/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1llbJZ-JxFl0lF3UctDLwmopZzILL1IZO/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1z6AM7CO9zxAVtWqLtWXasnEQmw2UZByk/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1HKe6HzBFt/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 8", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 3542,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-32",
    subject: "hoa",
    title: "BUỔI SỐ 8 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 208",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 8",
    caLive: "22h00",
    ngayLive: "12/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 12/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1GwOcux4KRpyAEG9ZUg-k2_szZv6xBcUL/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16SpEQCicA/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 8", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3798,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-33",
    subject: "hoa",
    title: "BUỔI SỐ 9 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 9",
    caLive: "5h00",
    ngayLive: "13/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 13/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1OUpMjZXLei4xMhIDwAjN-eYWQMSB7DdM/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1P9v1M9S9C/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 9", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3806,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-34",
    subject: "hoa",
    title: "BUỔI SỐ 9 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 09",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 9",
    caLive: "9h30",
    ngayLive: "13/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 13/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1AJIUT7MIKzzDGaMwh7Gu0mztZR8W47T9/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16ZZoudnmz/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 9", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 4173,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-35",
    subject: "hoa",
    title: "BUỔI SỐ 9 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 09",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 9",
    caLive: "18h00",
    ngayLive: "13/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 13/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/10gXL5pV7EeIckgTQ-5rwX4RPXGg3pe1A/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/10gXL5pV7EeIckgTQ-5rwX4RPXGg3pe1A/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1IYvtrc50EhfHKBcunFQ69nnfqefQgrW7/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1AoMpUP6cH/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 9", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 3703,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-36",
    subject: "hoa",
    title: "BUỔI SỐ 9 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 209",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 9",
    caLive: "22h00",
    ngayLive: "13/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 13/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1qbFJrF4AJLG6rQllSvnsMO0WzAODnsu9/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16r6nKkTfh/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 9", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3777,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-37",
    subject: "hoa",
    title: "BUỔI SỐ 10 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 10",
    caLive: "5h00",
    ngayLive: "14/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 14/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1UrSlPQozbLpwYrodVOtloZxZUz2Z3AIr/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16SVDFBne4/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 10", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 4178,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-38",
    subject: "hoa",
    title: "BUỔI SỐ 10 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 10",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 10",
    caLive: "9h30",
    ngayLive: "14/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 14/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1Z5xIeR0jTa9IBLWBrcoN07N5ZkqxOfnv/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1BcATNPPNL/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 10", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3740,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-39",
    subject: "hoa",
    title: "BUỔI SỐ 10 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 10",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 10",
    caLive: "18h00",
    ngayLive: "14/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 14/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1sBy5J5z2XfpBZJPqtFf19zzakVv6b_SV/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1sBy5J5z2XfpBZJPqtFf19zzakVv6b_SV/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/11qXQf8vGqJvV_toymfoFRQFjkJRbTYOn/view?usp=sharing",
    video: "https://www.facebook.com/share/v/19AbF3XChk/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 10", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 3762,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-40",
    subject: "hoa",
    title: "BUỔI SỐ 10 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 210",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 10",
    caLive: "22h00",
    ngayLive: "14/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 14/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1xpO30IMp3vZIdmRxfAVftbkc9GiFQwWB/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16QriJuMM3/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 10", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3678,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-41",
    subject: "hoa",
    title: "BUỔI SỐ 11 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 11",
    caLive: "5h00",
    ngayLive: "15/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 15/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1HerugsDVwvFWgPQRolaQjiY17u2GPHLV/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1CCaLMWLqu/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 11", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 2937,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-42",
    subject: "hoa",
    title: "BUỔI SỐ 11 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 11",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 11",
    caLive: "9h30",
    ngayLive: "15/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 15/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1UrYAOtbWgcwSa5i5NN2Z1-Yv5kphxSsl/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16kATjCqVR/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 11", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3922,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-43",
    subject: "hoa",
    title: "BUỔI SỐ 11 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 11",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 11",
    caLive: "18h00",
    ngayLive: "15/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 15/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1dXXcXVn-naAgIgWxbjtRYlQkKbs1_Vvb/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1dXXcXVn-naAgIgWxbjtRYlQkKbs1_Vvb/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1JghD5qnvncHYrzw_Cq9DUhIRjhyXSqn2/view?usp=sharing",
    video: "https://www.facebook.com/share/v/15ZJbURNCR/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 11", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 4033,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-44",
    subject: "hoa",
    title: "BUỔI SỐ 11 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 211",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 11",
    caLive: "22h00",
    ngayLive: "15/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 15/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/19txsEKHS5I11Nc7ebewdcy7nzgOPL_Y8/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1BXuy6Y6RJ/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 11", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3991,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-45",
    subject: "hoa",
    title: "BUỔI SỐ 12 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 12",
    caLive: "5h00",
    ngayLive: "16/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 16/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1QHmB5H5VNP4LYF3F1lMd1-nYuiBWbF-M/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1ZTZkb9QbC/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 12", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3045,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-46",
    subject: "hoa",
    title: "BUỔI SỐ 12 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 12",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 12",
    caLive: "9h30",
    ngayLive: "16/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 16/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1hH0rqUegcvGOjKTPq_tkKaG4wGMY1T9J/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1Bw3j8n72F/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 12", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 4067,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-47",
    subject: "hoa",
    title: "BUỔI SỐ 12 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 12",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 12",
    caLive: "18h00",
    ngayLive: "16/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 16/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/19pcMvXShLY8094tMbSWRw2EoBIT8-4Dp/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/19pcMvXShLY8094tMbSWRw2EoBIT8-4Dp/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1ONrpC6NfX5xTs8FZ4PACXOzELzTeyIMt/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1DcTFZCWVL/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 12", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 2955,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-48",
    subject: "hoa",
    title: "BUỔI SỐ 12 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 212",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 12",
    caLive: "22h00",
    ngayLive: "16/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 16/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1UG6D-3KRIN_i8byCY_JFhmMORllXl-as/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1A3RSushLD/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 12", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3280,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-49",
    subject: "hoa",
    title: "BUỔI SỐ 13 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 13",
    caLive: "5h00",
    ngayLive: "17/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 17/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1KZFrMAS7RZuu7SdprugwIyTP1t1EcKka/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1ByLuLEFad/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 13", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3674,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-50",
    subject: "hoa",
    title: "BUỔI SỐ 13 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 13",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 13",
    caLive: "9h30",
    ngayLive: "17/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 17/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1-tWP3v8VIPoPF2_-NgG3Y40M30rxBYik/view?usp=sharing",
    video: "https://www.facebook.com/share/v/15gAmgxFEU/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 13", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3748,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-51",
    subject: "hoa",
    title: "BUỔI SỐ 13 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 13",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 13",
    caLive: "18h00",
    ngayLive: "17/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 17/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1K5TbVqvUNk-YFKHyAs18dTPDs1vMjF8X/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1K5TbVqvUNk-YFKHyAs18dTPDs1vMjF8X/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1LL03RcqXDqlMhAk1m4mnIh_Y4JNCd9QT/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1FuqQLeQW3/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 13", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 4099,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-52",
    subject: "hoa",
    title: "BUỔI SỐ 13 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 213",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 13",
    caLive: "22h00",
    ngayLive: "17/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 17/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1-mWXkOoDDYOK5pAOTCrFrpjM5twDLoa5/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1FfPt8Eo1n/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 13", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3354,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-53",
    subject: "hoa",
    title: "BUỔI SỐ 14 (5h00) - 100 CÂU PHONG TỎA ĂN TRỌN ĐIỂM PHẦN TRẮC NGHIỆM - LUYỆN PHẢN XẠ",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 14",
    caLive: "5h00",
    ngayLive: "18/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 18/06/2025 • Ca live: 5h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1gb4vbtBVWVZ0OF3g7fztO6mPDkzUFIZP/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1TwqhI1kCRLyizy8qBAukl3kLcTK2vj5C/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16ZaF62ru8/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 14", "Ca 5h00", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 3556,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-54",
    subject: "hoa",
    title: "BUỔI SỐ 14 (9h30) - PHONG TỎA, DỰ ĐOÁN CÂU HỎI VẬN DỤNG CAO  - ĐỀ SỐ 14",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 14",
    caLive: "9h30",
    ngayLive: "18/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 18/06/2025 • Ca live: 9h30 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/16veqjHeKRobhWYU_oy-o3ar7n5ltFiB8/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1HYCjOcyi4rUCqLkCCHWityX6E6SKiZw0/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1AddLsuLAy/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 14", "Ca 9h30", "Vận dụng cao", "Dự đoán", "Luyện phản xạ", "Lời giải viết tay"],
    downloads: 4146,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-55",
    subject: "hoa",
    title: "BUỔI SỐ 14 (18h00) - THỰC CHIẾN ĐỀ \"DỰ ĐOÁN ĐẶC BIỆT\" - ĐỀ SỐ 14",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 14",
    caLive: "18h00",
    ngayLive: "18/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 18/06/2025 • Ca live: 18h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1va4tvjPU9_y_N2_oEsGjE8iOO7YtiPPc/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1va4tvjPU9_y_N2_oEsGjE8iOO7YtiPPc/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1eMR4Y4cVfLFO3o3sv-aN5eMlI_FGkZXx/view?usp=sharing",
    video: "https://www.facebook.com/share/v/15Ttwsjt7e/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 14", "Ca 18h00", "Dự đoán", "Lời giải viết tay"],
    downloads: 4027,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-56",
    subject: "hoa",
    title: "BUỔI SỐ 14 (22h00) - CHỮA ĐỀ SỞ TRƯỜNG MỚI VÀ HAY NHẤT - ĐỀ SỐ 214",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 14",
    caLive: "22h00",
    ngayLive: "18/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 18/06/2025 • Ca live: 22h00 • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1B2uhDEVmlkfworNlUKIOEQfoNM4-WMR8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1FEnY9dL3nFtXBUVPF13dA5CoGp6b2mNg/view?usp=sharing",
    video: "https://www.facebook.com/share/v/1LdCZGNhwz/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 14", "Ca 22h00", "Lời giải viết tay"],
    downloads: 3125,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-57",
    subject: "hoa",
    title: "BUỔI SỐ 15 (20H) - ĐỀ CHỮA LÀNH - SỐ 1, 2, 3",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 15",
    caLive: "20H",
    ngayLive: "19/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 19/06/2025 • Ca live: 20H • Đầy đủ File Đề • Có Lời Giải Viết Tay • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1qeNVF7XR_6TyFR9KpgvW9-4w50FQg-Aq/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1qeNVF7XR_6TyFR9KpgvW9-4w50FQg-Aq/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1YruSxzgAWsWTJfbBxFJ58L2U2XHrT-as/view?usp=sharing",
    video: "https://www.facebook.com/share/v/16aqroWJ3h/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 15", "Ca 20H", "Đề Chữa Lành", "Lời giải viết tay"],
    downloads: 3930,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-58",
    subject: "hoa",
    title: "BUỔI SỐ 16 (20H) - ĐỀ CHỮA LÀNH - SỐ 4, 5, 6",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 16",
    caLive: "20H",
    ngayLive: "20/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 20/06/2025 • Ca live: 20H • Đầy đủ File Đề • Có Video chữa bài",
    link: "https://drive.google.com/file/d/11c0l4SCB7ep6H58klQ8t-Q6lKGLlo75k/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/11c0l4SCB7ep6H58klQ8t-Q6lKGLlo75k/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.facebook.com/share/v/1CHFRaapSf/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 16", "Ca 20H", "Đề Chữa Lành"],
    downloads: 3194,
    featured: false,
    studyContent: null
  },
  {
    id: "hoa-vd-59",
    subject: "hoa",
    title: "BUỔI SỐ 17 (20H) - ĐỀ CHỮA LÀNH - SỐ 7, 8, 9",
    grade: 12,
    category: "ve-dich-hoa",
    source: "Khóa 14 Ngày Về Đích Cấp Tốc - Hóa Học",
    year: 2025,
    buoiHoc: "BUỔI SỐ 17",
    caLive: "20H",
    ngayLive: "21/06/2025",
    description: "Khóa 14 Ngày Về Đích Hóa Học: Ngày: 21/06/2025 • Ca live: 20H • Đầy đủ File Đề • Có Video chữa bài",
    link: "https://drive.google.com/file/d/1Lr5tbX3gyiPz2R5XllIQBfuJ7qhoOMcA/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Lr5tbX3gyiPz2R5XllIQBfuJ7qhoOMcA/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.facebook.com/share/v/18w5PNR5r9/",
    tags: ["Khóa 14 Ngày", "Về Đích", "BUỔI SỐ 17", "Ca 20H", "Đề Chữa Lành"],
    downloads: 4014,
    featured: false,
    studyContent: null
  },
  {
    id: "ly-1000-cau-chuan",
    subject: "ly",
    title: "1000 Câu Hỏi Trắc Nghiệm Lý Thuyết Trọng Tâm Vật Lí 10 - 11 - 12 (Chuẩn BGD)",
    grade: 12,
    category: "1000-cau-ly",
    source: "Mapstudy (Thầy Vũ Ngọc Anh) & VietJack - Thư Viện Vật Lí Quốc Gia",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Bộ tài liệu tổng hợp đầy đủ 1000 câu hỏi lý thuyết chọn lọc bám sát cấu trúc đề thi mới nhất (Trắc nghiệm 4 phương án, Đúng/Sai, Trả lời ngắn). Bao quát trọn vẹn 7 chủ đề cốt lõi.",
    link: "https://mapstudy.edu.vn/",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["1000 câu lý thuyết", "Vật lí 12", "Trọng tâm", "Mapstudy", "Vũ Ngọc Anh", "Chuẩn BGD"],
    downloads: 38900,
    featured: true,
    studyContent: {
        summary: "Bộ tài liệu '1000 câu càn quét lý thuyết Vật Lí' kinh điển giúp học sinh ăn trọn vẹn 100% điểm lý thuyết trong đề thi tốt nghiệp THPT. Phân tích bẫy đề thi, hiện tượng thực nghiệm và câu hỏi Đúng/Sai mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "1. Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$ (nhiệt hóa hơi), $Q = m\\lambda$ (nhiệt nóng chảy).",
          "2. Khí lý tưởng: Phương trình Clapeyron - Mendeleev: $pV = nRT = \\frac{m}{\\mu}RT$.",
          "3. Động học phân tử: Động năng tịnh tiến trung bình: $\\bar{E}_đ = \\frac{3}{2}kT$ (với $k = 1.38 \\times 10^{-23} \\text{ J/K}$).",
          "4. Từ trường: Cảm ứng từ trong lòng ống dây: $B = 4\\pi \\times 10^{-7} nI$.",
          "5. Hiện tượng quang điện ngoài: $hf = A + \\frac{1}{2}m v_{0\\max}^2$ (Einstein).",
          "6. Năng lượng liên kết hạt nhân: $W_{lk} = \\Delta m \\cdot c^2 = [Z m_p + (A - Z)m_n - m_X] c^2$.",
          "7. Độ phóng xạ: $H(t) = H_0 \\cdot 2^{-t/T} = \\lambda \\cdot N(t)$ (với $\\lambda = \\frac{\\ln 2}{T}$)."
        ],
        studyTips: [
          "1. Khi làm câu trắc nghiệm Đúng/Sai, kiểm tra kỹ từng mệnh đề độc lập, chú ý đơn vị nhiệt độ bắt buộc là Kelvin (K = °C + 273.15).",
          "2. Cẩn thận các bẫy về chiều đường sức từ, quy tắc bàn tay trái (với electron lực Lorentz ngược chiều chỉ ngón cái).",
          "3. Nắm chắc bảng hằng số vật lý: $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$, $N_A = 6.022 \\times 10^{23} \\text{ mol}^{-1}$, $c = 3 \\times 10^8 \\text{ m/s}$."
        ]
      }
  },
  {
    id: "toan-ds-01",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: CHẶNG 1: BỘ 100 CÂU HỎI TRẮC NGHIỆM ĐÚNG SAI TỪ 1 - 100 (400 Ý NHỎ) CHỦ ĐỀ TRỌNG TÂM: HÀM SỐ",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://drive.google.com/file/d/17G-_88Z5cpcSsAL3y2IJYZgLkFvb9_39/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/17G-_88Z5cpcSsAL3y2IJYZgLkFvb9_39/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1Ee2ZF7jwHNmYaw6J-XKQB0YEZotuBCp0/view?usp=sharing",
    video: "https://drive.google.com/file/d/17G-_88Z5cpcSsAL3y2IJYZgLkFvb9_39/view?usp=sharing",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5394,
    featured: true,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "https://drive.google.com/file/d/17G-_88Z5cpcSsAL3y2IJYZgLkFvb9_39/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1Ee2ZF7jwHNmYaw6J-XKQB0YEZotuBCp0/view?usp=sharing",
          video: "https://drive.google.com/file/d/17G-_88Z5cpcSsAL3y2IJYZgLkFvb9_39/view?usp=sharing"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-02",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 1-10",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/804346975013711/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/804346975013711/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5260,
    featured: true,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/804346975013711/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-03",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 11-20",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/804638388317903/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/804638388317903/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5339,
    featured: true,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/804638388317903/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-04",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 21-30",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/804647324983676/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/804647324983676/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5146,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/804647324983676/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-05",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 31-40",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/804920478289694/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/804920478289694/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5480,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/804920478289694/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-06",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 41-50",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/804928831622192/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/804928831622192/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 4840,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/804928831622192/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-07",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 51-60",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/804941698287572/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/804941698287572/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 4783,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/804941698287572/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-08",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 61-70",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/804952641619811/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/804952641619811/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5451,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/804952641619811/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-09",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 71-80",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/805033541611721/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/805033541611721/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5119,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/805033541611721/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-10",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 81-90",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/805040204944388/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/805040204944388/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 4858,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/805040204944388/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-11",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 91-100",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://www.facebook.com/groups/1000caudungsai/posts/805650011550074/",
    fileDe: "",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/1000caudungsai/posts/805650011550074/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 4870,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/1000caudungsai/posts/805650011550074/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-12",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: CHẶNG 1: BỘ 100 CÂU HỎI TRẮC NGHIỆM ĐÚNG SAI TỪ 101 - 200 (400 Ý NHỎ) CHỦ ĐỀ TRỌNG TÂM: HÀM SỐ",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://drive.google.com/file/d/1Jy8ORrS_gK19nu8wkbR4rZrSOfijXHRG/view?pli=1",
    fileDe: "https://drive.google.com/file/d/1Jy8ORrS_gK19nu8wkbR4rZrSOfijXHRG/view?pli=1",
    fileVietTay: "https://drive.google.com/file/d/1OuhTy5Sb7UA8cVE7P-GBMrqHJS7I9bg7/view",
    video: "https://drive.google.com/file/d/1Jy8ORrS_gK19nu8wkbR4rZrSOfijXHRG/view?pli=1",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5137,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "https://drive.google.com/file/d/1Jy8ORrS_gK19nu8wkbR4rZrSOfijXHRG/view?pli=1",
          fileVietTay: "https://drive.google.com/file/d/1OuhTy5Sb7UA8cVE7P-GBMrqHJS7I9bg7/view",
          video: "https://drive.google.com/file/d/1Jy8ORrS_gK19nu8wkbR4rZrSOfijXHRG/view?pli=1"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-13",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 101-110",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZqplFo6Aj/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZqplFo6Aj/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5342,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZqplFo6Aj/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-14",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 110-120",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZqvbxoYQ1/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZqvbxoYQ1/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 4900,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZqvbxoYQ1/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-15",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 121-130",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZqvIbOCMU/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZqvIbOCMU/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5310,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZqvIbOCMU/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-16",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 131-140",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZqwcEHiww/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZqwcEHiww/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 4725,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZqwcEHiww/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-17",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 141-150",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZqxwCznQM/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZqxwCznQM/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5140,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZqxwCznQM/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-18",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 151-160",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZqy7J7YtE/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZqy7J7YtE/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5335,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZqy7J7YtE/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-19",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 161-170",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZqyxMiLQf/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZqyxMiLQf/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 4756,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZqyxMiLQf/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-20",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 171-180",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZqz9tGh2A/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZqz9tGh2A/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 4910,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZqz9tGh2A/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-21",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 181-190",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZqzBZBje2/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZqzBZBje2/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5422,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZqzBZBje2/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "toan-ds-22",
    subject: "toan",
    title: "Khóa 1000 Câu Đúng Sai: VIDEO CHỮA CHI TIẾT TỪNG CÂU TỪ 191-200",
    grade: 12,
    category: "1000-cau-toan",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "",
    caLive: "",
    ngayLive: "",
    description: "Chuyên đề rèn luyện tư duy trắc nghiệm Đúng/Sai chuẩn format Bộ GD&ĐT 2025. Bao gồm đầy đủ File Đề, Lời Giải Viết Tay chi tiết và Video phân tích.",
    link: "https://fb.watch/tZsTyxzxsZ/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/tZsTyxzxsZ/",
    tags: ["Toán 12", "1000 câu đúng sai", "Đỗ Văn Đức", "Format 2025", "Đề & Lời giải"],
    downloads: 5475,
    featured: false,
    studyContent: {
        summary: "Tài liệu thuộc chuỗi Khóa 1000 Câu Hỏi Trắc Nghiệm Đúng Sai của Thầy Đỗ Văn Đức. Giúp học sinh nắm chắc 4 điểm tuyệt đối của Phần II trong cấu trúc đề thi tốt nghiệp THPT mới.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/tZsTyxzxsZ/"
        },
        keyFormulas: [
          "Phần II Đề Toán BGD 2025 gồm 4 câu hỏi Đúng/Sai (mỗi câu 4 ý a, b, c, d): Đúng 1 ý được 0,1đ; đúng 2 ý được 0,25đ; đúng 3 ý được 0,5đ; đúng 4 ý trọn vẹn 1,0 điểm.",
          "Đạo hàm tích, thương: (u * v)' = u'v + uv', (u/v)' = (u'v - uv') / v^2",
          "Khoảng cách từ điểm đến mặt phẳng: d(M, (P)) = |Ax0 + By0 + Cz0 + D| / sqrt(A^2 + B^2 + C^2)"
        ],
        studyTips: [
          "Kiểm tra từng ý cẩn thận, không suy diễn cảm tính. Ý nào chắc chắn thì giải trước."
        ]
      }
  },
  {
    id: "hoa-livem-01",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 1 - BÀI GIẢNG 01: ESTER",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 1",
    caLive: "",
    ngayLive: "20/05/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 1 - BÀI GIẢNG 01: ESTER. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/169hFsolHfTYYS2NHHZsC3WoetZSbeg5N/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/169hFsolHfTYYS2NHHZsC3WoetZSbeg5N/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/12_EFgUtWw2SUMVnckFf1_3GlKvDG7FaA/view?usp=sharing",
    video: "https://youtu.be/nJt9CmS_qv8?si=6bsbIsQ2Pxbpttrq",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 1"],
    downloads: 3509,
    featured: true,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 1 (BÀI GIẢNG 01: ESTER) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/169hFsolHfTYYS2NHHZsC3WoetZSbeg5N/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/12_EFgUtWw2SUMVnckFf1_3GlKvDG7FaA/view?usp=sharing",
          video: "https://youtu.be/nJt9CmS_qv8?si=6bsbIsQ2Pxbpttrq"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-02",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 2 - CHỮA BTRL ESTER - SỐ 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 2",
    caLive: "",
    ngayLive: "23/05/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 2 - CHỮA BTRL ESTER - SỐ 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1Gyw6yMWW-y9Td9MSC_yChBAfujkTgGgb/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Gyw6yMWW-y9Td9MSC_yChBAfujkTgGgb/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/12PMr-u4WYLQlE3y3xWNyRxpvZ64jExXD/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/1596365857605245/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 2"],
    downloads: 3903,
    featured: true,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 2 (CHỮA BTRL ESTER - SỐ 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1Gyw6yMWW-y9Td9MSC_yChBAfujkTgGgb/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/12PMr-u4WYLQlE3y3xWNyRxpvZ64jExXD/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/1596365857605245/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-03",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 3 - CHỮA BTRL ESTER - SỐ 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 3",
    caLive: "",
    ngayLive: "24/05/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 3 - CHỮA BTRL ESTER - SỐ 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1FnB1DPkVZb1Hwz6Lc3Z9nQQqUU0v_J1t/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1FnB1DPkVZb1Hwz6Lc3Z9nQQqUU0v_J1t/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/13KSwTTimqn53qQfjRQYwPKa7Ok65Hhq8/view?usp=sharing",
    video: "https://fb.watch/sgn-SzQgxm/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 3"],
    downloads: 3382,
    featured: true,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 3 (CHỮA BTRL ESTER - SỐ 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1FnB1DPkVZb1Hwz6Lc3Z9nQQqUU0v_J1t/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/13KSwTTimqn53qQfjRQYwPKa7Ok65Hhq8/view?usp=sharing",
          video: "https://fb.watch/sgn-SzQgxm/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-04",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 4 - PHƯƠNG PHÁP GIẢI CÁC DẠNG BÀI TẬP ESTE",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 4",
    caLive: "",
    ngayLive: "27/05/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 4 - PHƯƠNG PHÁP GIẢI CÁC DẠNG BÀI TẬP ESTE. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1MqowO4-kTMp1hlftQc4FYLJvQKA0l1dE/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1MqowO4-kTMp1hlftQc4FYLJvQKA0l1dE/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/17AgEGrwKVCRAz7IOdtqjRxs4r4ejbIv2/view?usp=sharing",
    video: "https://www.facebook.com/100014073250721/videos/1187088112304788/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 4"],
    downloads: 3749,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 4 (PHƯƠNG PHÁP GIẢI CÁC DẠNG BÀI TẬP ESTE) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1MqowO4-kTMp1hlftQc4FYLJvQKA0l1dE/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/17AgEGrwKVCRAz7IOdtqjRxs4r4ejbIv2/view?usp=sharing",
          video: "https://www.facebook.com/100014073250721/videos/1187088112304788/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-05",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 5 - CHỮA BÀI TẬP RÈN LUYỆN ESTE - PHẦN 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 5",
    caLive: "",
    ngayLive: "30/05/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 5 - CHỮA BÀI TẬP RÈN LUYỆN ESTE - PHẦN 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1f-QvG_nY_MW5q863BP5lFp8BKnxNlchu/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1f-QvG_nY_MW5q863BP5lFp8BKnxNlchu/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1pRO7i8PyhVQSey1TJK3zQLJvwigwJs9R/view?usp=sharing",
    video: "https://fb.watch/sokYGR21gU/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 5"],
    downloads: 3826,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 5 (CHỮA BÀI TẬP RÈN LUYỆN ESTE - PHẦN 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1f-QvG_nY_MW5q863BP5lFp8BKnxNlchu/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1pRO7i8PyhVQSey1TJK3zQLJvwigwJs9R/view?usp=sharing",
          video: "https://fb.watch/sokYGR21gU/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-06",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 6 - CHỮA BÀI TẬP RÈN LUYỆN ESTE - PHẦN 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 6",
    caLive: "",
    ngayLive: "31/05/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 6 - CHỮA BÀI TẬP RÈN LUYỆN ESTE - PHẦN 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1EGz8O4jJ0hcYSxh8pavQAPfWe07NKm40/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1EGz8O4jJ0hcYSxh8pavQAPfWe07NKm40/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1Qlz6zOhOBzcA6p66Yo8QDyoE8F3qnfK5/view?usp=drive_link",
    video: "https://www.facebook.com/100048652783192/videos/363326896323923/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 6"],
    downloads: 3531,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 6 (CHỮA BÀI TẬP RÈN LUYỆN ESTE - PHẦN 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1EGz8O4jJ0hcYSxh8pavQAPfWe07NKm40/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1Qlz6zOhOBzcA6p66Yo8QDyoE8F3qnfK5/view?usp=drive_link",
          video: "https://www.facebook.com/100048652783192/videos/363326896323923/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-07",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 7 - BÀI GIẢNG - PHƯƠNG PHÁP XÁC ĐỊNH CTCT ESTER (NÂNG CAO)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 7",
    caLive: "",
    ngayLive: "04/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 7 - BÀI GIẢNG - PHƯƠNG PHÁP XÁC ĐỊNH CTCT ESTER (NÂNG CAO). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1ghIKzRII6dKK6QITjMgz8qwVAaZ5dtI0/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1ghIKzRII6dKK6QITjMgz8qwVAaZ5dtI0/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1mHc8h-89RI1WTeUg4bu03dR0pf1fycee/view?usp=sharing",
    video: "https://www.facebook.com/100014073250721/videos/480377937988144/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 7"],
    downloads: 3526,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 7 (BÀI GIẢNG - PHƯƠNG PHÁP XÁC ĐỊNH CTCT ESTER (NÂNG CAO)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1ghIKzRII6dKK6QITjMgz8qwVAaZ5dtI0/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1mHc8h-89RI1WTeUg4bu03dR0pf1fycee/view?usp=sharing",
          video: "https://www.facebook.com/100014073250721/videos/480377937988144/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-08",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 8 - PHƯƠNG PHÁP XÁC ĐỊNH CTCT ESTER -  BTRL - SỐ 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 8",
    caLive: "",
    ngayLive: "06/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 8 - PHƯƠNG PHÁP XÁC ĐỊNH CTCT ESTER -  BTRL - SỐ 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1mo6E7Gg9lXLM6rMIdTfchYfVClJo5ZPR/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1mo6E7Gg9lXLM6rMIdTfchYfVClJo5ZPR/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1cGlGTbs6418hhVcp8hX68xQuUyj_3RiN/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/476051194826119/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 8"],
    downloads: 3938,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 8 (PHƯƠNG PHÁP XÁC ĐỊNH CTCT ESTER -  BTRL - SỐ 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1mo6E7Gg9lXLM6rMIdTfchYfVClJo5ZPR/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1cGlGTbs6418hhVcp8hX68xQuUyj_3RiN/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/476051194826119/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-09",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 9 - PHƯƠNG PHÁP XÁC ĐỊNH CTCT ESTER -  BTRL - SỐ 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 9",
    caLive: "",
    ngayLive: "07/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 9 - PHƯƠNG PHÁP XÁC ĐỊNH CTCT ESTER -  BTRL - SỐ 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1mx5pKrwPsgDNPTlfEidTDmh2rLJwm8KQ/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1mx5pKrwPsgDNPTlfEidTDmh2rLJwm8KQ/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1QLl_eSsMOUENbelCOcxP4bGQ_mFyHBga/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/738964931526394/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 9"],
    downloads: 3804,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 9 (PHƯƠNG PHÁP XÁC ĐỊNH CTCT ESTER -  BTRL - SỐ 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1mx5pKrwPsgDNPTlfEidTDmh2rLJwm8KQ/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1QLl_eSsMOUENbelCOcxP4bGQ_mFyHBga/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/738964931526394/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-10",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 10 - BÀI GIẢNG LIPID - XÀ PHÒNG - CHẤT GIẶT RỬA",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 10",
    caLive: "",
    ngayLive: "11/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 10 - BÀI GIẢNG LIPID - XÀ PHÒNG - CHẤT GIẶT RỬA. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1H1WhrQN2Q8nacPv_iGAugJui9iD-k5Nd/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1H1WhrQN2Q8nacPv_iGAugJui9iD-k5Nd/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1oASAp4pCR9WpxUo6mQADVVDCXdaYNqim/view?usp=sharing",
    video: "https://www.facebook.com/100014073250721/videos/823044393078605/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 10"],
    downloads: 3866,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 10 (BÀI GIẢNG LIPID - XÀ PHÒNG - CHẤT GIẶT RỬA) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1H1WhrQN2Q8nacPv_iGAugJui9iD-k5Nd/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1oASAp4pCR9WpxUo6mQADVVDCXdaYNqim/view?usp=sharing",
          video: "https://www.facebook.com/100014073250721/videos/823044393078605/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-11",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 11 - KHẢO SÁT CHẤT LƯỢNG LẦN 01",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 11",
    caLive: "",
    ngayLive: "12/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 11 - KHẢO SÁT CHẤT LƯỢNG LẦN 01. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1em42suRN7stA9MRoRZ9sXITb44EPeq84/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1em42suRN7stA9MRoRZ9sXITb44EPeq84/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1TEf05OpRzhdxU3dGaBLa8uKqbEYcdVJc/view?usp=drive_link",
    video: "https://www.youtube.com/watch?v=lcgZ4Kr1r3w",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 11"],
    downloads: 3840,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 11 (KHẢO SÁT CHẤT LƯỢNG LẦN 01) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1em42suRN7stA9MRoRZ9sXITb44EPeq84/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1TEf05OpRzhdxU3dGaBLa8uKqbEYcdVJc/view?usp=drive_link",
          video: "https://www.youtube.com/watch?v=lcgZ4Kr1r3w"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-12",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 12 - BTRL -  LIPID - XÀ PHÒNG - CHẤT GIẶT RỬA - SỐ 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 12",
    caLive: "",
    ngayLive: "13/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 12 - BTRL -  LIPID - XÀ PHÒNG - CHẤT GIẶT RỬA - SỐ 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/19_qmmGIDKT40uwFNA-YVxRZkWTFhwWbY/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/19_qmmGIDKT40uwFNA-YVxRZkWTFhwWbY/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1_VnVATqU2ryehAa2f991YynioxB3PzOf/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/771220025199628/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 12"],
    downloads: 3416,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 12 (BTRL -  LIPID - XÀ PHÒNG - CHẤT GIẶT RỬA - SỐ 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/19_qmmGIDKT40uwFNA-YVxRZkWTFhwWbY/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1_VnVATqU2ryehAa2f991YynioxB3PzOf/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/771220025199628/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-13",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 13 - BTRL -  LIPID - XÀ PHÒNG - CHẤT GIẶT RỬA - SỐ 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 13",
    caLive: "",
    ngayLive: "14/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 13 - BTRL -  LIPID - XÀ PHÒNG - CHẤT GIẶT RỬA - SỐ 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1Tb2PhXCYPdjWlAvaK_pyR3u611uufgOa/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Tb2PhXCYPdjWlAvaK_pyR3u611uufgOa/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1lEUCIC018ezxf19k6XQVapiXvsKwTbpT/view?usp=sharing",
    video: "https://fb.watch/sKpUHKJWv3/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 13"],
    downloads: 3531,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 13 (BTRL -  LIPID - XÀ PHÒNG - CHẤT GIẶT RỬA - SỐ 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1Tb2PhXCYPdjWlAvaK_pyR3u611uufgOa/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1lEUCIC018ezxf19k6XQVapiXvsKwTbpT/view?usp=sharing",
          video: "https://fb.watch/sKpUHKJWv3/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-14",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 14 - TỔNG ÔN ESTER - LIPID (PHẦN 1)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 14",
    caLive: "",
    ngayLive: "17/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 14 - TỔNG ÔN ESTER - LIPID (PHẦN 1). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/134cPJwAsNOViT38jfsWghmCLrMRMGwOj/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/134cPJwAsNOViT38jfsWghmCLrMRMGwOj/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1Wm6KHFoZz1DqB1Vmenw6H0SsYv5_0Eil/view?usp=sharing",
    video: "https://www.facebook.com/100014073250721/videos/425095400367052/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 14"],
    downloads: 3786,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 14 (TỔNG ÔN ESTER - LIPID (PHẦN 1)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/134cPJwAsNOViT38jfsWghmCLrMRMGwOj/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1Wm6KHFoZz1DqB1Vmenw6H0SsYv5_0Eil/view?usp=sharing",
          video: "https://www.facebook.com/100014073250721/videos/425095400367052/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-15",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 15 - TỔNG ÔN ESTER - LIPID (PHẦN 2)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 15",
    caLive: "",
    ngayLive: "18/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 15 - TỔNG ÔN ESTER - LIPID (PHẦN 2). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1LT26Q7v8DRpdXnNmRXjrOgXvX8NreIl-/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1LT26Q7v8DRpdXnNmRXjrOgXvX8NreIl-/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/14Vp7pS1l6YMDPHyLFymnxM5AFBYKL26n/view?usp=sharing",
    video: "https://fb.watch/sNWZAvQPAG/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 15"],
    downloads: 3916,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 15 (TỔNG ÔN ESTER - LIPID (PHẦN 2)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1LT26Q7v8DRpdXnNmRXjrOgXvX8NreIl-/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/14Vp7pS1l6YMDPHyLFymnxM5AFBYKL26n/view?usp=sharing",
          video: "https://fb.watch/sNWZAvQPAG/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-16",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 16 - KHẢO SÁT CHẤT LƯỢNG LẦN 02",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 16",
    caLive: "",
    ngayLive: "19/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 16 - KHẢO SÁT CHẤT LƯỢNG LẦN 02. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1Un3LJZFvX_Nx88-qrEVYl2-84Zbnf0yC/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Un3LJZFvX_Nx88-qrEVYl2-84Zbnf0yC/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1QMkgQt5tVWr8GZSDXLIZeNTqmJClU7mK/view?usp=sharing",
    video: "https://www.youtube.com/watch?v=8ZmPDyRiCv0",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 16"],
    downloads: 3328,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 16 (KHẢO SÁT CHẤT LƯỢNG LẦN 02) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1Un3LJZFvX_Nx88-qrEVYl2-84Zbnf0yC/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1QMkgQt5tVWr8GZSDXLIZeNTqmJClU7mK/view?usp=sharing",
          video: "https://www.youtube.com/watch?v=8ZmPDyRiCv0"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-17",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 17 - TỔNG ÔN ESTER - LIPID (PHẦN 3)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 17",
    caLive: "",
    ngayLive: "21/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 17 - TỔNG ÔN ESTER - LIPID (PHẦN 3). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1zl8nhn357K5xWxUW4gtfdhUPRr38GL6Q/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1zl8nhn357K5xWxUW4gtfdhUPRr38GL6Q/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1F1FBzg2-rPtejeR_CTQIbCYq_vUiNOG5/view?usp=sharing",
    video: "https://fb.watch/t12DVL0ZRt/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 17"],
    downloads: 3427,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 17 (TỔNG ÔN ESTER - LIPID (PHẦN 3)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1zl8nhn357K5xWxUW4gtfdhUPRr38GL6Q/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1F1FBzg2-rPtejeR_CTQIbCYq_vUiNOG5/view?usp=sharing",
          video: "https://fb.watch/t12DVL0ZRt/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-18",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 18 - KHẢO SÁT CHẤT LƯỢNG LẦN 03",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 18",
    caLive: "",
    ngayLive: "26/06/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 18 - KHẢO SÁT CHẤT LƯỢNG LẦN 03. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/15iD-zX_pYHwnY0Ml6carw-In4ka7T6K1/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/15iD-zX_pYHwnY0Ml6carw-In4ka7T6K1/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1ToHW1sElV4Efr8kAsAjSuxll_onqoYtl/view?usp=sharing",
    video: "https://www.youtube.com/watch?v=KymvVrQEUQE",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 18"],
    downloads: 3445,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 18 (KHẢO SÁT CHẤT LƯỢNG LẦN 03) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/15iD-zX_pYHwnY0Ml6carw-In4ka7T6K1/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1ToHW1sElV4Efr8kAsAjSuxll_onqoYtl/view?usp=sharing",
          video: "https://www.youtube.com/watch?v=KymvVrQEUQE"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-19",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 19 - BÀI GIẢNG CARBOHYDRATE, GLUCOSE, FRUCTOSE",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 19",
    caLive: "",
    ngayLive: "02/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 19 - BÀI GIẢNG CARBOHYDRATE, GLUCOSE, FRUCTOSE. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1Ay_DGlif6dMme9JfPuLYeTmg9fWWS6Qw/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Ay_DGlif6dMme9JfPuLYeTmg9fWWS6Qw/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.facebook.com/100014073250721/videos/329449256884740/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 19"],
    downloads: 3854,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 19 (BÀI GIẢNG CARBOHYDRATE, GLUCOSE, FRUCTOSE) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1Ay_DGlif6dMme9JfPuLYeTmg9fWWS6Qw/view?usp=sharing",
          fileVietTay: "",
          video: "https://www.facebook.com/100014073250721/videos/329449256884740/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-20",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 20 - KHẢO SÁT CHẤT LƯỢNG LẦN 04",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 20",
    caLive: "",
    ngayLive: "03/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 20 - KHẢO SÁT CHẤT LƯỢNG LẦN 04. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/156D7skkrli5AMMvapiBcFkKGbQ7g-3Fy/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/156D7skkrli5AMMvapiBcFkKGbQ7g-3Fy/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1pRnKQmI0I5KjFuz0dflMYGWDOpS1zVMo/view?usp=sharing",
    video: "https://www.youtube.com/watch?v=wZKKP2NBGZE",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 20"],
    downloads: 3996,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 20 (KHẢO SÁT CHẤT LƯỢNG LẦN 04) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/156D7skkrli5AMMvapiBcFkKGbQ7g-3Fy/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1pRnKQmI0I5KjFuz0dflMYGWDOpS1zVMo/view?usp=sharing",
          video: "https://www.youtube.com/watch?v=wZKKP2NBGZE"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-21",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 21 - CHỮA BÀI TẬP RÈN LUYỆN - SỐ 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 21",
    caLive: "",
    ngayLive: "05/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 21 - CHỮA BÀI TẬP RÈN LUYỆN - SỐ 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/18epgpr4aVRVDlpON2cVp2YeM9pbMro_f/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/18epgpr4aVRVDlpON2cVp2YeM9pbMro_f/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1aQOLz9Kyv_bzM7pUr-WxvyjTYLN9MvPC/view?usp=sharing",
    video: "https://fb.watch/td2z5FuB4F/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 21"],
    downloads: 3565,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 21 (CHỮA BÀI TẬP RÈN LUYỆN - SỐ 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/18epgpr4aVRVDlpON2cVp2YeM9pbMro_f/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1aQOLz9Kyv_bzM7pUr-WxvyjTYLN9MvPC/view?usp=sharing",
          video: "https://fb.watch/td2z5FuB4F/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-22",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 22 - CHỮA BÀI TẬP RÈN LUYỆN - SỐ 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 22",
    caLive: "",
    ngayLive: "06/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 22 - CHỮA BÀI TẬP RÈN LUYỆN - SỐ 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1sjhaJxuh_PPsVv4Re_5H0lvgdMYBP6WQ/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1sjhaJxuh_PPsVv4Re_5H0lvgdMYBP6WQ/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1ydMzGpkzrTGxhAgzAQ4byNs6HneJGMzV/view?usp=sharing",
    video: "https://fb.watch/t9_jyytLSD/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 22"],
    downloads: 3405,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 22 (CHỮA BÀI TẬP RÈN LUYỆN - SỐ 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1sjhaJxuh_PPsVv4Re_5H0lvgdMYBP6WQ/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1ydMzGpkzrTGxhAgzAQ4byNs6HneJGMzV/view?usp=sharing",
          video: "https://fb.watch/t9_jyytLSD/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-23",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 23 - BÀI GIẢNG SACCHAROSE VÀ MALTOSE",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 23",
    caLive: "",
    ngayLive: "09/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 23 - BÀI GIẢNG SACCHAROSE VÀ MALTOSE. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/18j38HRcFqwTJjW8bzUUWz7fYAysswwuS/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/18j38HRcFqwTJjW8bzUUWz7fYAysswwuS/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1AuZfuFJldXgNOUZslBFU_d6H-z64M1TQ/view?usp=sharing",
    video: "https://fb.watch/td2AkKp7fB/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 23"],
    downloads: 3807,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 23 (BÀI GIẢNG SACCHAROSE VÀ MALTOSE) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/18j38HRcFqwTJjW8bzUUWz7fYAysswwuS/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1AuZfuFJldXgNOUZslBFU_d6H-z64M1TQ/view?usp=sharing",
          video: "https://fb.watch/td2AkKp7fB/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-24",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 24 - KHẢO SÁT CHẤT LƯỢNG LẦN 05",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 24",
    caLive: "",
    ngayLive: "10/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 24 - KHẢO SÁT CHẤT LƯỢNG LẦN 05. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1KC4-ChON9L8DuEYQqQPhP-ZVuukbmiI7/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1KC4-ChON9L8DuEYQqQPhP-ZVuukbmiI7/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1EDuwgs9PEH7_OMEyhm6sUGf4I538PDSI/view?usp=sharing",
    video: "https://www.youtube.com/watch?v=MTRhZGAfGPo",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 24"],
    downloads: 3383,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 24 (KHẢO SÁT CHẤT LƯỢNG LẦN 05) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1KC4-ChON9L8DuEYQqQPhP-ZVuukbmiI7/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1EDuwgs9PEH7_OMEyhm6sUGf4I538PDSI/view?usp=sharing",
          video: "https://www.youtube.com/watch?v=MTRhZGAfGPo"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-25",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 25 - BÀI TẬP RÈN LUYỆN - SỐ 01",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 25",
    caLive: "",
    ngayLive: "11/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 25 - BÀI TẬP RÈN LUYỆN - SỐ 01. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1k-JuksPy0R1-yj8tlNTsyRDSJ1uZV1_v/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1k-JuksPy0R1-yj8tlNTsyRDSJ1uZV1_v/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/17vo8iEeLc7keJtj0rRxl5bl6Gr0IQWRb/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/853525123380239/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 25"],
    downloads: 3963,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 25 (BÀI TẬP RÈN LUYỆN - SỐ 01) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1k-JuksPy0R1-yj8tlNTsyRDSJ1uZV1_v/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/17vo8iEeLc7keJtj0rRxl5bl6Gr0IQWRb/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/853525123380239/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-26",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 26 - BÀI TẬP RÈN LUYỆN - SỐ 02",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 26",
    caLive: "",
    ngayLive: "12/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 26 - BÀI TẬP RÈN LUYỆN - SỐ 02. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1SHJofBbo239ujQJO0GIy0GdJbVk6hjEK/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1SHJofBbo239ujQJO0GIy0GdJbVk6hjEK/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1wYYyF3WYlAknaKYhWVTKw5X-iwOwP5KB/view?usp=sharing",
    video: "https://fb.watch/th14IYIO6g/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 26"],
    downloads: 3315,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 26 (BÀI TẬP RÈN LUYỆN - SỐ 02) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1SHJofBbo239ujQJO0GIy0GdJbVk6hjEK/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1wYYyF3WYlAknaKYhWVTKw5X-iwOwP5KB/view?usp=sharing",
          video: "https://fb.watch/th14IYIO6g/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-27",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 27 - BÀI GIẢNG TINH BỘT VÀ CELLULOSE",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 27",
    caLive: "",
    ngayLive: "16/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 27 - BÀI GIẢNG TINH BỘT VÀ CELLULOSE. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1bwIEAVGr2HR1cjwzicFLA1DeEfgPuQGQ/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1bwIEAVGr2HR1cjwzicFLA1DeEfgPuQGQ/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.facebook.com/100014073250721/videos/999642891705622/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 27"],
    downloads: 3331,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 27 (BÀI GIẢNG TINH BỘT VÀ CELLULOSE) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1bwIEAVGr2HR1cjwzicFLA1DeEfgPuQGQ/view?usp=sharing",
          fileVietTay: "",
          video: "https://www.facebook.com/100014073250721/videos/999642891705622/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-28",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 28 - THI THỰC CHIẾN LẦN 6",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 28",
    caLive: "",
    ngayLive: "17/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 28 - THI THỰC CHIẾN LẦN 6. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1TK_eRTj8rLWj9ZIcxNynFD4oRRlIZMhN/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1TK_eRTj8rLWj9ZIcxNynFD4oRRlIZMhN/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.youtube.com/watch?v=kt9Ze0DXvlQ",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 28"],
    downloads: 3324,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 28 (THI THỰC CHIẾN LẦN 6) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1TK_eRTj8rLWj9ZIcxNynFD4oRRlIZMhN/view?usp=sharing",
          fileVietTay: "",
          video: "https://www.youtube.com/watch?v=kt9Ze0DXvlQ"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-29",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 29 - CHỮA BTRL TINH BỘT VÀ CELLULOSE - SỐ 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 29",
    caLive: "",
    ngayLive: "18/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 29 - CHỮA BTRL TINH BỘT VÀ CELLULOSE - SỐ 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1WYzYizKXhwEpMFpAc0YA8KItjFTQK42U/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1WYzYizKXhwEpMFpAc0YA8KItjFTQK42U/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1vLL-Af89O8ZEWpsv6YBF-5BDa318DZwX/view?usp=sharing",
    video: "https://fb.watch/tpt3EaiBKI/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 29"],
    downloads: 3694,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 29 (CHỮA BTRL TINH BỘT VÀ CELLULOSE - SỐ 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1WYzYizKXhwEpMFpAc0YA8KItjFTQK42U/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1vLL-Af89O8ZEWpsv6YBF-5BDa318DZwX/view?usp=sharing",
          video: "https://fb.watch/tpt3EaiBKI/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-30",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 30 - CHỮA BTRL TINH BỘT VÀ CELLULOSE - SỐ 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 30",
    caLive: "",
    ngayLive: "19/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 30 - CHỮA BTRL TINH BỘT VÀ CELLULOSE - SỐ 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1zmxdb-BhOCRqGfXu-4pn007Bw_E957NF/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1zmxdb-BhOCRqGfXu-4pn007Bw_E957NF/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1mh2NxpNwx3dAJfnkwCwT-a9_hFeL7E71/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/445551351782654/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 30"],
    downloads: 3576,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 30 (CHỮA BTRL TINH BỘT VÀ CELLULOSE - SỐ 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1zmxdb-BhOCRqGfXu-4pn007Bw_E957NF/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1mh2NxpNwx3dAJfnkwCwT-a9_hFeL7E71/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/445551351782654/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-31",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 31 - BÀI GIẢNG AMINE",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 31",
    caLive: "",
    ngayLive: "23/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 31 - BÀI GIẢNG AMINE. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1MwPYdcSGbo7VaT7cfUBLBzixICKtHFhC/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1MwPYdcSGbo7VaT7cfUBLBzixICKtHFhC/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.facebook.com/100014073250721/videos/8344365062263272/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 31"],
    downloads: 3557,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 31 (BÀI GIẢNG AMINE) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1MwPYdcSGbo7VaT7cfUBLBzixICKtHFhC/view?usp=sharing",
          fileVietTay: "",
          video: "https://www.facebook.com/100014073250721/videos/8344365062263272/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-32",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 32 - 100 CÂU ÔN TẬP ESTER - LIPID",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 32",
    caLive: "",
    ngayLive: "24/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 32 - 100 CÂU ÔN TẬP ESTER - LIPID. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/134ucxxFwQ-YyKFtHN9zTPDs_tNVOkdZe/view",
    fileDe: "https://drive.google.com/file/d/134ucxxFwQ-YyKFtHN9zTPDs_tNVOkdZe/view",
    fileVietTay: "https://drive.google.com/file/d/1PltX_mk1bO8nXdLv48662TlwL_yakugg/view?usp=sharing",
    video: "https://fb.watch/txmTjQodxh/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 32"],
    downloads: 3534,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 32 (100 CÂU ÔN TẬP ESTER - LIPID) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/134ucxxFwQ-YyKFtHN9zTPDs_tNVOkdZe/view",
          fileVietTay: "https://drive.google.com/file/d/1PltX_mk1bO8nXdLv48662TlwL_yakugg/view?usp=sharing",
          video: "https://fb.watch/txmTjQodxh/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-33",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 33 - CHỮA BTRL AMINE - SỐ 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 33",
    caLive: "",
    ngayLive: "25/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 33 - CHỮA BTRL AMINE - SỐ 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1cPNN6jX3LDAo58jFl7bEDppeZ9Bla7GK/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1cPNN6jX3LDAo58jFl7bEDppeZ9Bla7GK/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1lCPRUiMX1Zww5O14c2XUgVZ2N2ACPcM3/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/465065766339687/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 33"],
    downloads: 3610,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 33 (CHỮA BTRL AMINE - SỐ 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1cPNN6jX3LDAo58jFl7bEDppeZ9Bla7GK/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1lCPRUiMX1Zww5O14c2XUgVZ2N2ACPcM3/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/465065766339687/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-34",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 34 - CHỮA BTRL AMINE - SỐ 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 34",
    caLive: "",
    ngayLive: "26/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 34 - CHỮA BTRL AMINE - SỐ 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1Nbhm_APVx8-iML5oSGWzSfvgvpKVo8Cu/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Nbhm_APVx8-iML5oSGWzSfvgvpKVo8Cu/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1RZPd2lbbu-rUEgoNS2qLHi_2rFreksml/view?usp=sharing",
    video: "https://fb.watch/tztDswh430/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 34"],
    downloads: 3386,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 34 (CHỮA BTRL AMINE - SỐ 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1Nbhm_APVx8-iML5oSGWzSfvgvpKVo8Cu/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1RZPd2lbbu-rUEgoNS2qLHi_2rFreksml/view?usp=sharing",
          video: "https://fb.watch/tztDswh430/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-35",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 35 - CHỮA SBT (CD, KNTT, CTST)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 35",
    caLive: "",
    ngayLive: "29/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 35 - CHỮA SBT (CD, KNTT, CTST). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/17Roro-w44a20gRLaJso3amYwAd6sHXk4/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/17Roro-w44a20gRLaJso3amYwAd6sHXk4/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1y8OPNd5Ytrrp6Ma0Xnf1Whlce1TLjzqB/view?usp=sharing",
    video: "https://fb.watch/tEND_YIaHX/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 35"],
    downloads: 3816,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 35 (CHỮA SBT (CD, KNTT, CTST)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/17Roro-w44a20gRLaJso3amYwAd6sHXk4/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1y8OPNd5Ytrrp6Ma0Xnf1Whlce1TLjzqB/view?usp=sharing",
          video: "https://fb.watch/tEND_YIaHX/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-36",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 36 - CHỮA SBT (CD, KNTT, CTST)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 36",
    caLive: "",
    ngayLive: "30/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 36 - CHỮA SBT (CD, KNTT, CTST). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/10xnjjTVh7AVaCs0yAeo0fhKQd2US20en/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/10xnjjTVh7AVaCs0yAeo0fhKQd2US20en/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/11EJebbvcXNf7bQG9WjuZRCJIgxrob-du/view?usp=sharing",
    video: "https://fb.watch/tENygwGpot/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 36"],
    downloads: 3592,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 36 (CHỮA SBT (CD, KNTT, CTST)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/10xnjjTVh7AVaCs0yAeo0fhKQd2US20en/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/11EJebbvcXNf7bQG9WjuZRCJIgxrob-du/view?usp=sharing",
          video: "https://fb.watch/tENygwGpot/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-37",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 37 - THI KSCL LẦN 07",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 37",
    caLive: "",
    ngayLive: "31/07/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 37 - THI KSCL LẦN 07. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1XEHGryabunJhDMr7oaSyxdOGJTXr5Ha6/edit?fbclid=IwZXh0bgNhZW0CMTAAAR26-KSxsIJByJ9ByTJ4W36v9JBshNkrtKvzfH0PGKYZbx6CP_mPWTfFPSU_aem_Hrx47aTfMEiqNV7c39ADXw",
    fileDe: "https://drive.google.com/file/d/1XEHGryabunJhDMr7oaSyxdOGJTXr5Ha6/edit?fbclid=IwZXh0bgNhZW0CMTAAAR26-KSxsIJByJ9ByTJ4W36v9JBshNkrtKvzfH0PGKYZbx6CP_mPWTfFPSU_aem_Hrx47aTfMEiqNV7c39ADXw",
    fileVietTay: "https://drive.google.com/file/d/140Q-rYYuVLFVjR1H26HwYwMgxYXbdcvc/view?usp=sharing",
    video: "https://www.youtube.com/watch?v=rcAs2e-adfs",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 37"],
    downloads: 3860,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 37 (THI KSCL LẦN 07) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1XEHGryabunJhDMr7oaSyxdOGJTXr5Ha6/edit?fbclid=IwZXh0bgNhZW0CMTAAAR26-KSxsIJByJ9ByTJ4W36v9JBshNkrtKvzfH0PGKYZbx6CP_mPWTfFPSU_aem_Hrx47aTfMEiqNV7c39ADXw",
          fileVietTay: "https://drive.google.com/file/d/140Q-rYYuVLFVjR1H26HwYwMgxYXbdcvc/view?usp=sharing",
          video: "https://www.youtube.com/watch?v=rcAs2e-adfs"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-38",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 38 - CHỮA SBT (CD, KNTT, CTST)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 38",
    caLive: "",
    ngayLive: "01/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 38 - CHỮA SBT (CD, KNTT, CTST). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1UB1pzCufbaSRrnnjwKPT-zpSxguLuFo8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1UB1pzCufbaSRrnnjwKPT-zpSxguLuFo8/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1GnlGEOsmxgLu5rwF9gYJcTHB5DQu6dXy/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/1479224959466156/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 38"],
    downloads: 3867,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 38 (CHỮA SBT (CD, KNTT, CTST)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1UB1pzCufbaSRrnnjwKPT-zpSxguLuFo8/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1GnlGEOsmxgLu5rwF9gYJcTHB5DQu6dXy/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/1479224959466156/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-39",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 39 - CHỮA SBT (CD, KNTT, CTST)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 39",
    caLive: "",
    ngayLive: "02/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 39 - CHỮA SBT (CD, KNTT, CTST). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1s7GBUgKpalsfG8jXDkbqse8w-PfdbmR4/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1s7GBUgKpalsfG8jXDkbqse8w-PfdbmR4/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/14MT5_exRnHeYUFQAqxAtVc2pV1LGGmrd/view?usp=sharing",
    video: "https://fb.watch/tKRlJJx_rs/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 39"],
    downloads: 3962,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 39 (CHỮA SBT (CD, KNTT, CTST)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1s7GBUgKpalsfG8jXDkbqse8w-PfdbmR4/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/14MT5_exRnHeYUFQAqxAtVc2pV1LGGmrd/view?usp=sharing",
          video: "https://fb.watch/tKRlJJx_rs/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-40",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 40 - CHỮA SBT (CD, KNTT, CTST)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 40",
    caLive: "",
    ngayLive: "03/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 40 - CHỮA SBT (CD, KNTT, CTST). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1T163KezVQEOmT7eElgw8u5Wj35ooKFkT/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1T163KezVQEOmT7eElgw8u5Wj35ooKFkT/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1VQnQNYVHiqOpxYLN7B2S2qPjBmA9VmHD/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/1206677987319748/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 40"],
    downloads: 3886,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 40 (CHỮA SBT (CD, KNTT, CTST)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1T163KezVQEOmT7eElgw8u5Wj35ooKFkT/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1VQnQNYVHiqOpxYLN7B2S2qPjBmA9VmHD/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/1206677987319748/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-41",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 41 - CHỮA SÁCH BT (CHƯƠNG 1 - CTST)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 41",
    caLive: "",
    ngayLive: "05/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 41 - CHỮA SÁCH BT (CHƯƠNG 1 - CTST). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1XEdf5HlJM-tOGhHhFMDkrgvF9dA3K1nf/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1XEdf5HlJM-tOGhHhFMDkrgvF9dA3K1nf/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1LLtuArIlidlmkHH_j7WuYEKmETDUp-rV/view?usp=sharing",
    video: "https://www.facebook.com/100005267714959/videos/1030672111784561?idorvanity=339825519117801",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 41"],
    downloads: 3569,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 41 (CHỮA SÁCH BT (CHƯƠNG 1 - CTST)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1XEdf5HlJM-tOGhHhFMDkrgvF9dA3K1nf/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1LLtuArIlidlmkHH_j7WuYEKmETDUp-rV/view?usp=sharing",
          video: "https://www.facebook.com/100005267714959/videos/1030672111784561?idorvanity=339825519117801"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-42",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 42 - BÀI GIẢNG AMINO ACID",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 42",
    caLive: "",
    ngayLive: "06/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 42 - BÀI GIẢNG AMINO ACID. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1adJxhjR3VoUes6EqZ-mkSa9UGSWMnN62/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1adJxhjR3VoUes6EqZ-mkSa9UGSWMnN62/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.facebook.com/thaynaphoa/videos/1526929941552142?idorvanity=339825519117801",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 42"],
    downloads: 3775,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 42 (BÀI GIẢNG AMINO ACID) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1adJxhjR3VoUes6EqZ-mkSa9UGSWMnN62/view?usp=sharing",
          fileVietTay: "",
          video: "https://www.facebook.com/thaynaphoa/videos/1526929941552142?idorvanity=339825519117801"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-43",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 43 - THI KSCL LẦN 08",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 43",
    caLive: "",
    ngayLive: "07/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 43 - THI KSCL LẦN 08. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1mVr-LZwZhF9MXdi2J3RRBDcdoYmSUY_f/edit?fbclid=IwY2xjawEjvzRleHRuA2FlbQIxMAABHW2PwOHhvE3li27xeOzqF3SU9q690qsDt-rNE0jEBZE6cmbMWoHvbs5nJA_aem_dDs58Ht04CYxobAPblyvJA",
    fileDe: "https://drive.google.com/file/d/1mVr-LZwZhF9MXdi2J3RRBDcdoYmSUY_f/edit?fbclid=IwY2xjawEjvzRleHRuA2FlbQIxMAABHW2PwOHhvE3li27xeOzqF3SU9q690qsDt-rNE0jEBZE6cmbMWoHvbs5nJA_aem_dDs58Ht04CYxobAPblyvJA",
    fileVietTay: "https://drive.google.com/file/d/1ohMZVZZI2AbD-d4fY6dOVhmHDQZzO_ve/view?usp=sharing",
    video: "https://www.youtube.com/watch?v=6OHI0jBYTK0",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 43"],
    downloads: 3661,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 43 (THI KSCL LẦN 08) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1mVr-LZwZhF9MXdi2J3RRBDcdoYmSUY_f/edit?fbclid=IwY2xjawEjvzRleHRuA2FlbQIxMAABHW2PwOHhvE3li27xeOzqF3SU9q690qsDt-rNE0jEBZE6cmbMWoHvbs5nJA_aem_dDs58Ht04CYxobAPblyvJA",
          fileVietTay: "https://drive.google.com/file/d/1ohMZVZZI2AbD-d4fY6dOVhmHDQZzO_ve/view?usp=sharing",
          video: "https://www.youtube.com/watch?v=6OHI0jBYTK0"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-44",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 44 - CHỮA BTRL AMINO ACID PHẦN 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 44",
    caLive: "",
    ngayLive: "08/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 44 - CHỮA BTRL AMINO ACID PHẦN 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1VCW7xItOORLSGIMhwR8IpQiTgCju76AT/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1VCW7xItOORLSGIMhwR8IpQiTgCju76AT/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/17tX-P29_QIB41q2ggWlinu9N2itRXV-_/view?usp=sharing",
    video: "https://www.facebook.com/100005267714959/videos/1966389783778968?idorvanity=339825519117801",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 44"],
    downloads: 3843,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 44 (CHỮA BTRL AMINO ACID PHẦN 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1VCW7xItOORLSGIMhwR8IpQiTgCju76AT/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/17tX-P29_QIB41q2ggWlinu9N2itRXV-_/view?usp=sharing",
          video: "https://www.facebook.com/100005267714959/videos/1966389783778968?idorvanity=339825519117801"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-45",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 45 - CHỮA BTRL AMINO ACID PHẦN 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 45",
    caLive: "",
    ngayLive: "09/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 45 - CHỮA BTRL AMINO ACID PHẦN 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1Oeh87MeZsLwgDJgIFSK9hJeoAe8iRDCa/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Oeh87MeZsLwgDJgIFSK9hJeoAe8iRDCa/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1k_btYbZqX9x9P724PX2bDwzlpEdYxkHR/view?usp=sharing",
    video: "https://www.facebook.com/100005267714959/videos/1601111340467095?idorvanity=339825519117801",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 45"],
    downloads: 3666,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 45 (CHỮA BTRL AMINO ACID PHẦN 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1Oeh87MeZsLwgDJgIFSK9hJeoAe8iRDCa/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1k_btYbZqX9x9P724PX2bDwzlpEdYxkHR/view?usp=sharing",
          video: "https://www.facebook.com/100005267714959/videos/1601111340467095?idorvanity=339825519117801"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-46",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 46 - CHỮA ĐỀ THAM KHẢO HSA - 2025",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 46",
    caLive: "",
    ngayLive: "09/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 46 - CHỮA ĐỀ THAM KHẢO HSA - 2025. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/17vsMqbcCQxcVR8R_sLlLIZdalXeYfLZR/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/17vsMqbcCQxcVR8R_sLlLIZdalXeYfLZR/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1_5E95yWCpy-qCrHECRzKtrSGuBzcbklj/view?usp=sharing",
    video: "https://www.facebook.com/thaynapdayhoa/videos/1051960916266190",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 46"],
    downloads: 3810,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 46 (CHỮA ĐỀ THAM KHẢO HSA - 2025) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/17vsMqbcCQxcVR8R_sLlLIZdalXeYfLZR/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1_5E95yWCpy-qCrHECRzKtrSGuBzcbklj/view?usp=sharing",
          video: "https://www.facebook.com/thaynapdayhoa/videos/1051960916266190"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-47",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 47 - THI THỬ THỰC CHIẾN ĐỀ 09",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 47",
    caLive: "",
    ngayLive: "12/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 47 - THI THỬ THỰC CHIẾN ĐỀ 09. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1rdhNqhley3N0WI6wxcs-lOEQOq-qv9Lr/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1rdhNqhley3N0WI6wxcs-lOEQOq-qv9Lr/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1krQXxVTGKdP6PnbDQxFnRRZofvJ1BpYk/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/782286967181693/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 47"],
    downloads: 3666,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 47 (THI THỬ THỰC CHIẾN ĐỀ 09) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1rdhNqhley3N0WI6wxcs-lOEQOq-qv9Lr/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1krQXxVTGKdP6PnbDQxFnRRZofvJ1BpYk/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/782286967181693/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-48",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 48 - BÀI GIẢNG: PEPTIDE, PROTEIN & ENZYME",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 48",
    caLive: "",
    ngayLive: "13/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 48 - BÀI GIẢNG: PEPTIDE, PROTEIN & ENZYME. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1mgPMT7U_nFVpgGeoCbLUQkhWW0MMfFjR/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1mgPMT7U_nFVpgGeoCbLUQkhWW0MMfFjR/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.facebook.com/100014073250721/videos/467584592915152/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 48"],
    downloads: 3653,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 48 (BÀI GIẢNG: PEPTIDE, PROTEIN & ENZYME) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1mgPMT7U_nFVpgGeoCbLUQkhWW0MMfFjR/view?usp=sharing",
          fileVietTay: "",
          video: "https://www.facebook.com/100014073250721/videos/467584592915152/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-49",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 49 - THI THỬ THỰC CHIẾN ĐỀ 10",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 49",
    caLive: "",
    ngayLive: "14/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 49 - THI THỬ THỰC CHIẾN ĐỀ 10. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1In_Ek8507EgLvMlsTau7X3mgqpysXmr8/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1In_Ek8507EgLvMlsTau7X3mgqpysXmr8/view?usp=sharing",
    fileVietTay: "",
    video: "https://fb.watch/t_r9b4oau2/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 49"],
    downloads: 3676,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 49 (THI THỬ THỰC CHIẾN ĐỀ 10) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1In_Ek8507EgLvMlsTau7X3mgqpysXmr8/view?usp=sharing",
          fileVietTay: "",
          video: "https://fb.watch/t_r9b4oau2/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-50",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 50 - CHỮA BTRL - PHẦN 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 50",
    caLive: "",
    ngayLive: "15/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 50 - CHỮA BTRL - PHẦN 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/10fRBhtzN8inZMC3NdJyOZY1u0hN2nCLz/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/10fRBhtzN8inZMC3NdJyOZY1u0hN2nCLz/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1emKrXcPXbDgufe2z70m-erS7BeY6-GLi/view?usp=sharing",
    video: "https://fb.watch/t_qOLnoyPd/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 50"],
    downloads: 3764,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 50 (CHỮA BTRL - PHẦN 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/10fRBhtzN8inZMC3NdJyOZY1u0hN2nCLz/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1emKrXcPXbDgufe2z70m-erS7BeY6-GLi/view?usp=sharing",
          video: "https://fb.watch/t_qOLnoyPd/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-51",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 51 - CHỮA BTRL - PHẦN 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 51",
    caLive: "",
    ngayLive: "16/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 51 - CHỮA BTRL - PHẦN 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1nKqmOLqeFYOEoDluAf4jV41ADLIgZK5N/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1nKqmOLqeFYOEoDluAf4jV41ADLIgZK5N/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1plCWQxVnwmgvDu8C8s9TkP-N9j-We0zP/view?usp=sharing",
    video: "https://fb.watch/u3FdNATim2/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 51"],
    downloads: 3738,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 51 (CHỮA BTRL - PHẦN 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1nKqmOLqeFYOEoDluAf4jV41ADLIgZK5N/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1plCWQxVnwmgvDu8C8s9TkP-N9j-We0zP/view?usp=sharing",
          video: "https://fb.watch/u3FdNATim2/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-52",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 52 - THI THỬ THỰC CHIẾN ĐỀ 11",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 52",
    caLive: "",
    ngayLive: "17/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 52 - THI THỬ THỰC CHIẾN ĐỀ 11. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1slb3j2XruRsjBqwiYzi20UrqQfP6PUcH/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1slb3j2XruRsjBqwiYzi20UrqQfP6PUcH/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1b9Nm810W9ghWS115hqIp0gYN3wRccGKW/view?usp=sharing",
    video: "https://fb.watch/u2p0TIDWHx/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 52"],
    downloads: 3363,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 52 (THI THỬ THỰC CHIẾN ĐỀ 11) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1slb3j2XruRsjBqwiYzi20UrqQfP6PUcH/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1b9Nm810W9ghWS115hqIp0gYN3wRccGKW/view?usp=sharing",
          video: "https://fb.watch/u2p0TIDWHx/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-53",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 53 - THI THỬ THỰC CHIẾN ĐỀ 12",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 53",
    caLive: "",
    ngayLive: "19/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 53 - THI THỬ THỰC CHIẾN ĐỀ 12. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1iiQmvJeu1OfThh8v3jTIMXkf9cD5akuQ/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1iiQmvJeu1OfThh8v3jTIMXkf9cD5akuQ/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1x68TTxHdRGYxPXx5d0CNccPDC3z-pqeC/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/1041953990919651/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 53"],
    downloads: 3326,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 53 (THI THỬ THỰC CHIẾN ĐỀ 12) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1iiQmvJeu1OfThh8v3jTIMXkf9cD5akuQ/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1x68TTxHdRGYxPXx5d0CNccPDC3z-pqeC/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/1041953990919651/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-54",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 54 - ÔN TẬP CHƯƠNG 3 PHẦN 1",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 54",
    caLive: "",
    ngayLive: "20/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 54 - ÔN TẬP CHƯƠNG 3 PHẦN 1. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/12UAK9zuJ3m-2A126xPi-COYCG522eie4/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/12UAK9zuJ3m-2A126xPi-COYCG522eie4/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1_2HF5bTuJyapi4tGt1aQM2YpuGEltXuN/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/1246517223187150/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 54"],
    downloads: 3706,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 54 (ÔN TẬP CHƯƠNG 3 PHẦN 1) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/12UAK9zuJ3m-2A126xPi-COYCG522eie4/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1_2HF5bTuJyapi4tGt1aQM2YpuGEltXuN/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/1246517223187150/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-55",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 55 - CHỮA ĐỀ THỰC CHIẾN 13",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 55",
    caLive: "",
    ngayLive: "21/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 55 - CHỮA ĐỀ THỰC CHIẾN 13. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/12n6ZmXOlj-u1ADXdyk85T-P94Asku9QR/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/12n6ZmXOlj-u1ADXdyk85T-P94Asku9QR/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.youtube.com/watch?v=y_s-fmUsoZg",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 55"],
    downloads: 3674,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 55 (CHỮA ĐỀ THỰC CHIẾN 13) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/12n6ZmXOlj-u1ADXdyk85T-P94Asku9QR/view?usp=sharing",
          fileVietTay: "",
          video: "https://www.youtube.com/watch?v=y_s-fmUsoZg"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-56",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 56 - ÔN TẬP CHƯƠNG 3 PHẦN 2",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 56",
    caLive: "",
    ngayLive: "22/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 56 - ÔN TẬP CHƯƠNG 3 PHẦN 2. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1q7DN54FQLr2Ebyki_27PXmLMHibiGzQx/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1q7DN54FQLr2Ebyki_27PXmLMHibiGzQx/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1t6GO0KEwaCf9_pwoJkru6oqBwc_HdnLg/view?usp=sharing",
    video: "https://fb.watch/u8WGsflMYY/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 56"],
    downloads: 3655,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 56 (ÔN TẬP CHƯƠNG 3 PHẦN 2) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1q7DN54FQLr2Ebyki_27PXmLMHibiGzQx/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1t6GO0KEwaCf9_pwoJkru6oqBwc_HdnLg/view?usp=sharing",
          video: "https://fb.watch/u8WGsflMYY/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-57",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 57 - ÔN TẬP CHƯƠNG 3 PHẦN 3",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 57",
    caLive: "",
    ngayLive: "23/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 57 - ÔN TẬP CHƯƠNG 3 PHẦN 3. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1m4yqKTJ7LXIznfXwKIlXpCIAMm29LMbX/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1m4yqKTJ7LXIznfXwKIlXpCIAMm29LMbX/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1psyPr6BhJuhdXW9fSqtwMOUQeEEasqO6/view?usp=sharing",
    video: "https://fb.watch/u8WFCwlr6j/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 57"],
    downloads: 3582,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 57 (ÔN TẬP CHƯƠNG 3 PHẦN 3) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1m4yqKTJ7LXIznfXwKIlXpCIAMm29LMbX/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1psyPr6BhJuhdXW9fSqtwMOUQeEEasqO6/view?usp=sharing",
          video: "https://fb.watch/u8WFCwlr6j/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-58",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 58 - THI THỬ THỰC CHIẾN ĐỀ 14",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 58",
    caLive: "",
    ngayLive: "24/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 58 - THI THỬ THỰC CHIẾN ĐỀ 14. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1aJtxwqFNZUWDO0ZRfxbOhy9KN3DPqbiO/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1aJtxwqFNZUWDO0ZRfxbOhy9KN3DPqbiO/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1HFxOC2mB3tp33GfWLZ69f7PhMWQsJf8n/view?usp=sharing",
    video: "https://fb.watch/uoQSON2Q2v/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 58"],
    downloads: 3617,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 58 (THI THỬ THỰC CHIẾN ĐỀ 14) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1aJtxwqFNZUWDO0ZRfxbOhy9KN3DPqbiO/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1HFxOC2mB3tp33GfWLZ69f7PhMWQsJf8n/view?usp=sharing",
          video: "https://fb.watch/uoQSON2Q2v/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-59",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 59 - THI THỬ THỰC CHIẾN ĐỀ 15",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 59",
    caLive: "",
    ngayLive: "25/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 59 - THI THỬ THỰC CHIẾN ĐỀ 15. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1HIukTVPSXennYbWWpck6dA7OH-89bRtU/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1HIukTVPSXennYbWWpck6dA7OH-89bRtU/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1v82SU0GuK8WVfdmHZg-2O79_6wvOanBr/view?usp=sharing",
    video: "https://fb.watch/uyIQ1Wf1be/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 59"],
    downloads: 3314,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 59 (THI THỬ THỰC CHIẾN ĐỀ 15) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1HIukTVPSXennYbWWpck6dA7OH-89bRtU/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1v82SU0GuK8WVfdmHZg-2O79_6wvOanBr/view?usp=sharing",
          video: "https://fb.watch/uyIQ1Wf1be/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-60",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 60 - BÀI GIẢNG 01: ĐẠI CƯƠNG VỀ POLYMER",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 60",
    caLive: "",
    ngayLive: "27/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 60 - BÀI GIẢNG 01: ĐẠI CƯƠNG VỀ POLYMER. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1rNvPXTiA8ttMSaULZxd4-Uo5oFdmtott/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1rNvPXTiA8ttMSaULZxd4-Uo5oFdmtott/view?usp=drive_link",
    fileVietTay: "",
    video: "https://fb.watch/ugVaqsffgj/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 60"],
    downloads: 3390,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 60 (BÀI GIẢNG 01: ĐẠI CƯƠNG VỀ POLYMER) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1rNvPXTiA8ttMSaULZxd4-Uo5oFdmtott/view?usp=drive_link",
          fileVietTay: "",
          video: "https://fb.watch/ugVaqsffgj/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-61",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 61 - BTRL ĐẠI CƯƠNG VỀ POLYMER",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 61",
    caLive: "",
    ngayLive: "29/08/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 61 - BTRL ĐẠI CƯƠNG VỀ POLYMER. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1nz8DNpXl6wBoW9QaE4-XSRYZRBVmwFmb/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1nz8DNpXl6wBoW9QaE4-XSRYZRBVmwFmb/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1K3dJmeijsTxFgVxIQxMOjRTjUegRmVNa/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/1234791200851028/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 61"],
    downloads: 3627,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 61 (BTRL ĐẠI CƯƠNG VỀ POLYMER) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1nz8DNpXl6wBoW9QaE4-XSRYZRBVmwFmb/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1K3dJmeijsTxFgVxIQxMOjRTjUegRmVNa/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/1234791200851028/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-62",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 62 - BÀI GIẢNG VẬT LIỆU POLYMER",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 62",
    caLive: "",
    ngayLive: "05/09/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 62 - BÀI GIẢNG VẬT LIỆU POLYMER. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1aGKaCGPzL_GGBq8VbOKk3lJuA7qYzTDT/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1aGKaCGPzL_GGBq8VbOKk3lJuA7qYzTDT/view?usp=sharing",
    fileVietTay: "",
    video: "https://fb.watch/uu6FZ4OMK5/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 62"],
    downloads: 3783,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 62 (BÀI GIẢNG VẬT LIỆU POLYMER) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1aGKaCGPzL_GGBq8VbOKk3lJuA7qYzTDT/view?usp=sharing",
          fileVietTay: "",
          video: "https://fb.watch/uu6FZ4OMK5/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-63",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 63 - BTRL VẬT LIỆU POLYMER",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 63",
    caLive: "",
    ngayLive: "07/09/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 63 - BTRL VẬT LIỆU POLYMER. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/108YwhoHVpyGuPs3-8QOwR0i4c6TecDCX/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/108YwhoHVpyGuPs3-8QOwR0i4c6TecDCX/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1z4FOZ3CQcZ4pl6Z2rzyRnJg7bOc-wO7G/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/1052897605764930/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 63"],
    downloads: 3545,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 63 (BTRL VẬT LIỆU POLYMER) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/108YwhoHVpyGuPs3-8QOwR0i4c6TecDCX/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1z4FOZ3CQcZ4pl6Z2rzyRnJg7bOc-wO7G/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/1052897605764930/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-64",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 64 - ÔN TẬP POLYMER",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 64",
    caLive: "",
    ngayLive: "12/09/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 64 - ÔN TẬP POLYMER. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1ohTLZGai4V3ZYrQOnVKU31YwZe2S-Jcy/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1ohTLZGai4V3ZYrQOnVKU31YwZe2S-Jcy/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1IFw5zOudZEjm9kUCFX-5-ymh_DN0SzNN/view?usp=sharing",
    video: "https://fb.watch/uyKkAGXyBl/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 64"],
    downloads: 3506,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 64 (ÔN TẬP POLYMER) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1ohTLZGai4V3ZYrQOnVKU31YwZe2S-Jcy/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1IFw5zOudZEjm9kUCFX-5-ymh_DN0SzNN/view?usp=sharing",
          video: "https://fb.watch/uyKkAGXyBl/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-65",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 65 - BÀI GIẢNG: THẾ ĐIỆN CỰC, PIN ĐIỆN HÓA",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 65",
    caLive: "",
    ngayLive: "17/09/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 65 - BÀI GIẢNG: THẾ ĐIỆN CỰC, PIN ĐIỆN HÓA. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1b_n-6BcDMYNLBxmGLra6iIHhjIpdz0e4/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1b_n-6BcDMYNLBxmGLra6iIHhjIpdz0e4/view?usp=sharing",
    fileVietTay: "",
    video: "https://fb.watch/uKxWyzzpFr/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 65"],
    downloads: 3621,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 65 (BÀI GIẢNG: THẾ ĐIỆN CỰC, PIN ĐIỆN HÓA) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1b_n-6BcDMYNLBxmGLra6iIHhjIpdz0e4/view?usp=sharing",
          fileVietTay: "",
          video: "https://fb.watch/uKxWyzzpFr/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-66",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 66 - CHỮA BTRL : THẾ ĐIỆN CỰC, PIN ĐIỆN HÓA",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 66",
    caLive: "",
    ngayLive: "19/09/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 66 - CHỮA BTRL : THẾ ĐIỆN CỰC, PIN ĐIỆN HÓA. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1PU_DoWu078R45d_1FsDG7G2T4UJOWGp4/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1PU_DoWu078R45d_1FsDG7G2T4UJOWGp4/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1dH8I8Xl33M-s71sDPXIx1Y_WyK7Asv6P/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/891798526161710/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 66"],
    downloads: 3998,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 66 (CHỮA BTRL : THẾ ĐIỆN CỰC, PIN ĐIỆN HÓA) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1PU_DoWu078R45d_1FsDG7G2T4UJOWGp4/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1dH8I8Xl33M-s71sDPXIx1Y_WyK7Asv6P/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/891798526161710/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-67",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 67 - BÀI GIẢNG ĐIỆN PHÂN",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 67",
    caLive: "",
    ngayLive: "24/09/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 67 - BÀI GIẢNG ĐIỆN PHÂN. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/15P51mXoRBn9oyyvFhlITcc6L7z7QEd0D/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/15P51mXoRBn9oyyvFhlITcc6L7z7QEd0D/view?usp=sharing",
    fileVietTay: "",
    video: "https://fb.watch/uRcBGRvE1P/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 67"],
    downloads: 3588,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 67 (BÀI GIẢNG ĐIỆN PHÂN) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/15P51mXoRBn9oyyvFhlITcc6L7z7QEd0D/view?usp=sharing",
          fileVietTay: "",
          video: "https://fb.watch/uRcBGRvE1P/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-68",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 68 - CHỮA BTRL ĐIỆN PHÂN",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 68",
    caLive: "",
    ngayLive: "26/09/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 68 - CHỮA BTRL ĐIỆN PHÂN. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1oZpJmo0P3XDBSTVBqOselbHHT4ibBYG7/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1oZpJmo0P3XDBSTVBqOselbHHT4ibBYG7/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1frn1A-TfWn_BJqBBMyiPBCbEOdmkK-fU/view?usp=sharing",
    video: "https://www.facebook.com/100048652783192/videos/1653660125484980/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 68"],
    downloads: 3649,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 68 (CHỮA BTRL ĐIỆN PHÂN) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1oZpJmo0P3XDBSTVBqOselbHHT4ibBYG7/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1frn1A-TfWn_BJqBBMyiPBCbEOdmkK-fU/view?usp=sharing",
          video: "https://www.facebook.com/100048652783192/videos/1653660125484980/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-69",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 69 - BÀI TOÁN PIN, ĐIỆN PHÂN (PHẦN 1)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 69",
    caLive: "",
    ngayLive: "01/10/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 69 - BÀI TOÁN PIN, ĐIỆN PHÂN (PHẦN 1). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1ExaigxQOSy8isjOztpe-2I5IqvmJxxmB/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1ExaigxQOSy8isjOztpe-2I5IqvmJxxmB/view?usp=sharing",
    fileVietTay: "",
    video: "https://fb.watch/vdZmTFmTPz/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 69"],
    downloads: 3800,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 69 (BÀI TOÁN PIN, ĐIỆN PHÂN (PHẦN 1)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1ExaigxQOSy8isjOztpe-2I5IqvmJxxmB/view?usp=sharing",
          fileVietTay: "",
          video: "https://fb.watch/vdZmTFmTPz/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-70",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 70 - CHỮA ĐỀ GIỮA HK1 (ĐỀ 1 + 2)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 70",
    caLive: "",
    ngayLive: "02/10/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 70 - CHỮA ĐỀ GIỮA HK1 (ĐỀ 1 + 2). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1ug2YQLqOkPwko7yP7j69x8Uz3gLPkz_6/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1ug2YQLqOkPwko7yP7j69x8Uz3gLPkz_6/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1jrrJQxbb8g2K7tGIyZJZsd_vrBajGQ6C/view?usp=sharing",
    video: "https://fb.watch/uZ4C8oEmUy/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 70"],
    downloads: 3651,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 70 (CHỮA ĐỀ GIỮA HK1 (ĐỀ 1 + 2)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1ug2YQLqOkPwko7yP7j69x8Uz3gLPkz_6/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1jrrJQxbb8g2K7tGIyZJZsd_vrBajGQ6C/view?usp=sharing",
          video: "https://fb.watch/uZ4C8oEmUy/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-71",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 71 - BÀI TOÁN PIN, ĐIỆN PHÂN (PHẦN 2)",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 71",
    caLive: "",
    ngayLive: "03/10/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 71 - BÀI TOÁN PIN, ĐIỆN PHÂN (PHẦN 2). Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1sph4xZb_CDyGsMmbHmb2OOfLvAoShWDD/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1sph4xZb_CDyGsMmbHmb2OOfLvAoShWDD/view?usp=sharing",
    fileVietTay: "",
    video: "https://fb.watch/vdZh51IfNu/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 71"],
    downloads: 3709,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 71 (BÀI TOÁN PIN, ĐIỆN PHÂN (PHẦN 2)) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1sph4xZb_CDyGsMmbHmb2OOfLvAoShWDD/view?usp=sharing",
          fileVietTay: "",
          video: "https://fb.watch/vdZh51IfNu/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-72",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 72 - LIÊN KẾT KIM LOẠI, TCVL, TCHH",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 72",
    caLive: "",
    ngayLive: "29/10/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 72 - LIÊN KẾT KIM LOẠI, TCVL, TCHH. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1r4JKP5bn1nD7QH3NYFgY_4krXzb-Rb8R/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1r4JKP5bn1nD7QH3NYFgY_4krXzb-Rb8R/view?usp=drive_link",
    fileVietTay: "",
    video: "https://www.facebook.com/thaynaphoa/videos/348548648304631?idorvanity=339825519117801",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 72"],
    downloads: 3889,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 72 (LIÊN KẾT KIM LOẠI, TCVL, TCHH) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1r4JKP5bn1nD7QH3NYFgY_4krXzb-Rb8R/view?usp=drive_link",
          fileVietTay: "",
          video: "https://www.facebook.com/thaynaphoa/videos/348548648304631?idorvanity=339825519117801"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-73",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 73 - BTRL LIÊN KẾT KIM LOẠI, TCVL, TCHH",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 73",
    caLive: "",
    ngayLive: "01/11/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 73 - BTRL LIÊN KẾT KIM LOẠI, TCVL, TCHH. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1s1qvR64vZB7ci3X5TjYfGXz7AvcPrdM6/view?usp=drive_link",
    fileDe: "https://drive.google.com/file/d/1s1qvR64vZB7ci3X5TjYfGXz7AvcPrdM6/view?usp=drive_link",
    fileVietTay: "https://drive.google.com/file/d/1HSe-yZVmgKYgMY8uGyPxUQ931NtOdhcL/view?usp=sharing",
    video: "https://fb.watch/vAEyogGQtZ/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 73"],
    downloads: 3612,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 73 (BTRL LIÊN KẾT KIM LOẠI, TCVL, TCHH) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1s1qvR64vZB7ci3X5TjYfGXz7AvcPrdM6/view?usp=drive_link",
          fileVietTay: "https://drive.google.com/file/d/1HSe-yZVmgKYgMY8uGyPxUQ931NtOdhcL/view?usp=sharing",
          video: "https://fb.watch/vAEyogGQtZ/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-74",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 74 - BÀI GIẢNG KIM LOẠI TRONG TỰ NHIÊN, TÁCH KIM LOẠI, HỢP KIM",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 74",
    caLive: "",
    ngayLive: "05/11/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 74 - BÀI GIẢNG KIM LOẠI TRONG TỰ NHIÊN, TÁCH KIM LOẠI, HỢP KIM. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1Lmmv20paoTu9gflyWPKWABeh4Q-HaQcI/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Lmmv20paoTu9gflyWPKWABeh4Q-HaQcI/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.facebook.com/hoahocnapschool/videos/924299116260222/?idorvanity=339825519117801",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 74"],
    downloads: 3350,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 74 (BÀI GIẢNG KIM LOẠI TRONG TỰ NHIÊN, TÁCH KIM LOẠI, HỢP KIM) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1Lmmv20paoTu9gflyWPKWABeh4Q-HaQcI/view?usp=sharing",
          fileVietTay: "",
          video: "https://www.facebook.com/hoahocnapschool/videos/924299116260222/?idorvanity=339825519117801"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-75",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 75 - BTRL ĐCKL, hợp kim",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 75",
    caLive: "",
    ngayLive: "08/11/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 75 - BTRL ĐCKL, hợp kim. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1o_fkXhFZJn9znV6YqlcI7hQb4Eit7bvR/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1o_fkXhFZJn9znV6YqlcI7hQb4Eit7bvR/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1CSs6HPPIT0xdUAcMPwjbxR4nW7Mw4Qsw/view?usp=sharing",
    video: "https://fb.watch/vOsPYmyTA1/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 75"],
    downloads: 3394,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 75 (BTRL ĐCKL, hợp kim) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1o_fkXhFZJn9znV6YqlcI7hQb4Eit7bvR/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1CSs6HPPIT0xdUAcMPwjbxR4nW7Mw4Qsw/view?usp=sharing",
          video: "https://fb.watch/vOsPYmyTA1/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-76",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 76 - BÀI GIẢNG NGUYÊN TỐ NHÓM IA",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 76",
    caLive: "",
    ngayLive: "20/11/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 76 - BÀI GIẢNG NGUYÊN TỐ NHÓM IA. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1LHNwyi8hfoacdGZAipdLMgu2a9t9gaQO/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1LHNwyi8hfoacdGZAipdLMgu2a9t9gaQO/view?usp=sharing",
    fileVietTay: "",
    video: "https://www.facebook.com/hoahocnapschool/videos/613076284377748/?idorvanity=339825519117801",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 76"],
    downloads: 3716,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 76 (BÀI GIẢNG NGUYÊN TỐ NHÓM IA) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1LHNwyi8hfoacdGZAipdLMgu2a9t9gaQO/view?usp=sharing",
          fileVietTay: "",
          video: "https://www.facebook.com/hoahocnapschool/videos/613076284377748/?idorvanity=339825519117801"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-77",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 77 - BTRL NGUYÊN TỐ NHÓM IA",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 77",
    caLive: "",
    ngayLive: "21/11/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 77 - BTRL NGUYÊN TỐ NHÓM IA. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1Dpiy2IG1vGj0NmtDNHQaYCRrY8aiT_Fn/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1Dpiy2IG1vGj0NmtDNHQaYCRrY8aiT_Fn/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1Cz0RyyOVcW-BlyKRGWXZdQyesKjAub3a/view?usp=sharing",
    video: "https://www.facebook.com/100005267714959/videos/611713427863661?idorvanity=339825519117801",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 77"],
    downloads: 3816,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 77 (BTRL NGUYÊN TỐ NHÓM IA) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1Dpiy2IG1vGj0NmtDNHQaYCRrY8aiT_Fn/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1Cz0RyyOVcW-BlyKRGWXZdQyesKjAub3a/view?usp=sharing",
          video: "https://www.facebook.com/100005267714959/videos/611713427863661?idorvanity=339825519117801"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-78",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 78 - BÀI GIẢNG NGUYÊN TỐ NHÓM IIA",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 78",
    caLive: "",
    ngayLive: "27/11/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 78 - BÀI GIẢNG NGUYÊN TỐ NHÓM IIA. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1ceY3qbmXX-ihTj7QMyAuYroBQA24zfLS/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1ceY3qbmXX-ihTj7QMyAuYroBQA24zfLS/view?usp=sharing",
    fileVietTay: "",
    video: "https://fb.watch/wd7fY3wRvM/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 78"],
    downloads: 3867,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 78 (BÀI GIẢNG NGUYÊN TỐ NHÓM IIA) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1ceY3qbmXX-ihTj7QMyAuYroBQA24zfLS/view?usp=sharing",
          fileVietTay: "",
          video: "https://fb.watch/wd7fY3wRvM/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-79",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 79 - BTRL NGUYÊN TỐ NHÓM IIA",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 79",
    caLive: "",
    ngayLive: "28/11/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 79 - BTRL NGUYÊN TỐ NHÓM IIA. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1euGlec_QBOs29wNLJ66bQ_IcWR-xeSzN/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1euGlec_QBOs29wNLJ66bQ_IcWR-xeSzN/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1RzoBEN4SDkSqaBox-G_JsiGj2ie4kiUY/view?usp=sharing",
    video: "https://fb.watch/wd7hL9m2DT/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 79"],
    downloads: 3517,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 79 (BTRL NGUYÊN TỐ NHÓM IIA) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1euGlec_QBOs29wNLJ66bQ_IcWR-xeSzN/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1RzoBEN4SDkSqaBox-G_JsiGj2ie4kiUY/view?usp=sharing",
          video: "https://fb.watch/wd7hL9m2DT/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-80",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 80 - BÀI GIẢNG KIM LOẠI CHUYỂN TIẾP",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 80",
    caLive: "",
    ngayLive: "04/12/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 80 - BÀI GIẢNG KIM LOẠI CHUYỂN TIẾP. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://fb.watch/wipIhqqqHt/",
    fileDe: "",
    fileVietTay: "",
    video: "https://fb.watch/wipIhqqqHt/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 80"],
    downloads: 3522,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 80 (BÀI GIẢNG KIM LOẠI CHUYỂN TIẾP) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: "https://fb.watch/wipIhqqqHt/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-81",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 81 - BTRL KIM LOẠI CHUYỂN TIẾP",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 81",
    caLive: "",
    ngayLive: "05/12/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 81 - BTRL KIM LOẠI CHUYỂN TIẾP. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1n643u85SEnSdO2eVN2V0OgSP8QSVVy9t/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1n643u85SEnSdO2eVN2V0OgSP8QSVVy9t/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/120KrODAkG_hpCnH5cWJNRmfD4fGodu3S/view?usp=sharing",
    video: "https://fb.watch/wipE1Qd8XQ/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 81"],
    downloads: 3646,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 81 (BTRL KIM LOẠI CHUYỂN TIẾP) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1n643u85SEnSdO2eVN2V0OgSP8QSVVy9t/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/120KrODAkG_hpCnH5cWJNRmfD4fGodu3S/view?usp=sharing",
          video: "https://fb.watch/wipE1Qd8XQ/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-82",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 82 - BÀI GIẢNG PHỨC CHẤT",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 82",
    caLive: "",
    ngayLive: "10/12/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 82 - BÀI GIẢNG PHỨC CHẤT. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1uyL1jfE-81AUoNj5-lQto5JsrFZY86Y4/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1uyL1jfE-81AUoNj5-lQto5JsrFZY86Y4/view?usp=sharing",
    fileVietTay: "",
    video: "https://fb.watch/wpYnkFTSdQ/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 82"],
    downloads: 3873,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 82 (BÀI GIẢNG PHỨC CHẤT) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1uyL1jfE-81AUoNj5-lQto5JsrFZY86Y4/view?usp=sharing",
          fileVietTay: "",
          video: "https://fb.watch/wpYnkFTSdQ/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "hoa-livem-83",
    subject: "hoa",
    title: "Khóa Live M: BUỔI SỐ 83 - BTRL PHỨC CHẤT",
    grade: 12,
    category: "imo-hoa",
    source: "Thầy Phạm Thắng - Hệ Thống Hóa Học IMO 2025",
    year: 2025,
    buoiHoc: "BUỔI SỐ 83",
    caLive: "",
    ngayLive: "12/12/2024",
    description: "Khóa học Live M Hóa Học 2025: BUỔI SỐ 83 - BTRL PHỨC CHẤT. Đầy đủ File Đề bản in, File Lời Giải Viết Tay chi tiết từng câu và Video livestream chữa bài.",
    link: "https://drive.google.com/file/d/1cWhoRDTvJwkI66Y-qWwd0cIrgA2Z10AC/view?usp=sharing",
    fileDe: "https://drive.google.com/file/d/1cWhoRDTvJwkI66Y-qWwd0cIrgA2Z10AC/view?usp=sharing",
    fileVietTay: "https://drive.google.com/file/d/1CcbYJaItthnhC_FG0tOWKOwWOdIy4agC/view?usp=sharing",
    video: "https://fb.watch/wvfp5oneMT/",
    tags: ["Hóa Học 12", "Live M", "Thầy Phạm Thắng", "Đề & Lời giải", "BUỔI SỐ 83"],
    downloads: 3907,
    featured: false,
    studyContent: {
        summary: "Buổi học BUỔI SỐ 83 (BTRL PHỨC CHẤT) thuộc Khóa Live M luyện thi THPT 2025. Hướng dẫn toàn diện phương pháp giải nhanh, sơ đồ tư duy và biện luận cấu trúc chất hữu cơ - vô cơ.",
        files: {
          fileDe: "https://drive.google.com/file/d/1cWhoRDTvJwkI66Y-qWwd0cIrgA2Z10AC/view?usp=sharing",
          fileVietTay: "https://drive.google.com/file/d/1CcbYJaItthnhC_FG0tOWKOwWOdIy4agC/view?usp=sharing",
          video: "https://fb.watch/wvfp5oneMT/"
        },
        keyFormulas: [
          "Cấu trúc đề Hóa 2025: Phần I (18 câu nhiều phương án - 4,5đ), Phần II (4 câu Đúng/Sai - 4,0đ), Phần III (6 câu Trả lời ngắn - 1,5đ).",
          "Thế điện cực chuẩn pin Galvani: $E^\\circ_{\\text{pin}} = E^\\circ_{\\text{cathode}} - E^\\circ_{\\text{anode}}$",
          "Khối lượng mol: Tripalmitin $M=806$, Tristearin $M=890$, Triolein $M=884$, Glucose $M=180$, Saccharose $M=342$."
        ],
        studyTips: [
          "Tải File Đề về làm trước khi đối chiếu với File Lời Giải Viết Tay để tối ưu hóa hiệu quả tiếp thu."
        ]
      }
  },
  {
    id: "ly-mapstudy-01",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 1 Thứ 3 - 03/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 1 Thứ 3 - 03/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 1 Thứ 3 - 03/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/hinta.ngocanh/videos/1140943778070053?idorvanity=624679967252956",
    fileDe: "https://www.facebook.com/hinta.ngocanh/videos/1140943778070053?idorvanity=624679967252956",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/633691979685088/",
    video: "https://www.facebook.com/hinta.ngocanh/videos/1140943778070053?idorvanity=624679967252956",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4328,
    featured: true,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 1 Thứ 3 - 03/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/hinta.ngocanh/videos/1140943778070053?idorvanity=624679967252956",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/633691979685088/",
          video: "https://www.facebook.com/hinta.ngocanh/videos/1140943778070053?idorvanity=624679967252956"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-02",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 1 Thứ 3 - 03/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 1 Thứ 3 - 03/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 1 Thứ 3 - 03/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/633702943017325/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/633702943017325/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/633702943017325/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4678,
    featured: true,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 1 Thứ 3 - 03/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/633702943017325/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/633702943017325/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-03",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 1 Thứ 3 - 03/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 1 Thứ 3 - 03/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 1 Thứ 3 - 03/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/633795439674742/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/633795439674742/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/633975752990044/",
    video: "https://www.facebook.com/groups/624679967252956/posts/633795439674742/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4623,
    featured: true,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 1 Thứ 3 - 03/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/633795439674742/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/633975752990044/",
          video: "https://www.facebook.com/groups/624679967252956/posts/633795439674742/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-04",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 1 Thứ 3 - 03/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 1 Thứ 3 - 03/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 1 Thứ 3 - 03/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/634059639648322/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/634059639648322/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/634223112965308/",
    video: "https://www.facebook.com/groups/624679967252956/posts/634059639648322/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4490,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 1 Thứ 3 - 03/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/634059639648322/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/634223112965308/",
          video: "https://www.facebook.com/groups/624679967252956/posts/634059639648322/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-05",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 2 Thứ 4 - 04/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 2 Thứ 4 - 04/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 2 Thứ 4 - 04/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/hinta.ngocanh/videos/1862948734550826?idorvanity=624679967252956",
    fileDe: "https://www.facebook.com/hinta.ngocanh/videos/1862948734550826?idorvanity=624679967252956",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/634719549582331/",
    video: "https://www.facebook.com/hinta.ngocanh/videos/1862948734550826?idorvanity=624679967252956",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4907,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 2 Thứ 4 - 04/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/hinta.ngocanh/videos/1862948734550826?idorvanity=624679967252956",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/634719549582331/",
          video: "https://www.facebook.com/hinta.ngocanh/videos/1862948734550826?idorvanity=624679967252956"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-06",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 2 Thứ 4 - 04/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 2 Thứ 4 - 04/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 2 Thứ 4 - 04/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/634722256248727/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/634722256248727/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/634722256248727/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4632,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 2 Thứ 4 - 04/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/634722256248727/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/634722256248727/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-07",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 2 Thứ 4 - 04/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 2 Thứ 4 - 04/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 2 Thứ 4 - 04/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/634824812905138/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/634824812905138/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/634954252892194/",
    video: "https://www.facebook.com/groups/624679967252956/posts/634824812905138/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4571,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 2 Thứ 4 - 04/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/634824812905138/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/634954252892194/",
          video: "https://www.facebook.com/groups/624679967252956/posts/634824812905138/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-08",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 2 Thứ 4 - 04/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 2 Thứ 4 - 04/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 2 Thứ 4 - 04/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/635045922883027/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/635045922883027/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/635153882872231/",
    video: "https://www.facebook.com/groups/624679967252956/posts/635045922883027/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4570,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 2 Thứ 4 - 04/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/635045922883027/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/635153882872231/",
          video: "https://www.facebook.com/groups/624679967252956/posts/635045922883027/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-09",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 3 Thứ 5 - 05/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 3 Thứ 5 - 05/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 3 Thứ 5 - 05/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/hinta.ngocanh/videos/634762816253967?idorvanity=624679967252956",
    fileDe: "https://www.facebook.com/hinta.ngocanh/videos/634762816253967?idorvanity=624679967252956",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/635634172824202/",
    video: "https://www.facebook.com/hinta.ngocanh/videos/634762816253967?idorvanity=624679967252956",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4464,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 3 Thứ 5 - 05/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/hinta.ngocanh/videos/634762816253967?idorvanity=624679967252956",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/635634172824202/",
          video: "https://www.facebook.com/hinta.ngocanh/videos/634762816253967?idorvanity=624679967252956"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-10",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 3 Thứ 5 - 05/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 3 Thứ 5 - 05/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 3 Thứ 5 - 05/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/635635532824066/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/635635532824066/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/635635532824066/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4770,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 3 Thứ 5 - 05/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/635635532824066/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/635635532824066/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-11",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 3 Thứ 5 - 05/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 3 Thứ 5 - 05/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 3 Thứ 5 - 05/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/635736666147286/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/635736666147286/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/635817346139218/",
    video: "https://www.facebook.com/groups/624679967252956/posts/635736666147286/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4475,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 3 Thứ 5 - 05/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/635736666147286/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/635817346139218/",
          video: "https://www.facebook.com/groups/624679967252956/posts/635736666147286/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-12",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 3 Thứ 5 - 05/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 3 Thứ 5 - 05/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 3 Thứ 5 - 05/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/635918316129121/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/635918316129121/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/?multi_permalinks=636016109452675&hoisted_section_header_type=recently_seen",
    video: "https://www.facebook.com/groups/624679967252956/posts/635918316129121/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4371,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 3 Thứ 5 - 05/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/635918316129121/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/?multi_permalinks=636016109452675&hoisted_section_header_type=recently_seen",
          video: "https://www.facebook.com/groups/624679967252956/posts/635918316129121/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-13",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 4 Thứ 6 - 06/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 4 Thứ 6 - 06/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 4 Thứ 6 - 06/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/636463976074555/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/636463976074555/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/636627042724915/",
    video: "https://www.facebook.com/groups/624679967252956/posts/636463976074555/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4826,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 4 Thứ 6 - 06/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/636463976074555/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/636627042724915/",
          video: "https://www.facebook.com/groups/624679967252956/posts/636463976074555/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-14",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 4 Thứ 6 - 06/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 4 Thứ 6 - 06/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 4 Thứ 6 - 06/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/636303056090647/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/636303056090647/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/636303056090647/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4230,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 4 Thứ 6 - 06/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/636303056090647/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/636303056090647/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-15",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 4 Thứ 6 - 06/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 4 Thứ 6 - 06/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 4 Thứ 6 - 06/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/636635656057387/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/636635656057387/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/636743069379979/",
    video: "https://www.facebook.com/groups/624679967252956/posts/636635656057387/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4236,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 4 Thứ 6 - 06/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/636635656057387/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/636743069379979/",
          video: "https://www.facebook.com/groups/624679967252956/posts/636635656057387/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-16",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 4 Thứ 6 - 06/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 4 Thứ 6 - 06/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 4 Thứ 6 - 06/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/636820406038912/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/636820406038912/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/637058722681747/",
    video: "https://www.facebook.com/groups/624679967252956/posts/636820406038912/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4384,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 4 Thứ 6 - 06/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/636820406038912/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/637058722681747/",
          video: "https://www.facebook.com/groups/624679967252956/posts/636820406038912/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-17",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 5 Thứ 7 - 07/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 5 Thứ 7 - 07/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 5 Thứ 7 - 07/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/637309042656715/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/637309042656715/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/637556625965290/",
    video: "https://www.facebook.com/groups/624679967252956/posts/637309042656715/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4911,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 5 Thứ 7 - 07/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/637309042656715/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/637556625965290/",
          video: "https://www.facebook.com/groups/624679967252956/posts/637309042656715/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-18",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 5 Thứ 7 - 07/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 5 Thứ 7 - 07/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 5 Thứ 7 - 07/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/637134556007497/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/637134556007497/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/637134556007497/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4544,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 5 Thứ 7 - 07/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/637134556007497/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/637134556007497/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-19",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 5 Thứ 7 - 07/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 5 Thứ 7 - 07/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 5 Thứ 7 - 07/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/637466089307677/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/637466089307677/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/637557412631878/",
    video: "https://www.facebook.com/groups/624679967252956/posts/637466089307677/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4988,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 5 Thứ 7 - 07/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/637466089307677/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/637557412631878/",
          video: "https://www.facebook.com/groups/624679967252956/posts/637466089307677/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-20",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 6 Thứ 2 - 09/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 6 Thứ 2 - 09/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 6 Thứ 2 - 09/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/638900152497604/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/638900152497604/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/638975695823383/",
    video: "https://www.facebook.com/groups/624679967252956/posts/638900152497604/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4450,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 6 Thứ 2 - 09/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/638900152497604/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/638975695823383/",
          video: "https://www.facebook.com/groups/624679967252956/posts/638900152497604/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-21",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 6 Thứ 2 - 09/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 6 Thứ 2 - 09/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 6 Thứ 2 - 09/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/639075552480064/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/639075552480064/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/639163192471300/",
    video: "https://www.facebook.com/groups/624679967252956/posts/639075552480064/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4457,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 6 Thứ 2 - 09/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/639075552480064/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/639163192471300/",
          video: "https://www.facebook.com/groups/624679967252956/posts/639075552480064/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-22",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 6 Thứ 2 - 09/06 - Ca 12h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 6 Thứ 2 - 09/06",
    caLive: "12h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 6 Thứ 2 - 09/06 - Ca 12h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/?multi_permalinks=639178452469774&hoisted_section_header_type=recently_seen",
    fileDe: "https://www.facebook.com/groups/624679967252956/?multi_permalinks=639178452469774&hoisted_section_header_type=recently_seen",
    fileVietTay: "",
    video: "",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 12h00"],
    downloads: 4794,
    featured: false,
    studyContent: {
        summary: "Ca học 12h00 (Ngày 6 Thứ 2 - 09/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/?multi_permalinks=639178452469774&hoisted_section_header_type=recently_seen",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-23",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 6 Thứ 2 - 09/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 6 Thứ 2 - 09/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 6 Thứ 2 - 09/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/639254509128835/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/639254509128835/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/639335719120714/",
    video: "https://www.facebook.com/groups/624679967252956/posts/639254509128835/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4212,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 6 Thứ 2 - 09/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/639254509128835/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/639335719120714/",
          video: "https://www.facebook.com/groups/624679967252956/posts/639254509128835/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-24",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 6 Thứ 2 - 09/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 6 Thứ 2 - 09/06",
    caLive: "20h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 6 Thứ 2 - 09/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/639466295774323/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/639466295774323/",
    fileVietTay: "https://drive.google.com/file/d/1bju_uUO5LaDVlCT_cV8HiuU6H-mKqnom/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/639466295774323/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 20h00"],
    downloads: 4470,
    featured: false,
    studyContent: {
        summary: "Ca học 20h00 (Ngày 6 Thứ 2 - 09/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/639466295774323/",
          fileVietTay: "https://drive.google.com/file/d/1bju_uUO5LaDVlCT_cV8HiuU6H-mKqnom/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/639466295774323/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-25",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 7 Thứ 3 - 10/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 7 Thứ 3 - 10/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 7 Thứ 3 - 10/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/hinta.ngocanh/videos/2119267711923513?idorvanity=624679967252956",
    fileDe: "https://www.facebook.com/hinta.ngocanh/videos/2119267711923513?idorvanity=624679967252956",
    fileVietTay: "https://drive.google.com/file/d/1gSKUYrMmyIQjvjDC1tPikZk_wtMI9MOy/view?usp=sharing",
    video: "https://www.facebook.com/hinta.ngocanh/videos/2119267711923513?idorvanity=624679967252956",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4960,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 7 Thứ 3 - 10/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/hinta.ngocanh/videos/2119267711923513?idorvanity=624679967252956",
          fileVietTay: "https://drive.google.com/file/d/1gSKUYrMmyIQjvjDC1tPikZk_wtMI9MOy/view?usp=sharing",
          video: "https://www.facebook.com/hinta.ngocanh/videos/2119267711923513?idorvanity=624679967252956"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-26",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 7 Thứ 3 - 10/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 7 Thứ 3 - 10/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 7 Thứ 3 - 10/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/639865122401107/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/639865122401107/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/639865122401107/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4529,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 7 Thứ 3 - 10/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/639865122401107/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/639865122401107/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-27",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 7 Thứ 3 - 10/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 7 Thứ 3 - 10/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 7 Thứ 3 - 10/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/639972895723663/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/639972895723663/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/640036805717272/",
    video: "https://www.facebook.com/groups/624679967252956/posts/639972895723663/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4619,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 7 Thứ 3 - 10/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/639972895723663/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/640036805717272/",
          video: "https://www.facebook.com/groups/624679967252956/posts/639972895723663/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-28",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 7 Thứ 3 - 10/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 7 Thứ 3 - 10/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 7 Thứ 3 - 10/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/640141699040116/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/640141699040116/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/640235489030737/",
    video: "https://www.facebook.com/groups/624679967252956/posts/640141699040116/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4639,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 7 Thứ 3 - 10/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/640141699040116/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/640235489030737/",
          video: "https://www.facebook.com/groups/624679967252956/posts/640141699040116/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-29",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 8 Thứ 4 - 11/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 8 Thứ 4 - 11/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 8 Thứ 4 - 11/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/640642428990043/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/640642428990043/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/640790815641871/",
    video: "https://www.facebook.com/groups/624679967252956/posts/640642428990043/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4290,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 8 Thứ 4 - 11/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/640642428990043/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/640790815641871/",
          video: "https://www.facebook.com/groups/624679967252956/posts/640642428990043/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-30",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 8 Thứ 4 - 11/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 8 Thứ 4 - 11/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 8 Thứ 4 - 11/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/640457112341908/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/640457112341908/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/640457112341908/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4923,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 8 Thứ 4 - 11/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/640457112341908/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/640457112341908/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-31",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 8 Thứ 4 - 11/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 8 Thứ 4 - 11/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 8 Thứ 4 - 11/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/640805888973697/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/640805888973697/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/640853625635590/",
    video: "https://www.facebook.com/groups/624679967252956/posts/640805888973697/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4444,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 8 Thứ 4 - 11/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/640805888973697/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/640853625635590/",
          video: "https://www.facebook.com/groups/624679967252956/posts/640805888973697/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-32",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 8 Thứ 4 - 11/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 8 Thứ 4 - 11/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 8 Thứ 4 - 11/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/640964588957827/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/640964588957827/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/641069465614006/",
    video: "https://www.facebook.com/groups/624679967252956/posts/640964588957827/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4357,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 8 Thứ 4 - 11/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/640964588957827/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/641069465614006/",
          video: "https://www.facebook.com/groups/624679967252956/posts/640964588957827/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-33",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 9 Thứ 5 - 12/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 9 Thứ 5 - 12/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 9 Thứ 5 - 12/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/641442692243350/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/641442692243350/",
    fileVietTay: "https://drive.google.com/file/d/1hjToyaJjk01KlkkEOT3f3vDINlgmNX34/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/641442692243350/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4972,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 9 Thứ 5 - 12/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/641442692243350/",
          fileVietTay: "https://drive.google.com/file/d/1hjToyaJjk01KlkkEOT3f3vDINlgmNX34/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/641442692243350/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-34",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 9 Thứ 5 - 12/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 9 Thứ 5 - 12/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 9 Thứ 5 - 12/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/641496625571290/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/641496625571290/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/641496625571290/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4564,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 9 Thứ 5 - 12/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/641496625571290/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/641496625571290/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-35",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 9 Thứ 5 - 12/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 9 Thứ 5 - 12/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 9 Thứ 5 - 12/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/641597992227820/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/641597992227820/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/641648295556123/",
    video: "https://www.facebook.com/groups/624679967252956/posts/641597992227820/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4776,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 9 Thứ 5 - 12/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/641597992227820/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/641648295556123/",
          video: "https://www.facebook.com/groups/624679967252956/posts/641597992227820/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-36",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 9 Thứ 5 - 12/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 9 Thứ 5 - 12/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 9 Thứ 5 - 12/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/641761215544831/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/641761215544831/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/641857422201877/",
    video: "https://www.facebook.com/groups/624679967252956/posts/641761215544831/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4347,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 9 Thứ 5 - 12/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/641761215544831/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/641857422201877/",
          video: "https://www.facebook.com/groups/624679967252956/posts/641761215544831/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-37",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 10 Thứ 6 - 13/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 10 Thứ 6 - 13/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 10 Thứ 6 - 13/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/642250392162580/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/642250392162580/",
    fileVietTay: "https://drive.google.com/file/d/1kC9VAQOtPv2qIYL6XiHTb-ERvDK8HTn9/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/642250392162580/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4442,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 10 Thứ 6 - 13/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/642250392162580/",
          fileVietTay: "https://drive.google.com/file/d/1kC9VAQOtPv2qIYL6XiHTb-ERvDK8HTn9/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/642250392162580/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-38",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 10 Thứ 6 - 13/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 10 Thứ 6 - 13/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 10 Thứ 6 - 13/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/642391328815153/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/642391328815153/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/642391328815153/",
    video: "https://www.facebook.com/groups/624679967252956/posts/642391328815153/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4663,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 10 Thứ 6 - 13/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/642391328815153/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/642391328815153/",
          video: "https://www.facebook.com/groups/624679967252956/posts/642391328815153/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-39",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 10 Thứ 6 - 13/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 10 Thứ 6 - 13/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 10 Thứ 6 - 13/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/642400648814221/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/642400648814221/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/642443898809896/",
    video: "https://www.facebook.com/groups/624679967252956/posts/642400648814221/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4496,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 10 Thứ 6 - 13/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/642400648814221/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/642443898809896/",
          video: "https://www.facebook.com/groups/624679967252956/posts/642400648814221/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-40",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 10 Thứ 6 - 13/06 - Ca 12h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 10 Thứ 6 - 13/06",
    caLive: "12h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 10 Thứ 6 - 13/06 - Ca 12h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/permalink/642468998807386",
    fileDe: "https://www.facebook.com/groups/624679967252956/permalink/642468998807386",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/642468998807386/",
    video: "",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 12h00"],
    downloads: 4658,
    featured: false,
    studyContent: {
        summary: "Ca học 12h00 (Ngày 10 Thứ 6 - 13/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/permalink/642468998807386",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/642468998807386/",
          video: ""
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-41",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 10 Thứ 6 - 13/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 10 Thứ 6 - 13/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 10 Thứ 6 - 13/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/642555822132037/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/642555822132037/",
    fileVietTay: "https://drive.google.com/file/d/1zyLNxSEbGuJ2gCb3B1-F_FiljeL7xXKR/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/642555822132037/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4294,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 10 Thứ 6 - 13/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/642555822132037/",
          fileVietTay: "https://drive.google.com/file/d/1zyLNxSEbGuJ2gCb3B1-F_FiljeL7xXKR/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/642555822132037/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-42",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 10 Thứ 6 - 13/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 10 Thứ 6 - 13/06",
    caLive: "20h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 10 Thứ 6 - 13/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/642752405445712/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/642752405445712/",
    fileVietTay: "https://drive.google.com/file/d/1-NIaesRPwyxf2K6l06NUDrzrYE13sXQe/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/642752405445712/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 20h00"],
    downloads: 4745,
    featured: false,
    studyContent: {
        summary: "Ca học 20h00 (Ngày 10 Thứ 6 - 13/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/642752405445712/",
          fileVietTay: "https://drive.google.com/file/d/1-NIaesRPwyxf2K6l06NUDrzrYE13sXQe/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/642752405445712/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-43",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 11 Thứ 7 - 14/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 11 Thứ 7 - 14/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 11 Thứ 7 - 14/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/643065398747746/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/643065398747746/",
    fileVietTay: "https://drive.google.com/file/d/1rc3eu7gqhE-hV3bvoVE6RVTRkrJ9vQ83/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/643065398747746/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4991,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 11 Thứ 7 - 14/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/643065398747746/",
          fileVietTay: "https://drive.google.com/file/d/1rc3eu7gqhE-hV3bvoVE6RVTRkrJ9vQ83/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/643065398747746/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-44",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 11 Thứ 7 - 14/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 11 Thứ 7 - 14/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 11 Thứ 7 - 14/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/642871128767173/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/642871128767173/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/642871128767173/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4448,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 11 Thứ 7 - 14/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/642871128767173/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/642871128767173/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-45",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 11 Thứ 7 - 14/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 11 Thứ 7 - 14/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 11 Thứ 7 - 14/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/643212282066391/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/643212282066391/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/643276948726591/",
    video: "https://www.facebook.com/groups/624679967252956/posts/643212282066391/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4691,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 11 Thứ 7 - 14/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/643212282066391/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/643276948726591/",
          video: "https://www.facebook.com/groups/624679967252956/posts/643212282066391/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-46",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 11 Thứ 7 - 14/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 11 Thứ 7 - 14/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 11 Thứ 7 - 14/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/643374682050151/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/643374682050151/",
    fileVietTay: "https://drive.google.com/file/d/10pPX_s9C3jIPiXjAVYE8Zk0Yh2jxPAeT/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/643374682050151/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4866,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 11 Thứ 7 - 14/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/643374682050151/",
          fileVietTay: "https://drive.google.com/file/d/10pPX_s9C3jIPiXjAVYE8Zk0Yh2jxPAeT/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/643374682050151/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-47",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 12 Thứ 2 - 16/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 12 Thứ 2 - 16/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 12 Thứ 2 - 16/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
    fileVietTay: "https://drive.google.com/file/d/1exNWSiHJbGcyArW6w_Ow8eST8MxPE8eq/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4645,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 12 Thứ 2 - 16/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
          fileVietTay: "https://drive.google.com/file/d/1exNWSiHJbGcyArW6w_Ow8eST8MxPE8eq/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-48",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 12 Thứ 2 - 16/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 12 Thứ 2 - 16/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 12 Thứ 2 - 16/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/permalink/644769675243985",
    fileDe: "https://www.facebook.com/groups/624679967252956/permalink/644769675243985",
    fileVietTay: "",
    video: "",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4397,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 12 Thứ 2 - 16/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/permalink/644769675243985",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-49",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 12 Thứ 2 - 16/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 12 Thứ 2 - 16/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 12 Thứ 2 - 16/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/644782611909358/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/644782611909358/",
    fileVietTay: "https://drive.google.com/file/d/1Y3avF4RDHFzfXFrq55QRsend9rYX7dqB/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/644782611909358/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4674,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 12 Thứ 2 - 16/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/644782611909358/",
          fileVietTay: "https://drive.google.com/file/d/1Y3avF4RDHFzfXFrq55QRsend9rYX7dqB/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/644782611909358/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-50",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 12 Thứ 2 - 16/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 12 Thứ 2 - 16/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 12 Thứ 2 - 16/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/644931471894472/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/644931471894472/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/645046861882933/",
    video: "https://www.facebook.com/groups/624679967252956/posts/644931471894472/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4568,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 12 Thứ 2 - 16/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/644931471894472/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/645046861882933/",
          video: "https://www.facebook.com/groups/624679967252956/posts/644931471894472/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-51",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 13 Thứ 3 - 17/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 13 Thứ 3 - 17/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 13 Thứ 3 - 17/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
    fileVietTay: "https://drive.google.com/file/d/1exNWSiHJbGcyArW6w_Ow8eST8MxPE8eq/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4984,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 13 Thứ 3 - 17/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
          fileVietTay: "https://drive.google.com/file/d/1exNWSiHJbGcyArW6w_Ow8eST8MxPE8eq/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-52",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 13 Thứ 3 - 17/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 13 Thứ 3 - 17/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 13 Thứ 3 - 17/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/permalink/645553161832303",
    fileDe: "https://www.facebook.com/groups/624679967252956/permalink/645553161832303",
    fileVietTay: "",
    video: "",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4247,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 13 Thứ 3 - 17/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/permalink/645553161832303",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-53",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 13 Thứ 3 - 17/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 13 Thứ 3 - 17/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 13 Thứ 3 - 17/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/645590448495241/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/645590448495241/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/645632518491034/",
    video: "https://www.facebook.com/groups/624679967252956/posts/645590448495241/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4810,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 13 Thứ 3 - 17/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/645590448495241/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/645632518491034/",
          video: "https://www.facebook.com/groups/624679967252956/posts/645590448495241/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-54",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 13 Thứ 3 - 17/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 13 Thứ 3 - 17/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 13 Thứ 3 - 17/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/645743901813229/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/645743901813229/",
    fileVietTay: "https://drive.google.com/file/d/1dAUOiTi0IxagXRvpmqaN6IxZrvOxApNA/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/645743901813229/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4241,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 13 Thứ 3 - 17/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/645743901813229/",
          fileVietTay: "https://drive.google.com/file/d/1dAUOiTi0IxagXRvpmqaN6IxZrvOxApNA/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/645743901813229/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-55",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 13 Thứ 3 - 17/06 - Ca 17h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 13 Thứ 3 - 17/06",
    caLive: "17h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 13 Thứ 3 - 17/06 - Ca 17h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/645824121805207/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/645824121805207/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/645824121805207/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 17h00"],
    downloads: 4880,
    featured: false,
    studyContent: {
        summary: "Ca học 17h00 (Ngày 13 Thứ 3 - 17/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/645824121805207/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/645824121805207/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-56",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 13 Thứ 3 - 17/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 13 Thứ 3 - 17/06",
    caLive: "20h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 13 Thứ 3 - 17/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/645927445128208/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/645927445128208/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/645927445128208/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 20h00"],
    downloads: 4740,
    featured: false,
    studyContent: {
        summary: "Ca học 20h00 (Ngày 13 Thứ 3 - 17/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/645927445128208/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/645927445128208/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-57",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 14 Thứ 4 - 18/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 14 Thứ 4 - 18/06",
    caLive: "5h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 14 Thứ 4 - 18/06 - Ca 5h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
    fileVietTay: "https://drive.google.com/file/d/1exNWSiHJbGcyArW6w_Ow8eST8MxPE8eq/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 5h00"],
    downloads: 4760,
    featured: false,
    studyContent: {
        summary: "Ca học 5h00 (Ngày 14 Thứ 4 - 18/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/",
          fileVietTay: "https://drive.google.com/file/d/1exNWSiHJbGcyArW6w_Ow8eST8MxPE8eq/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/645150515205901/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-58",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 14 Thứ 4 - 18/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 14 Thứ 4 - 18/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 14 Thứ 4 - 18/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/646056198448666/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/646056198448666/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/646056198448666/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4398,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 14 Thứ 4 - 18/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/646056198448666/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/646056198448666/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-59",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 14 Thứ 4 - 18/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 14 Thứ 4 - 18/06",
    caLive: "10h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 14 Thứ 4 - 18/06 - Ca 10h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/646347215086231/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/646347215086231/",
    fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/646440021743617/",
    video: "https://www.facebook.com/groups/624679967252956/posts/646347215086231/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 10h00"],
    downloads: 4961,
    featured: false,
    studyContent: {
        summary: "Ca học 10h00 (Ngày 14 Thứ 4 - 18/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/646347215086231/",
          fileVietTay: "https://www.facebook.com/groups/624679967252956/posts/646440021743617/",
          video: "https://www.facebook.com/groups/624679967252956/posts/646347215086231/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-60",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 14 Thứ 4 - 18/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 14 Thứ 4 - 18/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 14 Thứ 4 - 18/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/646539885066964/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/646539885066964/",
    fileVietTay: "https://drive.google.com/file/d/12mYr6tX-BL-2zrmoPo208LyhAE3rVJtl/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/646539885066964/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4652,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 14 Thứ 4 - 18/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/646539885066964/",
          fileVietTay: "https://drive.google.com/file/d/12mYr6tX-BL-2zrmoPo208LyhAE3rVJtl/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/646539885066964/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-61",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 15 Thứ 5 - 19/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 15 Thứ 5 - 19/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 15 Thứ 5 - 19/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/646889325032020/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/646889325032020/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/646889325032020/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4952,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 15 Thứ 5 - 19/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/646889325032020/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/646889325032020/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-62",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 15 Thứ 5 - 19/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 15 Thứ 5 - 19/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 15 Thứ 5 - 19/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/647290884991864/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/647290884991864/",
    fileVietTay: "https://drive.google.com/file/d/1RUs_0K-LZquy5D3tiRaPdmcaevlGAcGY/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/647290884991864/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4578,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 15 Thứ 5 - 19/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/647290884991864/",
          fileVietTay: "https://drive.google.com/file/d/1RUs_0K-LZquy5D3tiRaPdmcaevlGAcGY/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/647290884991864/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-63",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 16 Thứ 6 - 20/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 16 Thứ 6 - 20/06",
    caLive: "7h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 16 Thứ 6 - 20/06 - Ca 7h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/648085841579035/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/648085841579035/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/648085841579035/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 7h00"],
    downloads: 4344,
    featured: false,
    studyContent: {
        summary: "Ca học 7h00 (Ngày 16 Thứ 6 - 20/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/648085841579035/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/648085841579035/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-64",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 16 Thứ 6 - 20/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 16 Thứ 6 - 20/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 16 Thứ 6 - 20/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/648170991570520/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/648170991570520/",
    fileVietTay: "https://drive.google.com/file/d/1wNGQdqW8c3AXh6qEE5WC96JcwuQpatqd/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/648170991570520/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4585,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 16 Thứ 6 - 20/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/648170991570520/",
          fileVietTay: "https://drive.google.com/file/d/1wNGQdqW8c3AXh6qEE5WC96JcwuQpatqd/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/648170991570520/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-65",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 16 Thứ 6 - 20/06 - Ca 17h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 16 Thứ 6 - 20/06",
    caLive: "17h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 16 Thứ 6 - 20/06 - Ca 17h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/648201264900826/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/648201264900826/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/648201264900826/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 17h00"],
    downloads: 4737,
    featured: false,
    studyContent: {
        summary: "Ca học 17h00 (Ngày 16 Thứ 6 - 20/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/648201264900826/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/648201264900826/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-66",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 16 Thứ 6 - 20/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 16 Thứ 6 - 20/06",
    caLive: "20h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 16 Thứ 6 - 20/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/648465401541079/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/648465401541079/",
    fileVietTay: "https://drive.google.com/file/d/1ZGUw8M_yDOJZ22OfduoJbGyy7ASkXCzW/view?usp=sharing",
    video: "https://www.facebook.com/groups/624679967252956/posts/648465401541079/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 20h00"],
    downloads: 4980,
    featured: false,
    studyContent: {
        summary: "Ca học 20h00 (Ngày 16 Thứ 6 - 20/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/648465401541079/",
          fileVietTay: "https://drive.google.com/file/d/1ZGUw8M_yDOJZ22OfduoJbGyy7ASkXCzW/view?usp=sharing",
          video: "https://www.facebook.com/groups/624679967252956/posts/648465401541079/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-67",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 17 Thứ 2 - 23/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 17 Thứ 2 - 23/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 17 Thứ 2 - 23/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/652216791165940/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/652216791165940/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/652216791165940/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4903,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 17 Thứ 2 - 23/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/652216791165940/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/652216791165940/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-68",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 18 Thứ 3 - 24/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 18 Thứ 3 - 24/06",
    caLive: "15h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 18 Thứ 3 - 24/06 - Ca 15h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/groups/624679967252956/posts/653131334407819/",
    fileDe: "https://www.facebook.com/groups/624679967252956/posts/653131334407819/",
    fileVietTay: "",
    video: "https://www.facebook.com/groups/624679967252956/posts/653131334407819/",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 15h00"],
    downloads: 4554,
    featured: false,
    studyContent: {
        summary: "Ca học 15h00 (Ngày 18 Thứ 3 - 24/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/groups/624679967252956/posts/653131334407819/",
          fileVietTay: "",
          video: "https://www.facebook.com/groups/624679967252956/posts/653131334407819/"
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "ly-mapstudy-69",
    subject: "ly",
    title: "Khóa 14 Ngày Tổng Ôn: Ngày 18 Thứ 3 - 24/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy)",
    grade: 12,
    category: "ve-dich-ly",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Ngày 18 Thứ 3 - 24/06",
    caLive: "20h00",
    ngayLive: "",
    description: "Khóa Tổng Ôn Cấp Tốc 14 Ngày Vật Lí 2K7 - Mapstudy: Ngày 18 Thứ 3 - 24/06 - Ca 20h00 (Tổng Ôn Cấp Tốc 14 Ngày - Thầy VNA Mapstudy). Tài liệu ôn thi, PDF đề thi, bản viết tay và video bài giảng livestream.",
    link: "https://www.facebook.com/watch/live/?ref=watch_permalink&v=1078042750944631",
    fileDe: "https://www.facebook.com/watch/live/?ref=watch_permalink&v=1078042750944631",
    fileVietTay: "https://drive.google.com/file/d/10LbHIBQiWQaKjHjgIOJMCKIXI7tRxJAB/view?usp=sharing",
    video: "",
    tags: ["Vật Lí 12", "Mapstudy", "Vũ Ngọc Anh", "14 Ngày Tổng Ôn", "Ca 20h00"],
    downloads: 4286,
    featured: false,
    studyContent: {
        summary: "Ca học 20h00 (Ngày 18 Thứ 3 - 24/06) trong chuỗi 14 Ngày Về Đích Cấp Tốc Vật Lí Mapstudy. Luyện phản xạ lý thuyết và kỹ thuật xử lý bài toán vận dụng cao.",
        files: {
          fileDe: "https://www.facebook.com/watch/live/?ref=watch_permalink&v=1078042750944631",
          fileVietTay: "https://drive.google.com/file/d/10LbHIBQiWQaKjHjgIOJMCKIXI7tRxJAB/view?usp=sharing",
          video: ""
        },
        keyFormulas: [
          "Vật lý nhiệt: $Q = mc\\Delta T$, $Q = mL$, $Q = m\\lambda$.",
          "Phương trình khí lý tưởng: $pV = nRT = \\frac{m}{\\mu}RT$ (với $R = 8.31 \\text{ J/(mol}\\cdot\\text{K)}$).",
          "Từ trường cảm ứng: $\\Phi = BS\\cos\\alpha$, $e_c = -\\frac{\\Delta \\Phi}{\\Delta t}$."
        ],
        studyTips: [
          "Luôn chú ý đổi đơn vị nhiệt độ sang Kelvin ($T = t + 273.15$) và áp suất sang Pascal ($1 \\text{ atm} = 1.013 \\times 10^5 \\text{ Pa}$)."
        ]
      }
  },
  {
    id: "toan-10-01",
    subject: "toan",
    title: "Tổng Ôn Chuyên Đề: Mệnh Đề, Tập Hợp & Bất Phương Trình Bậc Nhất Hai Ẩn",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Tổ Toán THPT Chuyên Sư Phạm & SGK Kết Nối Tri Thức",
    year: 2025,
    buoiHoc: "Chuyên đề 01",
    caLive: "",
    ngayLive: "",
    description: "Hệ thống toàn bộ kiến thức nền tảng lớp 10: Phép toán tập hợp (giao, hợp, hiệu), miền nghiệm bất phương trình và bài toán tối ưu hóa thực tế quy hoạch tuyến tính.",
    link: "https://toanmath.com/tai-lieu-toan-10",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 10", "Mệnh đề", "Tập hợp", "Quy hoạch tuyến tính", "Lý thuyết & Bài tập"],
    downloads: 14200,
    featured: true,
    studyContent: {
        summary: "Kiến thức mở đầu quan trọng của chương trình GDPT 2018. Rèn luyện tư duy logic mệnh đề và kỹ năng biểu diễn miền nghiệm của hệ bất phương trình bậc nhất hai ẩn để giải bài toán tối ưu chi phí, lợi nhuận.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Giao của hai tập hợp: A \\cap B = \\{x \\mid x \\in A \\text{ và } x \\in B\\}",
          "Hợp của hai tập hợp: A \\cup B = \\{x \\mid x \\in A \\text{ hoặc } x \\in B\\}",
          "Hiệu của hai tập hợp: A \\setminus B = \\{x \\mid x \\in A \\text{ và } x \\notin B\\}",
          "Công thức số phần tử: n(A \\cup B) = n(A) + n(B) - n(A \\cap B)",
          "Biểu thức tối ưu: F(x, y) = c_1 x + c_2 y đạt cực đại/cực tiểu tại đỉnh đa giác miền nghiệm."
        ],
        studyTips: [
          "1. Luôn vẽ đường thẳng bờ ax + by = c chính xác bằng cách lấy 2 điểm cắt trục Ox, Oy.",
          "2. Thử điểm O(0; 0) để xác định nửa mặt phẳng nghiệm nhanh chóng.",
          "3. Với bài toán lời văn thực tế (lập kế hoạch sản xuất), ghi rõ điều kiện x \\ge 0, y \\ge 0."
        ],
        theory: [
          { title: "Mệnh đề toán học & Mệnh đề chứa biến", points: ["Mệnh đề là một câu khẳng định đúng hoặc khẳng định sai. Một mệnh đề không thể vừa đúng vừa sai.", "Mệnh đề phủ định của P ký hiệu là \\bar{P}. Nếu P đúng thì \\bar{P} sai và ngược lại.", "Phủ định của mệnh đề chứa 'với mọi': Phủ định của \\forall x \\in X, P(x) là \\exists x \\in X, \\bar{P}(x).", "Phủ định của mệnh đề chứa 'tồn tại': Phủ định của \\exists x \\in X, P(x) là \\forall x \\in X, \\bar{P}(x)."] },
          { title: "Hệ bất phương trình bậc nhất hai ẩn & Quy hoạch tuyến tính", points: ["Bất phương trình bậc nhất hai ẩn có dạng ax + by \\le c (hoặc <, \\ge, >). Miền nghiệm là một nửa mặt phẳng kể cả bờ ax + by = c.", "Miền nghiệm của hệ bất phương trình là giao các miền nghiệm của từng bất phương trình trong hệ.", "Định lý giá trị cực trị: Giá trị lớn nhất hoặc nhỏ nhất của biểu thức F(x; y) = ax + by trên miền đa giác lồi luôn đạt tại một trong các đỉnh của miền đa giác đó."] }
        ],
        examples: [
          { q: "Một xưởng sản xuất 2 loại sản phẩm A và B. Mỗi tấn loại A cần 2 giờ máy và đem lại 3 triệu đồng tiền lãi. Mỗi tấn loại B cần 1 giờ máy và đem lại 2 triệu đồng tiền lãi. Máy hoạt động tối đa 8 giờ mỗi ngày. Tìm số tấn mỗi loại để tiền lãi lớn nhất.", a: "Gọi x, y lần lượt là số tấn sản phẩm A và B sản xuất mỗi ngày (x, y \\ge 0).\\nTheo đề bài, thời gian máy sử dụng: 2x + y \\le 8.\\nLợi nhuận: F(x, y) = 3x + 2y (triệu đồng).\\nMiền nghiệm là tam giác OAB với O(0,0), A(4,0), B(0,8).\\nTính giá trị tại các đỉnh:\\nF(0,0) = 0;\\nF(4,0) = 3(4) + 0 = 12;\\nF(0,8) = 0 + 2(8) = 16 triệu đồng.\\nVậy xưởng cần sản xuất 0 tấn A và 8 tấn B để đạt lãi tối đa 16 triệu đồng/ngày." }
        ]
      }
  },
  {
    id: "toan-10-02",
    subject: "toan",
    title: "Chuyên Đề Hệ Thức Lượng Trong Tam Giác & Vectơ Trong Mặt Phẳng Tọa Độ",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Thầy Đỗ Văn Đức & Nhóm Toán THPT Chuyên",
    year: 2025,
    buoiHoc: "Chuyên đề 02",
    caLive: "",
    ngayLive: "",
    description: "Tổng hợp công thức định lý sin, cosin, công thức tính diện tích tam giác (Heron, bán kính đường tròn nội/ngoại tiếp) và tích vô hướng của hai vectơ.",
    link: "https://toanmath.com/he-thuc-luong-tam-giac",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 10", "Hệ thức lượng", "Định lý cosin", "Định lý sin", "Vectơ", "Tích vô hướng"],
    downloads: 16800,
    featured: true,
    studyContent: {
        summary: "Chuyên đề xuất hiện thường xuyên trong câu hỏi trắc nghiệm thực tế: đo chiều cao ngọn hải đăng, khoảng cách giữa 2 con tàu, tính công của lực trong Vật lí bằng tích vô hướng.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Định lý Cosin: a^2 = b^2 + c^2 - 2bc \\cos A \\Rightarrow \\cos A = \\frac{b^2 + c^2 - a^2}{2bc}",
          "Định lý Sin: \\frac{a}{\\sin A} = \\frac{b}{\\sin B} = \\frac{c}{\\sin C} = 2R",
          "Diện tích tam giác: S = \\frac{1}{2}ab \\sin C = \\frac{abc}{4R} = pr = \\sqrt{p(p-a)(p-b)(p-c)}",
          "Tích vô hướng theo tọa độ: \\vec{u} \\cdot \\vec{v} = x_1 x_2 + y_1 y_2",
          "Độ dài vectơ: |\\vec{u}| = \\sqrt{x_1^2 + y_1^2}; \\cos(\\vec{u}, \\vec{v}) = \\frac{x_1 x_2 + y_1 y_2}{\\sqrt{x_1^2 + y_1^2} \\sqrt{x_2^2 + y_2^2}}"
        ],
        studyTips: [
          "1. Dùng Định lý Cosin khi biết 2 cạnh 1 góc xen giữa hoặc biết cả 3 cạnh.",
          "2. Dùng Định lý Sin khi biết 1 cạnh và 2 góc kề, hoặc muốn tìm bán kính ngoại tiếp R.",
          "3. Sử dụng công thức Heron khi độ dài 3 cạnh là các số nguyên đẹp."
        ],
        theory: [
          { title: "Định lý Cosin & Định lý Sin trong tam giác", points: ["Định lý côsin giúp tính cạnh thứ 3 khi biết 2 cạnh và góc xen giữa, hoặc tính góc khi biết 3 cạnh.", "Định lý sin liên hệ độ dài cạnh đối diện với sin của góc và bán kính đường tròn ngoại tiếp R.", "Công thức trung tuyến: m_a^2 = \\frac{2(b^2 + c^2) - a^2}{4}."] },
          { title: "Tích vô hướng của hai vectơ", points: ["Tích vô hướng: \\vec{u} \\cdot \\vec{v} = |\\vec{u}| \\cdot |\\vec{v}| \\cdot \\cos(\\vec{u}, \\vec{v}).", "Hai vectơ vuông góc khi và chỉ khi tích vô hướng bằng 0: \\vec{u} \\perp \\vec{v} \\Leftrightarrow \\vec{u} \\cdot \\vec{v} = 0.", "Tọa độ: Với \\vec{u} = (x_1; y_1), \\vec{v} = (x_2; y_2) thì \\vec{u} \\cdot \\vec{v} = x_1 x_2 + y_1 y_2."] }
        ],
        examples: [
          { q: "Tam giác ABC có a = 7, b = 8, c = 5. Tính góc A và diện tích tam giác ABC.", a: "Áp dụng định lý côsin:\\n\\cos A = \\frac{b^2 + c^2 - a^2}{2bc} = \\frac{8^2 + 5^2 - 7^2}{2 \\cdot 8 \\cdot 5} = \\frac{64 + 25 - 49}{80} = \\frac{40}{80} = \\frac{1}{2}.\\nSuy ra góc A = 60^\\circ.\\nDiện tích tam giác: S = \\frac{1}{2} b c \\sin A = \\frac{1}{2} \\cdot 8 \\cdot 5 \\cdot \\sin 60^\\circ = 20 \\cdot \\frac{\\sqrt{3}}{2} = 10\\sqrt{3}." }
        ]
      }
  },
  {
    id: "toan-10-03",
    subject: "toan",
    title: "Đại Số Tổ Hợp & Nhị Thức Newton Ứng Dụng Trong Bài Toán Xác Suất",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Khoa Toán - ĐH Sư Phạm Hà Nội",
    year: 2025,
    buoiHoc: "Chuyên đề 03",
    caLive: "",
    ngayLive: "",
    description: "Quy tắc cộng, quy tắc nhân, sơ đồ cây, hoán vị, chỉnh hợp, tổ hợp và công thức khai triển nhị thức Newton cho số mũ n = 4, 5.",
    link: "https://toanmath.com/to-hop-xac-suat-10",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 10", "Quy tắc cộng", "Quy tắc nhân", "Chỉnh hợp", "Tổ hợp", "Nhị thức Newton"],
    downloads: 15300,
    featured: false,
    studyContent: {
        summary: "Nền tảng của toàn bộ phần xác suất 10, 11 và đề thi THPT 2025. Phân biệt rõ ràng khi nào chọn có thứ tự (chỉnh hợp) và khi nào chọn không thứ tự (tổ hợp).",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Hoán vị: P_n = n! = n(n-1)...1",
          "Chỉnh hợp: A_n^k = \\frac{n!}{(n-k)!}",
          "Tổ hợp: C_n^k = \\frac{n!}{k!(n-k)!}",
          "Tính chất tổ hợp: C_n^k = C_n^{n-k}; C_n^{k-1} + C_n^k = C_{n+1}^k",
          "Khai triển Nhị thức Newton: (a + b)^4 = a^4 + 4a^3b + 6a^2b^2 + 4ab^3 + b^4",
          "Khai triển: (a + b)^5 = a^5 + 5a^4b + 10a^3b^2 + 10a^2b^3 + 5ab^4 + b^5"
        ],
        studyTips: [
          "1. Nếu bài toán có sắp xếp vị trí (hàng dọc, ghế ngồi, chức vụ Trưởng/Phó) \\rightarrow dùng Chỉnh hợp A_n^k.",
          "2. Nếu bài toán chỉ lấy ra một nhóm người/vật mà không phân vai trò \\rightarrow dùng Tổ hợp C_n^k.",
          "3. Bài toán 'có ít nhất một' nên làm theo biến cố đối (lấy tổng trừ đi trường hợp không có cái nào)."
        ],
        theory: [
          { title: "Quy tắc đếm cơ bản", points: ["Quy tắc cộng: Một công việc thực hiện theo một trong hai phương án loại trừ nhau (phương án 1 có m cách, phương án 2 có n cách) thì có m + n cách hoàn thành.", "Quy tắc nhân: Một công việc thực hiện qua hai công đoạn liên tiếp (công đoạn 1 có m cách, sau đó công đoạn 2 có n cách) thì có m \\times n cách hoàn thành.", "Quy tắc bù: Số cách thực hiện hành động = Tổng số trường hợp - Số cách vi phạm yêu cầu."] },
          { title: "Hoán vị, Chỉnh hợp và Tổ hợp", points: ["Hoán vị của n phần tử: Sắp xếp thứ tự n phần tử khác nhau, số cách là P_n = n!.", "Chỉnh hợp chập k của n: Chọn k phần tử từ n phần tử và CÓ sắp xếp thứ tự, số cách là A_n^k = \\frac{n!}{(n-k)!}.", "Tổ hợp chập k của n: Chọn k phần tử từ n phần tử và KHÔNG quan tâm thứ tự, số cách là C_n^k = \\frac{n!}{k!(n-k)!}."] }
        ],
        examples: [
          { q: "Một hộp chứa 5 quả cầu xanh và 4 quả cầu đỏ. Lấy ngẫu nhiên 3 quả cầu. Có bao nhiêu cách để lấy được ít nhất 1 quả cầu đỏ?", a: "Tổng số cách lấy 3 quả cầu bất kì từ 9 quả: C_9^3 = 84 cách.\\nTrường hợp lấy 3 quả toàn màu xanh (không có quả đỏ nào): C_5^3 = 10 cách.\\nSố cách lấy được ít nhất 1 quả cầu đỏ là: 84 - 10 = 74 cách." }
        ]
      }
  },
  {
    id: "toan-10-04",
    subject: "toan",
    title: "Chuyên Đề Hàm Số Bậc Hai, Dấu Tam Thức Bậc Hai & Bất Phương Trình Bậc Hai",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Tổ Toán THPT Chuyên KHTN & VietJack",
    year: 2025,
    buoiHoc: "Chuyên đề 04",
    caLive: "",
    ngayLive: "",
    description: "Khảo sát và vẽ parabol y = ax^2 + bx + c, định lý xét dấu tam thức bậc hai (trong trái ngoài cùng), bất phương trình bậc hai và bài toán thực tế quỹ đạo parabol.",
    link: "https://toanmath.com/ham-so-bac-hai-10",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 10", "Hàm số bậc hai", "Parabol", "Tam thức bậc hai", "Định lý Viète", "Bất phương trình"],
    downloads: 13900,
    featured: false,
    studyContent: {
        summary: "Kiến thức đại số cốt lõi. Giúp giải quyết các bài toán tìm tham số m để bất phương trình luôn đúng với mọi x, tìm giá trị lớn nhất nhỏ nhất của hàm số bậc hai trên một đoạn.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Tọa độ đỉnh Parabol: I\\left(-\\frac{b}{2a}; -\\frac{\\Delta}{4a}\\right) với \\Delta = b^2 - 4ac",
          "Điều kiện f(x) > 0, \\forall x \\in \\mathbb{R}: a > 0 \\text{ và } \\Delta < 0",
          "Điều kiện f(x) \\ge 0, \\forall x \\in \\mathbb{R}: a > 0 \\text{ và } \\Delta \\le 0",
          "Điều kiện f(x) < 0, \\forall x \\in \\mathbb{R}: a < 0 \\text{ và } \\Delta < 0",
          "Định lý Viète: x_1 + x_2 = -\\frac{b}{a}, x_1 x_2 = \\frac{c}{a}"
        ],
        studyTips: [
          "1. Chú ý xét trường hợp a = 0 khi hệ số chứa tham số m.",
          "2. Muốn tam thức không đổi dấu trên \\mathbb{R}, điều kiện tiên quyết là \\Delta < 0 hoặc \\Delta \\le 0.",
          "3. Khi tìm GTLN, GTNN trên đoạn [p; q], kiểm tra xem hoành độ đỉnh x_I có thuộc đoạn [p; q] hay không."
        ],
        theory: [
          { title: "Khảo sát hàm số bậc hai y = ax^2 + bx + c (a \\ne 0)", points: ["Đồ thị là một đường Parabol có đỉnh I(-\\frac{b}{2a}; -\\frac{\\Delta}{4a}), trục đối xứng là đường thẳng x = -\\frac{b}{2a}.", "Bề lõm: Nếu a > 0 bề lõm quay lên trên (hàm số đạt giá trị nhỏ nhất tại đỉnh); nếu a < 0 bề lõm quay xuống dưới (hàm số đạt giá trị lớn nhất tại đỉnh).", "Giao điểm với trục Ox là nghiệm của phương trình ax^2 + bx + c = 0."] },
          { title: "Định lý về dấu của tam thức bậc hai f(x) = ax^2 + bx + c", points: ["Nếu \\Delta < 0: f(x) cùng dấu với hệ số a với mọi x \\in \\mathbb{R}.", "Nếu \\Delta = 0: f(x) cùng dấu với hệ số a với mọi x \\ne -\\frac{b}{2a}.", "Nếu \\Delta > 0: f(x) có 2 nghiệm x_1 < x_2. Trong khoảng (x_1; x_2) f(x) trái dấu với a; ngoài khoảng f(x) cùng dấu với a ('Trong trái ngoài cùng')."] }
        ],
        examples: [
          { q: "Tìm tất cả các giá trị của tham số m để bất phương trình x^2 - 2(m + 1)x + 4m + 5 > 0 nghiệm đúng với mọi x \\in \\mathbb{R}.", a: "Hệ số a = 1 > 0.\\nĐể bất phương trình nghiệm đúng với mọi x \\in \\mathbb{R}, điều kiện cần và đủ là \\Delta' < 0.\\nTa có: \\Delta' = [-(m + 1)]^2 - 1(4m + 5) = m^2 + 2m + 1 - 4m - 5 = m^2 - 2m - 4.\\n\\Delta' < 0 \\Leftrightarrow m^2 - 2m - 4 < 0.\\nGiải phương trình m^2 - 2m - 4 = 0 \\Rightarrow m = 1 \\pm \\sqrt{5}.\\nTheo định lý trong trái ngoài cùng, ta được: 1 - \\sqrt{5} < m < 1 + \\sqrt{5}." }
        ]
      }
  },
  {
    id: "toan-10-05",
    subject: "toan",
    title: "Chuyên Đề Phương Pháp Tọa Độ Trong Mặt Phẳng Oxy & Ba Đường Conic",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Tổ Toán THPT Chu Văn An & ToanMath",
    year: 2025,
    buoiHoc: "Chuyên đề 05",
    caLive: "",
    ngayLive: "",
    description: "Phương trình đường thẳng, khoảng cách, góc, phương trình đường tròn và phương trình chính tắc của 3 đường conic: Elip, Hypebol, Parabol.",
    link: "https://toanmath.com/phuong-phap-toa-do-oxy-10",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 10", "Hình học Oxy", "Đường thẳng", "Đường tròn", "Elip", "Hypebol", "Parabol"],
    downloads: 14700,
    featured: false,
    studyContent: {
        summary: "Cung cấp công cụ giải tích phẳng chuẩn xác. Chuyển đổi các bài toán hình học tổng hợp thành tính toán đại số tọa độ, làm tiền đề trực tiếp cho hình học không gian Oxyz lớp 12.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Khoảng cách: d(M_0, \\Delta) = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}",
          "Góc giữa hai đường thẳng: \\cos \\varphi = \\frac{|A_1 A_2 + B_1 B_2|}{\\sqrt{A_1^2 + B_1^2}\\sqrt{A_2^2 + B_2^2}}",
          "Tiếp tuyến đường tròn tại M_0: (x_0 - a)(x - a) + (y_0 - b)(y - b) = R^2",
          "Elip: \\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1; c = \\sqrt{a^2 - b^2}; \\text{tiêu cự } 2c",
          "Hypebol: \\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1; c = \\sqrt{a^2 + b^2}",
          "Parabol: y^2 = 2px; \\text{tham số tiêu } p"
        ],
        studyTips: [
          "1. Chú ý dấu cộng trong phương trình Elip và dấu trừ trong phương trình Hypebol.",
          "2. Trong Elip: a lớn nhất (a^2 = b^2 + c^2). Trong Hypebol: c lớn nhất (c^2 = a^2 + b^2).",
          "3. Điều kiện đường thẳng tiếp xúc đường tròn: d(I, \\Delta) = R."
        ],
        theory: [
          { title: "Đường thẳng & Đường tròn trong Oxy", points: ["Phương trình tổng quát đường thẳng qua M_0(x_0; y_0) có VTPT \\vec{n}(A; B): A(x - x_0) + B(y - y_0) = 0.", "Khoảng cách từ M_0(x_0; y_0) đến đường thẳng \\Delta: Ax + By + C = 0: d(M_0, \\Delta) = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}.", "Phương trình đường tròn tâm I(a; b) bán kính R: (x - a)^2 + (y - b)^2 = R^2 hoặc x^2 + y^2 - 2ax - 2by + c = 0 (với a^2 + b^2 - c = R^2 > 0)."] },
          { title: "Ba đường Conic chính tắc", points: ["Elip: \\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1 (a > b > 0) với quan hệ tiêu cự c^2 = a^2 - b^2, 2 tiêu điểm F_1(-c; 0), F_2(c; 0).", "Hypebol: \\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1 (a, b > 0) với c^2 = a^2 + b^2, hai đường tiệm cận y = \\pm \\frac{b}{a} x.", "Parabol: y^2 = 2px (p > 0), tiêu điểm F\\left(\\frac{p}{2}; 0\\right), đường chuẩn x = -\\frac{p}{2}."] }
        ],
        examples: [
          { q: "Cho Elip (E): \\frac{x^2}{25} + \\frac{y^2}{9} = 1. Xác định tọa độ các tiêu điểm và tính tiêu cự của (E).", a: "Từ phương trình (E), ta có:\\na^2 = 25 \\Rightarrow a = 5;\\nb^2 = 9 \\Rightarrow b = 3.\\nTa tính c: c^2 = a^2 - b^2 = 25 - 9 = 16 \\Rightarrow c = 4.\\nTọa độ hai tiêu điểm là: F_1(-4; 0) và F_2(4; 0).\\nTiêu cự của Elip là: 2c = 2 \\cdot 4 = 8." }
        ]
      }
  },
  {
    id: "toan-10-06",
    subject: "toan",
    title: "Thống Kê & Xác Suất Cổ Điển Lớp 10 (Chương Trình Mới)",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Tổ Toán THPT Chuyên Lê Hồng Phong",
    year: 2025,
    buoiHoc: "Chuyên đề 06",
    caLive: "",
    ngayLive: "",
    description: "Số đặc trưng đo xu thế trung tâm (trung bình, trung vị, tứ phân vị, mốt) và số đặc trưng đo mức độ phân tán (khoảng biến thiên, khoảng tứ phân vị, phương sai, độ lệch chuẩn, giá trị ngoại lệ).",
    link: "https://toanmath.com/thong-ke-xac-suat-10",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 10", "Thống kê", "Số trung bình", "Trung vị", "Tứ phân vị", "Phương sai", "Độ lệch chuẩn"],
    downloads: 12900,
    featured: false,
    studyContent: {
        summary: "Nội dung trọng tâm mới của SGK 2018. Đề thi minh họa Bộ GD&ĐT 2025 có câu hỏi trắc nghiệm Đúng/Sai về tìm tứ phân vị và phân tích độ ổn định dữ liệu.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Số trung bình: \\bar{x} = \\frac{x_1 + x_2 + ... + x_n}{n}",
          "Khoảng biến thiên: R = x_{max} - x_{min}",
          "Khoảng tứ phân vị: \\Delta_Q = Q_3 - Q_1",
          "Ranh giới giá trị ngoại lệ: [Q_1 - 1.5\\Delta_Q; Q_3 + 1.5\\Delta_Q]",
          "Phương sai mẫu: s^2 = \\frac{1}{n}\\sum_{i=1}^n (x_i - \\bar{x})^2",
          "Độ lệch chuẩn: s = \\sqrt{s^2}"
        ],
        studyTips: [
          "1. Trước khi tìm trung vị và tứ phân vị, BẮT BUỘC phải sắp xếp mẫu số liệu theo thứ tự tăng dần.",
          "2. Nếu số phần tử n là lẻ: Q_2 là phần tử chính giữa, nửa dưới và nửa trên không tính Q_2.",
          "3. Nếu số phần tử n là chẵn: Q_2 là trung bình cộng của 2 phần tử chính giữa."
        ],
        theory: [
          { title: "Các số đặc trưng đo xu thế trung tâm", points: ["Số trung bình \\bar{x}: Tổng các giá trị chia cho kích thước mẫu n.", "Trung vị M_e (hay tứ phân vị thứ hai Q_2): Giá trị nằm chính giữa dãy số liệu đã sắp xếp theo thứ tự không giảm.", "Tứ phân vị thứ nhất Q_1: Trung vị của nửa dãy dưới; Tứ phân vị thứ ba Q_3: Trung vị của nửa dãy trên.", "Mốt M_o: Giá trị có tần số xuất hiện lớn nhất trong mẫu số liệu."] },
          { title: "Các số đặc trưng đo mức độ phân tán", points: ["Khoảng biến thiên: R = x_{\\max} - x_{\\min}.", "Khoảng tứ phân vị: \\Delta_Q = Q_3 - Q_1 (đo mức độ phân tán của 50% số liệu ở giữa, không bị ảnh hưởng bởi giá trị bất thường).", "Giá trị ngoại lệ: Giá trị x nhỏ hơn Q_1 - 1.5 \\Delta_Q hoặc lớn hơn Q_3 + 1.5 \\Delta_Q.", "Phương sai s^2 và độ lệch chuẩn s = \\sqrt{s^2}: Đo độ lệch trung bình so với số trung bình. Độ lệch chuẩn càng nhỏ thì số liệu càng đồng đều và ổn định."] }
        ],
        examples: [
          { q: "Cho mẫu số liệu điểm kiểm tra: 4, 6, 7, 7, 8, 9, 10. Tìm các tứ phân vị Q_1, Q_2, Q_3 và khoảng tứ phân vị \\Delta_Q.", a: "Mẫu số liệu đã sắp xếp có n = 7 phần tử:\\nTrung vị (tứ phân vị thứ hai) là phần tử thứ 4: Q_2 = 7.\\nNửa mẫu dưới: 4, 6, 7 \\Rightarrow Tứ phân vị thứ nhất Q_1 = 6.\\nNửa mẫu trên: 8, 9, 10 \\Rightarrow Tứ phân vị thứ ba Q_3 = 9.\\nKhoảng tứ phân vị: \\Delta_Q = Q_3 - Q_1 = 9 - 6 = 3." }
        ]
      }
  },
  {
    id: "toan-11-01",
    subject: "toan",
    title: "Hàm Số Lượng Giác & Các Phương Trình Lượng Giác Cốt Lõi (Lớp 11)",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thầy Đỗ Văn Đức & SGK Cánh Diều",
    year: 2025,
    buoiHoc: "Chuyên đề 07",
    caLive: "",
    ngayLive: "",
    description: "Giá trị lượng giác của góc lượng giác, công thức cộng, nhân đôi, biến đổi tích - tổng, tập xác định, chu kì và phương trình lượng giác cơ bản.",
    link: "https://toanmath.com/luong-giac-11",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 11", "Lượng giác", "Hàm số lượng giác", "Phương trình lượng giác"],
    downloads: 17500,
    featured: true,
    studyContent: {
        summary: "Lượng giác là công cụ toán học nền móng cho phần Dao động điều hòa và Sóng cơ học môn Vật lí lớp 11 và 12. Thành thạo công thức nghiệm và điều kiện xác định.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "\\sin x = \\sin \\alpha \\Leftrightarrow x = \\alpha + k2\\pi \\lor x = \\pi - \\alpha + k2\\pi",
          "\\cos x = \\cos \\alpha \\Leftrightarrow x = \\pm \\alpha + k2\\pi",
          "\\tan x = \\tan \\alpha \\Leftrightarrow x = \\alpha + k\\pi",
          "\\cot x = \\cot \\alpha \\Leftrightarrow x = \\alpha + k\\pi",
          "\\cos 2x = 2\\cos^2 x - 1 = 1 - 2\\sin^2 x = \\cos^2 x - \\sin^2 x",
          "\\sin 2x = 2\\sin x \\cos x"
        ],
        studyTips: [
          "1. Chú ý đơn vị radian và độ khi bấm máy tính (phím Shift + Mode để chọn Radian).",
          "2. Đừng quên đuôi nghiệm chu kì: sin và cos là k2\\pi, tan và cot là k\\pi.",
          "3. Phương trình \\sin x = a hoặc \\cos x = a chỉ có nghiệm khi -1 \\le a \\le 1."
        ],
        theory: [
          { title: "Các công thức biến đổi lượng giác cốt lõi", points: ["Công thức cộng: \\cos(a \\pm b) = \\cos a \\cos b \\mp \\sin a \\sin b; \\sin(a \\pm b) = \\sin a \\cos b \\pm \\cos a \\sin b.", "Công thức nhân đôi: \\sin 2a = 2\\sin a \\cos a; \\cos 2a = \\cos^2 a - \\sin^2 a = 2\\cos^2 a - 1 = 1 - 2\\sin^2 a.", "Công thức hạ bậc: \\cos^2 a = \\frac{1 + \\cos 2a}{2}; \\sin^2 a = \\frac{1 - \\cos 2a}{2}."] },
          { title: "Phương trình lượng giác cơ bản", points: ["\\sin x = \\sin \\alpha \\Leftrightarrow x = \\alpha + k2\\pi \\text{ hoặc } x = \\pi - \\alpha + k2\\pi (k \\in \\mathbb{Z}).", "\\cos x = \\cos \\alpha \\Leftrightarrow x = \\pm \\alpha + k2\\pi (k \\in \\mathbb{Z}).", "\\tan x = \\tan \\alpha \\Leftrightarrow x = \\alpha + k\\pi (k \\in \\mathbb{Z}) (điều kiện x, \\alpha \\ne \\frac{\\pi}{2} + m\\pi)."] }
        ],
        examples: [
          { q: "Giải phương trình: 2\\cos\\left(2x - \\frac{\\pi}{3}\\right) - \\sqrt{3} = 0.", a: "Phương trình tương đương với:\\n\\cos\\left(2x - \\frac{\\pi}{3}\\right) = \\frac{\\sqrt{3}}{2} = \\cos\\left(\\frac{\\pi}{6}\\right).\\nÁp dụng công thức nghiệm:\\nTrường hợp 1: 2x - \\frac{\\pi}{3} = \\frac{\\pi}{6} + k2\\pi \\Rightarrow 2x = \\frac{\\pi}{2} + k2\\pi \\Rightarrow x = \\frac{\\pi}{4} + k\\pi (k \\in \\mathbb{Z}).\\nTrường hợp 2: 2x - \\frac{\\pi}{3} = -\\frac{\\pi}{6} + k2\\pi \\Rightarrow 2x = \\frac{\\pi}{6} + k2\\pi \\Rightarrow x = \\frac{\\pi}{12} + k\\pi (k \\in \\mathbb{Z})." }
        ]
      }
  },
  {
    id: "toan-11-02",
    subject: "toan",
    title: "Dãy Số, Cấp Số Cộng & Cấp Số Nhân - Ứng Dụng Bài Toán Tài Chính & Tăng Trưởng",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Tổ Toán THPT Chuyên KHTN & VietJack",
    year: 2025,
    buoiHoc: "Chuyên đề 08",
    caLive: "",
    ngayLive: "",
    description: "Số hạng tổng quát, công sai d, công bội q, tổng n số hạng đầu tiên và bài toán lãi kép, gửi tiết kiệm, trả góp hàng tháng.",
    link: "https://toanmath.com/day-so-cap-so-cong-nhan-11",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 11", "Cấp số cộng", "Cấp số nhân", "Lãi kép", "Toán tài chính"],
    downloads: 16300,
    featured: false,
    studyContent: {
        summary: "Các bài toán thực tế về bài toán tăng trưởng dân số, lãi kép ngân hàng và khấu hao tài sản trong đề thi THPT 2025 đều khai thác trực tiếp từ công thức cấp số cộng và cấp số nhân.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Số hạng tổng quát CSC: u_n = u_1 + (n - 1)d",
          "Tổng n số hạng CSC: S_n = \\frac{n(u_1 + u_n)}{2} = \\frac{n[2u_1 + (n-1)d]}{2}",
          "Số hạng tổng quát CSN: u_n = u_1 \\cdot q^{n-1}",
          "Tổng n số hạng CSN: S_n = \\frac{u_1(1 - q^n)}{1 - q} \\quad (q \\ne 1)",
          "Bài toán lãi kép: A = P(1 + r)^n"
        ],
        studyTips: [
          "1. Phân biệt rõ số hạng thứ n (u_n) và tổng n số hạng đầu tiên (S_n).",
          "2. Cấp số nhân lùi vô hạn (|q| < 1) có tổng S = \\frac{u_1}{1 - q}.",
          "3. Bài toán lãi kép: n là số kì hạn gửi, r là lãi suất tương ứng của 1 kì hạn."
        ],
        theory: [
          { title: "Cấp số cộng (CSC)", points: ["Định nghĩa: Dãy số (u_n) thỏa mãn u_{n+1} = u_n + d với d là công sai không đổi.", "Số hạng tổng quát: u_n = u_1 + (n - 1)d.", "Tính chất: u_k = \\frac{u_{k-1} + u_{k+1}}{2} (ba số hạng liên tiếp lập thành CSC thì số ở giữa bằng TBC hai số hai bên).", "Tổng n số hạng đầu: S_n = \\frac{n(u_1 + u_n)}{2} = \\frac{n[2u_1 + (n - 1)d]}{2}."] },
          { title: "Cấp số nhân (CSN)", points: ["Định nghĩa: Dãy số (u_n) thỏa mãn u_{n+1} = u_n \\cdot q với q là công bội không đổi.", "Số hạng tổng quát: u_n = u_1 \\cdot q^{n - 1}.", "Tính chất: u_k^2 = u_{k-1} \\cdot u_{k+1}.", "Tổng n số hạng đầu (q \\ne 1): S_n = \\frac{u_1(1 - q^n)}{1 - q}."] }
        ],
        examples: [
          { q: "Một người gửi tiết kiệm 100 triệu đồng vào ngân hàng với lãi suất 6%/năm theo hình thức lãi kép. Hỏi sau 5 năm người đó nhận được tất cả bao nhiêu tiền cả gốc lẫn lãi?", a: "Áp dụng công thức lãi kép:\\nA = P(1 + r)^n\\nVới P = 100 triệu, r = 6% = 0.06, n = 5 năm.\\nSố tiền nhận được sau 5 năm là:\\nA = 100 \\times (1 + 0.06)^5 \\approx 100 \\times 1.338226 = 133.82 triệu đồng." }
        ]
      }
  },
  {
    id: "toan-11-03",
    subject: "toan",
    title: "Hình Học Không Gian 11: Quan Hệ Vuông Góc, Tính Góc & Khoảng Cách",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thầy Đỗ Văn Đức - Hệ Thống Luyện Thi IMO",
    year: 2025,
    buoiHoc: "Chuyên đề 09",
    caLive: "",
    ngayLive: "",
    description: "Chứng minh đường thẳng vuông góc mặt phẳng, hai mặt phẳng vuông góc, góc giữa đường thẳng và mặt phẳng, khoảng cách từ điểm đến mặt phẳng.",
    link: "https://toanmath.com/hinh-hoc-khong-gian-11",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 11", "Hình không gian", "Vuông góc", "Góc", "Khoảng cách", "Khoảng cách điểm đến mp"],
    downloads: 18900,
    featured: true,
    studyContent: {
        summary: "Phần hình học chiếm tới 2-3 câu trong cấu trúc đề thi tốt nghiệp 2025. Nắm chắc mô hình chân đường cao, định lý 3 đường vuông góc và phương pháp chuyển khoảng cách về chân đường cao.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Đường vuông góc mặt: d \\perp a, d \\perp b (a \\cap b \\subset (P)) \\Rightarrow d \\perp (P)",
          "Góc giữa đường thẳng và mp: \\sin(d, (P)) = \\frac{d(M, (P))}{MH} = \\cos(d, \\vec{n})",
          "Tỉ số khoảng cách: \\frac{d(A, (P))}{d(B, (P))} = \\frac{IA}{IB} \\quad (AB \\cap (P) = I)",
          "Công thức tứ diện vuông OABC tại O: \\frac{1}{h^2} = \\frac{1}{OA^2} + \\frac{1}{OB^2} + \\frac{1}{OC^2}"
        ],
        studyTips: [
          "1. Luôn xác định 'Chân đường vuông góc' H của hình chóp/hình lăng trụ trước tiên.",
          "2. Đưa mọi bài toán tính khoảng cách từ điểm bất kì về chân đường vuông góc H.",
          "3. Sử dụng công thức nghịch đảo bình phương đường cao trong tam giác vuông: \\frac{1}{h^2} = \\frac{1}{a^2} + \\frac{1}{b^2}."
        ],
        theory: [
          { title: "Đường thẳng vuông góc với mặt phẳng", points: ["Định lý: Muốn chứng minh d \\perp (P), ta chứng minh d vuông góc với hai đường thẳng cắt nhau nằm trong (P).", "Tính chất: Nếu d \\perp (P) thì d vuông góc với MỌI đường thẳng nằm trong (P).", "Định lý ba đường vuông góc: Giả sử a \\subset (P) và b' là hình chiếu của b lên (P). Khi đó a \\perp b \\Leftrightarrow a \\perp b'."] },
          { title: "Khoảng cách từ điểm đến mặt phẳng", points: ["Khoảng cách từ điểm M đến mặt phẳng (P) là độ dài đoạn MH vuông góc với (P).", "Quy tắc chuyển điểm: Nếu đường thẳng AB song song với (P) thì d(A, (P)) = d(B, (P)).", "Nếu AB cắt (P) tại I thì \\frac{d(A, (P))}{d(B, (P))} = \\frac{IA}{IB} (quy tắc tỉ số khoảng cách)."] }
        ],
        examples: [
          { q: "Cho hình chóp S.ABC có SA \\perp (ABC), tam giác ABC vuông tại B. Cho SA = a, AB = a, BC = a\\sqrt{3}. Tính khoảng cách từ A đến mặt phẳng (SBC).", a: "Ta có:\\nBC \\perp AB (tam giác ABC vuông tại B)\\nBC \\perp SA (do SA \\perp (ABC))\\n\\Rightarrow BC \\perp (SAB) \\Rightarrow (SBC) \\perp (SAB) theo giao tuyến SB.\\nTrong mặt phẳng (SAB), kẻ AH \\perp SB tại H.\\nDo (SAB) \\perp (SBC) nên AH \\perp (SBC) \\Rightarrow d(A, (SBC)) = AH.\\nXét tam giác SAB vuông tại A có hai cạnh góc vuông SA = a, AB = a:\\n\\frac{1}{AH^2} = \\frac{1}{SA^2} + \\frac{1}{AB^2} = \\frac{1}{a^2} + \\frac{1}{a^2} = \\frac{2}{a^2} \\Rightarrow AH = \\frac{a}{\\sqrt{2}} = \\frac{a\\sqrt{2}}{2}." }
        ]
      }
  },
  {
    id: "toan-11-04",
    subject: "toan",
    title: "Chuyên Đề Giới Hạn Dãy Số, Giới Hạn Hàm Số & Hàm Số Liên Tục",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Khoa Toán ĐH Sư Phạm Hà Nội & ToanMath",
    year: 2025,
    buoiHoc: "Chuyên đề 10",
    caLive: "",
    ngayLive: "",
    description: "Khử các dạng vô định 0/0, vô cùng / vô cùng, vô cùng trừ vô cùng, định lý kẹp, xét tính liên tục của hàm số và định lý chứng minh phương trình có nghiệm.",
    link: "https://toanmath.com/gioi-han-ham-so-11",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 11", "Giới hạn", "Dạng vô định", "Hàm số liên tục", "Định lý Bolzano"],
    downloads: 14800,
    featured: false,
    studyContent: {
        summary: "Giới hạn là nền tảng giải tích bắt buộc để xây dựng khái niệm Đạo hàm, Tích phân và Tiệm cận của hàm số lớp 12. Thành thạo kỹ thuật nhân liên hợp và phân tích nhân tử.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Dạng đa thức bậc n/m: \\lim_{x \\to \\infty} \\frac{a x^n + ...}{b x^m + ...} = \\frac{a}{b} \\text{ (nếu n = m)}",
          "Liên hợp bậc 2: a - b = \\frac{a^2 - b^2}{a + b}",
          "Liên hợp bậc 3: a - b = \\frac{a^3 - b^3}{a^2 + ab + b^2}",
          "Điều kiện liên tục: \\lim_{x \\to x_0^+} f(x) = \\lim_{x \\to x_0^-} f(x) = f(x_0)",
          "Định lý nghiệm: f(a) \\cdot f(b) < 0 \\Rightarrow \\exists c \\in (a; b): f(c) = 0"
        ],
        studyTips: [
          "1. Nhớ công thức nghiệm nhẩm đa thức: nếu f(x_0) = 0 thì f(x) chứa nhân tử (x - x_0).",
          "2. Khi x \\to -\\infty, chú ý khai căn \\sqrt{x^2} = |x| = -x.",
          "3. Đặt u = x - x_0 để đổi biến giới hạn về 0 khi gặp biểu thức lượng giác."
        ],
        theory: [
          { title: "Các dạng vô định và phương pháp giải", points: ["Dạng 0/0: Phân tích đa thức thành nhân tử để triệt tiêu nhân tử chung (x - x_0), hoặc nhân chia lượng liên hợp khi có căn thức.", "Dạng \\infty/\\infty: Chia cả tử và mẫu cho lũy thừa bậc cao nhất của biến.", "Dạng \\infty - \\infty: Nhân liên hợp để đưa về dạng hữu tỉ."] },
          { title: "Hàm số liên tục & Sự tồn tại nghiệm", points: ["Hàm số f(x) liên tục tại x_0 khi: \\lim_{x \\to x_0} f(x) = f(x_0).", "Hàm đa thức, phân thức hữu tỉ, lượng giác liên tục trên từng khoảng xác định của chúng.", "Định lý Bolzano: Nếu hàm số f(x) liên tục trên đoạn [a; b] và f(a) \\cdot f(b) < 0 thì phương trình f(x) = 0 có ít nhất một nghiệm thuộc khoảng (a; b)."] }
        ],
        examples: [
          { q: "Tính giới hạn: L = \\lim_{x \\to 2} \\frac{\\sqrt{x + 2} - 2}{x^2 - 4}.", a: "Đây là dạng vô định 0/0. Nhân tử và mẫu với lượng liên hợp \\sqrt{x + 2} + 2:\\nTử số: (\\sqrt{x + 2} - 2)(\\sqrt{x + 2} + 2) = (x + 2) - 4 = x - 2.\\nMẫu số: (x^2 - 4)(\\sqrt{x + 2} + 2) = (x - 2)(x + 2)(\\sqrt{x + 2} + 2).\\nTriệt tiêu nhân tử (x - 2):\\nL = \\lim_{x \\to 2} \\frac{1}{(x + 2)(\\sqrt{x + 2} + 2)} = \\frac{1}{(2 + 2)(\\sqrt{4} + 2)} = \\frac{1}{4 \\times 4} = \\frac{1}{16}." }
        ]
      }
  },
  {
    id: "toan-11-05",
    subject: "toan",
    title: "Chuyên Đề Đạo Hàm Lớp 11, Ý Nghĩa Hình Học & Phương Trình Tiếp Tuyến",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Tổ Toán THPT Chuyên Hà Nội - Amsterdam",
    year: 2025,
    buoiHoc: "Chuyên đề 11",
    caLive: "",
    ngayLive: "",
    description: "Bảng quy tắc tính đạo hàm các hàm cơ bản và hàm hợp, ý nghĩa vật lí (vận tốc tức thời), ý nghĩa hình học (hệ số góc) và viết phương trình tiếp tuyến của đồ thị.",
    link: "https://toanmath.com/dao-ham-va-tiep-tuyen-11",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 11", "Đạo hàm", "Quy tắc tính đạo hàm", "Hàm hợp", "Tiếp tuyến đồ thị"],
    downloads: 17200,
    featured: true,
    studyContent: {
        summary: "Trọng tâm trực tiếp xuyên suốt môn Toán lớp 12. Thành thạo quy tắc đạo hàm hàm hợp và viết phương trình tiếp tuyến tại tiếp điểm, qua một điểm hoặc biết trước hệ số góc.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Đạo hàm tại điểm: f'(x_0) = \\lim_{\\Delta x \\to 0} \\frac{f(x_0 + \\Delta x) - f(x_0)}{\\Delta x}",
          "Đạo hàm hàm hợp: (f(u))' = f'(u) \\cdot u'",
          "Phương trình tiếp tuyến tại M_0(x_0, y_0): y = f'(x_0)(x - x_0) + y_0",
          "Hệ số góc song song với d (y = ax + b): f'(x_0) = a",
          "Hệ số góc vuông góc với d (y = ax + b): f'(x_0) = -\\frac{1}{a}"
        ],
        studyTips: [
          "1. Đạo hàm của hàm hợp đừng bao giờ quên nhân thêm đuôi u'.",
          "2. Phân biệt rõ: Tiếp tuyến TẠI điểm (điểm đó nằm trên đồ thị) và tiếp tuyến ĐI QUA điểm.",
          "3. Vận tốc tức thời trong chuyển động v(t) = s'(t); gia tốc tức thời a(t) = v'(t) = s''(t)."
        ],
        theory: [
          { title: "Bảng đạo hàm hàm số cơ bản và hàm hợp", points: ["(x^n)' = n x^{n-1} \\Rightarrow (u^n)' = n u^{n-1} \\cdot u'.", "(\\sqrt{x})' = \\frac{1}{2\\sqrt{x}} \\Rightarrow (\\sqrt{u})' = \\frac{u'}{2\\sqrt{u}}.", "(u \\cdot v)' = u'v + uv'; (\\frac{u}{v})' = \\frac{u'v - uv'}{v^2}.", "(\\sin u)' = u' \\cos u; (\\cos u)' = -u' \\sin u; (\\tan u)' = \\frac{u'}{\\cos^2 u}."] },
          { title: "Ý nghĩa hình học & Phương trình tiếp tuyến", points: ["Đạo hàm f'(x_0) là hệ số góc k của tiếp tuyến tại điểm M_0(x_0; y_0).", "Phương trình tiếp tuyến tại M_0(x_0; y_0): y = f'(x_0)(x - x_0) + y_0.", "Hai đường song song có cùng hệ số góc: k_1 = k_2. Hai đường vuông góc có tích hệ số góc bằng -1: k_1 \\cdot k_2 = -1."] }
        ],
        examples: [
          { q: "Viết phương trình tiếp tuyến của đồ thị hàm số y = x^3 - 3x + 2 tại điểm có hoành độ x_0 = 2.", a: "Ta có:\\ny(2) = 2^3 - 3(2) + 2 = 8 - 6 + 2 = 4 \\Rightarrow Tiếp điểm M_0(2; 4).\\nTính đạo hàm:\\ny' = 3x^2 - 3.\\nHệ số góc của tiếp tuyến tại x_0 = 2 là:\\nk = y'(2) = 3(2)^2 - 3 = 12 - 3 = 9.\\nPhương trình tiếp tuyến là:\\ny = k(x - x_0) + y_0 = 9(x - 2) + 4 = 9x - 18 + 4 = 9x - 14." }
        ]
      }
  },
  {
    id: "toan-11-06",
    subject: "toan",
    title: "Chuyên Đề Hàm Số Mũ, Lũy Thừa & Hàm Số Logarit",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thầy Đỗ Văn Đức & SGK Kết Nối Tri Thức",
    year: 2025,
    buoiHoc: "Chuyên đề 12",
    caLive: "",
    ngayLive: "",
    description: "Quy tắc lũy thừa, các tính chất logarit, tập xác định, đồ thị, tính đơn điệu của hàm số mũ, logarit và giải phương trình mũ - logarit cơ bản.",
    link: "https://toanmath.com/ham-so-mu-va-logarit-11",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 11", "Hàm số mũ", "Logarit", "Lũy thừa", "Phương trình mũ", "Bất phương trình logarit"],
    downloads: 16700,
    featured: false,
    studyContent: {
        summary: "Chương trình mới chuyển phần Hàm số Mũ và Logarit xuống lớp 11. Đóng vai trò cực kì then chốt trong kì thi THPT 2025 với nhiều bài toán thực tế về độ pH, cường độ âm thanh Decibel và lãi kép liên tục.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "\\log_a(xy) = \\log_a x + \\log_a y; \\log_a(x/y) = \\log_a x - \\log_a y",
          "\\log_{a^\\alpha} x = \\frac{1}{\\alpha}\\log_a x; a^{\\log_a b} = b",
          "Đổi cơ số: \\log_a b = \\frac{\\ln b}{\\ln a}",
          "Nghiệm PT: a^x = b \\Leftrightarrow x = \\log_a b \\quad (b > 0)",
          "Nghiệm PT: \\log_a x = b \\Leftrightarrow x = a^b"
        ],
        studyTips: [
          "1. Giải phương trình/bất phương trình logarit: BƯỚC ĐẦU TIÊN là đặt điều kiện xác định biểu thức trong log > 0.",
          "2. Khi giải bất phương trình cơ số 0 < a < 1, nhớ ĐỔI CHIỀU bất phương trình.",
          "3. Phương trình a^x = b vô nghiệm nếu b \\le 0."
        ],
        theory: [
          { title: "Các công thức biến đổi logarit cốt lõi", points: ["\\log_a(x \\cdot y) = \\log_a x + \\log_a y; \\log_a\\left(\\frac{x}{y}\\right) = \\log_a x - \\log_a y (với x, y > 0).", "\\log_a x^\\alpha = \\alpha \\log_a x; \\log_{a^\\beta} x = \\frac{1}{\\beta} \\log_a x.", "Công thức đổi cơ số: \\log_a b = \\frac{\\log_c b}{\\log_c a} = \\frac{1}{\\log_b a}."] },
          { title: "Tính đơn điệu của hàm số mũ y = a^x và hàm số logarit y = \\log_a x", points: ["Nếu cơ số a > 1: Hàm số luôn ĐỒNG BIẾN trên tập xác định. Khi đó a^f(x) > a^g(x) \\Leftrightarrow f(x) > g(x).", "Nếu cơ số 0 < a < 1: Hàm số luôn NGHỊCH BIẾN trên tập xác định. Khi đó a^f(x) > a^g(x) \\Leftrightarrow f(x) < g(x) (phải đổi chiều bất đẳng thức)."] }
        ],
        examples: [
          { q: "Giải phương trình: \\log_2(x - 1) + \\log_2(x + 1) = 3.", a: "Điều kiện: x - 1 > 0 và x + 1 > 0 \\Leftrightarrow x > 1.\\nPhương trình tương đương với:\\n\\log_2[(x - 1)(x + 1)] = 3\\n\\Leftrightarrow (x - 1)(x + 1) = 2^3 = 8\\n\\Leftrightarrow x^2 - 1 = 8 \\Leftrightarrow x^2 = 9 \\Leftrightarrow x = \\pm 3.\\nĐối chiếu điều kiện x > 1, ta chọn nghiệm x = 3." }
        ]
      }
  },
  {
    id: "toan-11-07",
    subject: "toan",
    title: "Chuyên Đề Xác Suất Có Điều Kiện, Công Thức Toàn Phần & Công Thức Bayes",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Khoa Toán ĐH Sư Phạm Hà Nội & Tổ Toán Chuyên KHTN",
    year: 2025,
    buoiHoc: "Chuyên đề 13",
    caLive: "",
    ngayLive: "",
    description: "Kiến thức hoàn toàn mới trong GDPT 2018: Định nghĩa xác suất có điều kiện, biến cố độc lập, sơ đồ hình cây, công thức xác suất toàn phần và công thức Bayes.",
    link: "https://toanmath.com/xac-suat-co-dieu-kien-11",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Toán 11", "Xác suất", "Xác suất có điều kiện", "Công thức toàn phần", "Công thức Bayes", "Chương trình mới 2025"],
    downloads: 19100,
    featured: true,
    studyContent: {
        summary: "Nội dung trọng điểm xuất hiện chắc chắn trong đề thi tốt nghiệp THPT năm 2025 theo chuẩn Bộ GD&ĐT. Áp dụng giải các bài toán thực tiễn về xác suất y học, xác suất kiểm tra chất lượng linh kiện công nghiệp.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Xác suất có điều kiện: P(A|B) = \\frac{P(A \\cap B)}{P(B)} \\quad (P(B) > 0)",
          "Biến cố độc lập: P(A \\cap B) = P(A) \\cdot P(B)",
          "Công thức xác suất toàn phần: P(B) = P(A)P(B|A) + P(\\bar{A})P(B|\\bar{A})",
          "Công thức Bayes: P(A|B) = \\frac{P(A) \\cdot P(B|A)}{P(B)}"
        ],
        studyTips: [
          "1. Vẽ sơ đồ hình cây (Tree diagram) là cách trực quan và ít nhầm lẫn nhất khi giải bài toán xác suất toàn phần và Bayes.",
          "2. Tổng các nhánh xuất phát từ cùng một nút luôn có tổng xác suất bằng 1.",
          "3. Phân biệt P(A|B) (biết B xảy ra, tìm xác suất A) và P(B|A) (biết A xảy ra, tìm xác suất B)."
        ],
        theory: [
          { title: "Xác suất có điều kiện & Quy tắc nhân", points: ["Xác suất của biến cố A khi biết biến cố B đã xảy ra là P(A|B) = \\frac{P(A \\cap B)}{P(B)} với P(B) > 0.", "Quy tắc nhân xác suất: P(A \\cap B) = P(B) \\cdot P(A|B) = P(A) \\cdot P(B|A).", "Hai biến cố độc lập: Biến cố B xảy ra không ảnh hưởng đến xác suất xảy ra A \\Leftrightarrow P(A|B) = P(A) \\Leftrightarrow P(A \\cap B) = P(A) \\cdot P(B)."] },
          { title: "Công thức xác suất toàn phần & Công thức Bayes", points: ["Hệ biến cố đầy đủ: A_1, A_2, ..., A_n đôi một xung khắc và hợp của chúng là không gian mẫu \\Omega.", "Công thức xác suất toàn phần: P(B) = \\sum_{i=1}^n P(A_i) \\cdot P(B|A_i).", "Công thức Bayes: P(A_k|B) = \\frac{P(A_k) \\cdot P(B|A_k)}{P(B)} = \\frac{P(A_k) \\cdot P(B|A_k)}{\\sum_{i=1}^n P(A_i) \\cdot P(B|A_i)}."] }
        ],
        examples: [
          { q: "Một nhà máy có hai phân xưởng I và II sản xuất bóng đèn. Phân xưởng I sản xuất 60% tổng số sản phẩm với tỉ lệ bóng hỏng là 2%. Phân xưởng II sản xuất 40% tổng số sản phẩm với tỉ lệ bóng hỏng là 3%. Lấy ngẫu nhiên một bóng đèn từ kho, tính xác suất để bóng đèn đó bị hỏng.", a: "Gọi A_1 là biến cố bóng do phân xưởng I sản xuất: P(A_1) = 0.6.\\nGọi A_2 là biến cố bóng do phân xưởng II sản xuất: P(A_2) = 0.4.\\nGọi B là biến cố bóng đèn bị hỏng.\\nTheo đề bài: P(B|A_1) = 0.02; P(B|A_2) = 0.03.\\nÁp dụng công thức xác suất toàn phần:\\nP(B) = P(A_1)P(B|A_1) + P(A_2)P(B|A_2) = 0.6 \\times 0.02 + 0.4 \\times 0.03 = 0.012 + 0.012 = 0.024 (tức 2.4%)." }
        ]
      }
  },
  {
    id: "ly-10-01",
    subject: "ly",
    title: "Tổng Ôn Động Học Chất Điểm & Chuyển Động Biến Đổi Đều (Lớp 10)",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Thầy Vũ Ngọc Anh - Mapstudy & SGK Kết Nối Tri Thức",
    year: 2025,
    buoiHoc: "Chuyên đề 14",
    caLive: "",
    ngayLive: "",
    description: "Độ dịch chuyển, vận tốc trung bình, gia tốc, đồ thị d - t và v - t, công thức độc lập thời gian, chuyển động rơi tự do và ném xiên.",
    link: "https://mapstudy.edu.vn/vat-li-10-dong-hoc",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 10", "Động học", "Độ dịch chuyển", "Biến đổi đều", "Rơi tự do", "Đồ thị v-t"],
    downloads: 15800,
    featured: true,
    studyContent: {
        summary: "Nền tảng cơ học lớp 10. Chú trọng phân biệt quãng đường (đại lượng vô hướng luôn không âm) và độ dịch chuyển (đại lượng vectơ có thể âm, dương hoặc bằng 0).",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Vận tốc tức thời: v = v_0 + at",
          "Độ dịch chuyển: d = v_0 t + \\frac{1}{2} at^2",
          "Hệ thức độc lập thời gian: v^2 - v_0^2 = 2ad",
          "Rơi tự do (v_0 = 0): v = gt; h = \\frac{1}{2} gt^2 \\Rightarrow v = \\sqrt{2gh}; t = \\sqrt{\\frac{2h}{g}}",
          "Độ dốc đồ thị d-t cho biết vận tốc v; độ dốc đồ thị v-t cho biết gia tốc a."
        ],
        studyTips: [
          "1. Chọn hệ quy chiếu: trục tọa độ, gốc thời gian và chiều dương trước khi viết phương trình.",
          "2. Diện tích hình giới hạn dưới đồ thị v - t chính là độ dịch chuyển d của vật.",
          "3. Chậm dần đều gia tốc a mang dấu âm nếu chiều dương chọn theo chiều chuyển động."
        ],
        theory: [
          { title: "Độ dịch chuyển và Vận tốc", points: ["Độ dịch chuyển \\vec{d} là vectơ nối từ vị trí đầu đến vị trí cuối của chất điểm.", "Tốc độ trung bình v_{tb} = \\frac{s}{t} (quãng đường chia thời gian).", "Vận tốc trung bình \\vec{v}_{tb} = \\frac{\\Delta \\vec{d}}{\\Delta t}."] },
          { title: "Chuyển động thẳng biến đổi đều", points: ["Gia tốc a = \\frac{v - v_0}{t} (không đổi).", "Chuyển động nhanh dần đều: a cùng dấu với v (a \\cdot v > 0).", "Chuyển động chậm dần đều: a ngược dấu với v (a \\cdot v < 0).", "Rơi tự do là chuyển động thẳng nhanh dần đều không vận tốc đầu với gia tốc g."] }
        ],
        examples: [
          { q: "Một ô tô đang chạy với vận tốc 20 m/s thì người lái hãm phanh chuyển động chậm dần đều với gia tốc có độ lớn 2 m/s^2. Tính quãng đường ô tô đi được từ khi hãm phanh đến khi dừng hẳn.", a: "Chọn chiều dương là chiều chuyển động của ô tô.\\nVận tốc ban đầu v_0 = 20 m/s.\\nKhi dừng lại v = 0 m/s.\\nDo ô tô chuyển động chậm dần đều nên a = -2 m/s^2.\\nÁp dụng hệ thức độc lập với thời gian:\\nv^2 - v_0^2 = 2ad \\Rightarrow 0^2 - 20^2 = 2(-2)d \\Rightarrow -400 = -4d \\Rightarrow d = 100 m.\\nVì xe chuyển động theo một chiều nên quãng đường s = d = 100 m." }
        ]
      }
  },
  {
    id: "ly-10-02",
    subject: "ly",
    title: "Động Lực Học: 3 Định Luật Newton, Các Lực Cơ Học & Bảo Toàn Cơ Năng",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Thư Viện Vật Lí & Thầy Vũ Ngọc Anh",
    year: 2025,
    buoiHoc: "Chuyên đề 15",
    caLive: "",
    ngayLive: "",
    description: "Ba định luật Newton, trọng lực, lực ma sát, lực căng, công cơ học, công suất, định lý động năng và định luật bảo toàn cơ năng trong trọng trường.",
    link: "https://thuvienvatly.com/vat-li-10-dong-luc-hoc",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 10", "Định luật Newton", "Lực ma sát", "Công", "Công suất", "Bảo toàn cơ năng"],
    downloads: 16900,
    featured: true,
    studyContent: {
        summary: "Cốt lõi của cơ học cổ điển. Phân tích lực tác dụng lên vật bằng định luật II Newton và áp dụng định luật bảo toàn cơ năng để giải nhanh các bài toán vận tốc và độ cao.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Định luật II Newton: \\sum \\vec{F} = m\\vec{a}",
          "Lực ma sát trượt: F_{mst} = \\mu N",
          "Công cơ học: A = F \\cdot s \\cdot \\cos \\alpha; \\quad \\text{Công suất: } \\mathcal{P} = \\frac{A}{t} = F \\cdot v",
          "Động năng: W_d = \\frac{1}{2}mv^2; \\quad \\text{Thế năng: } W_t = mgh",
          "Bảo toàn cơ năng: W = \\frac{1}{2}mv^2 + mgh = \\text{const}",
          "Độ biến thiên cơ năng bằng công lực cản/ma sát: W_2 - W_1 = A_{F_{ms}}"
        ],
        studyTips: [
          "1. Luôn vẽ hình phân tích các lực tác dụng lên vật trước khi chiếu lên các trục tọa độ Ox, Oy.",
          "2. Lực ma sát trượt tỉ lệ với áp lực N, chú ý tính đúng N trên mặt phẳng nghiêng: N = mg \\cos \\alpha.",
          "3. Nếu có ma sát thì cơ năng KHÔNG bảo toàn, lúc đó dùng: W_sau - W_truoc = A_ms."
        ],
        theory: [
          { title: "Ba định luật Newton", points: ["Định luật I (Quán tính): Vật giữ nguyên trạng thái đứng yên hoặc chuyển động thẳng đều khi không chịu lực tác dụng hoặc hợp lực bằng 0.", "Định luật II: Gia tốc của một vật tỉ lệ thuận với lực tác dụng và tỉ lệ nghịch với khối lượng: \\vec{a} = \\frac{\\vec{F}}{m} \\Leftrightarrow \\vec{F} = m\\vec{a}.", "Định luật III: Tác dụng và phản tác dụng xuất hiện đồng thời, cùng phương, ngược chiều, cùng độ lớn và đặt vào hai vật khác nhau."] },
          { title: "Công, Công suất & Bảo toàn cơ năng", points: ["Công cơ học A = F s \\cos \\alpha (\\alpha là góc hợp bởi \\vec{F} và \\vec{s}).", "Định lý động năng: W_{d2} - W_{d1} = A_{ngoai luc}.", "Định luật bảo toàn cơ năng: Khi vật chỉ chịu tác dụng của lực thế (trọng lực, lực đàn hồi), cơ năng W = W_d + W_t không đổi theo thời gian."] }
        ],
        examples: [
          { q: "Một vật khối lượng m = 2 kg được thả rơi tự do từ độ cao h = 20 m so với mặt đất. Lấy g = 10 m/s^2. Bỏ qua sức cản không khí. Tính vận tốc của vật khi chạm đất.", a: "Chọn gốc thế năng tại mặt đất.\\nTại vị trí thả, vật có cơ năng:\\nW_1 = mgh = 2 \\times 10 \\times 20 = 400 J (do v_1 = 0 nên W_{d1} = 0).\\nKhi chạm đất, độ cao h_2 = 0 nên W_{t2} = 0, cơ năng là:\\nW_2 = \\frac{1}{2} m v_2^2 = \\frac{1}{2} \\times 2 \\times v_2^2 = v_2^2.\\nÁp dụng định luật bảo toàn cơ năng (bỏ qua sức cản):\\nW_2 = W_1 \\Rightarrow v_2^2 = 400 \\Rightarrow v_2 = \\sqrt{400} = 20 m/s." }
        ]
      }
  },
  {
    id: "ly-10-03",
    subject: "ly",
    title: "Chuyên Đề Cân Bằng Lực, Moment Lực & Quy Tắc Cánh Tay Đòn",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Khoa Vật Lí ĐH Sư Phạm Hà Nội & VietJack",
    year: 2025,
    buoiHoc: "Chuyên đề 16",
    caLive: "",
    ngayLive: "",
    description: "Điều kiện cân bằng chất điểm, quy tắc moment lực M = F.d, ngẫu lực, xác định trọng tâm và điều kiện cân bằng của vật rắn có trục quay cố định.",
    link: "https://thuvienvatly.com/vat-li-10-moment-luc",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 10", "Cân bằng lực", "Moment lực", "Cánh tay đòn", "Ngẫu lực", "Vật rắn"],
    downloads: 14300,
    featured: false,
    studyContent: {
        summary: "Cung cấp phương pháp giải các bài toán kỹ thuật thực tế: cần cẩu nâng tải trọng, cân đòn, xà beng bẩy đá và xác định vị trí đặt trục quay để giảm thiểu lực tác dụng.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Moment lực: M = F \\cdot d \\quad (N \\cdot m)",
          "Quy tắc moment: \\sum M_{\\text{thuận}} = \\sum M_{\\text{nghịch}}",
          "Moment của ngẫu lực: M = F \\cdot d \\quad (\\text{d là khoảng cách giữa 2 giá lực})",
          "Hợp lực của hai lực song song cùng chiều: F = F_1 + F_2; \\quad \\frac{F_1}{F_2} = \\frac{d_2}{d_1}"
        ],
        studyTips: [
          "1. Sai lầm phổ biến nhất là lấy độ dài của thanh làm cánh tay đòn. Phải hạ đường vuông góc từ trục quay đến đường chứa vectơ lực.",
          "2. Lực nào có giá đi qua trục quay thì cánh tay đòn d = 0 và moment lực bằng 0.",
          "3. Chọn trục quay đi qua điểm đặt của lực chưa biết để triệt tiêu moment của lực đó."
        ],
        theory: [
          { title: "Moment lực & Cánh tay đòn", points: ["Moment lực đối với trục quay là đại lượng đặc trưng cho tác dụng làm quay của lực: M = F \\cdot d.", "Cánh tay đòn d là khoảng cách vuông góc từ trục quay đến giá của lực (không phải khoảng cách từ trục quay đến điểm đặt của lực).", "Đơn vị của moment lực là N.m (Newton mét)."] },
          { title: "Quy tắc moment lực (Điều kiện cân bằng vật có trục quay)", points: ["Muốn cho một vật có trục quay cố định ở trạng thái cân bằng, tổng các moment lực có xu hướng làm vật quay theo chiều kim đồng hồ phải bằng tổng các moment lực có xu hướng làm vật quay ngược chiều kim đồng hồ.", "Ngẫu lực: Hệ hai lực song song, ngược chiều, có độ lớn bằng nhau và cùng tác dụng vào một vật. Moment của ngẫu lực M = F \\cdot d (với d là khoảng cách giữa hai giá của lực)."] }
        ],
        examples: [
          { q: "Một thanh AB đồng chất tiết diện đều dài 2 m, khối lượng 4 kg có thể quay quanh trục nằm ngang qua điểm O cách đầu A một khoảng 0.5 m. Tại đầu A treo một vật có khối lượng m_A. Tìm m_A để thanh cân bằng nằm ngang. Lấy g = 10 m/s^2.", a: "Thanh đồng chất nên trọng tâm G nằm ở chính giữa thanh: AG = 1 m.\\nTrục quay O cách A 0.5 m \\Rightarrow OG = AG - AO = 1 - 0.5 = 0.5 m.\\nTrọng lực của thanh P = mg = 4 \\times 10 = 40 N đặt tại G có xu hướng làm thanh quay cùng chiều kim đồng hồ quanh O.\\nLực căng dây do vật m_A tác dụng tại A là P_A = m_A \\cdot g có xu hướng làm thanh quay ngược chiều kim đồng hồ quanh O.\\nÁp dụng quy tắc moment quanh trục O:\\nP_A \\cdot OA = P \\cdot OG\\n\\Leftrightarrow (m_A \\times 10) \\times 0.5 = 40 \\times 0.5\\n\\Leftrightarrow 5 m_A = 20 \\Rightarrow m_A = 4 kg." }
        ]
      }
  },
  {
    id: "ly-10-04",
    subject: "ly",
    title: "Động Lượng, Xung Lượng Của Lực & Định Luật Bảo Toàn Động Lượng",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Thầy Vũ Ngọc Anh - Mapstudy",
    year: 2025,
    buoiHoc: "Chuyên đề 17",
    caLive: "",
    ngayLive: "",
    description: "Vectơ động lượng p = mv, xung lượng của lực F.delta t, định luật bảo toàn động lượng trong hệ kín, va chạm mềm, va chạm đàn hồi và chuyển động bằng phản lực.",
    link: "https://mapstudy.edu.vn/vat-li-10-dong-luong",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 10", "Động lượng", "Xung lượng", "Bảo toàn động lượng", "Va chạm mềm", "Phản lực"],
    downloads: 15400,
    featured: false,
    studyContent: {
        summary: "Phương pháp giải quyết va chạm tức thời không cần quan tâm đến chi tiết lực tương tác phức tạp trong thời gian va chạm. Trọng tâm bài toán tên lửa đẩy và giật lùi của súng pháo.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Động lượng: \\vec{p} = m\\vec{v}",
          "Độ biến thiên động lượng: \\Delta \\vec{p} = \\vec{F} \\Delta t",
          "Bảo toàn động lượng hệ kín: \\sum \\vec{p}_{\\text{trước}} = \\sum \\vec{p}_{\\text{sau}}",
          "Vận tốc va chạm mềm: \\vec{V} = \\frac{m_1 \\vec{v}_1 + m_2 \\vec{v}_2}{m_1 + m_2}",
          "Chuyển động bằng phản lực: \\vec{V} = -\\frac{m}{M}\\vec{v}"
        ],
        studyTips: [
          "1. Động lượng là đại lượng VECTƠ, khi viết phương trình vô hướng BẮT BUỘC phải chiếu lên chiều dương đã chọn.",
          "2. Trong va chạm mềm: Động lượng bảo toàn nhưng Động năng KHÔNG bảo toàn (một phần cơ năng chuyển thành nhiệt năng).",
          "3. Chú ý vận tốc phụt khí phải tính đối với hệ quy chiếu gắn với mặt đất."
        ],
        theory: [
          { title: "Động lượng & Xung lượng của lực", points: ["Động lượng là đại lượng vectơ xác định bởi tích khối lượng và vận tốc: \\vec{p} = m\\vec{v} (đơn vị kg.m/s).", "Độ biến thiên động lượng bằng xung lượng của tổng ngoại lực: \\Delta \\vec{p} = \\vec{p}_2 - \\vec{p}_1 = \\vec{F} \\Delta t."] },
          { title: "Định luật bảo toàn động lượng", points: ["Trong một hệ cô lập (kín), tổng động lượng của hệ được bảo toàn: \\vec{p}_1 + \\vec{p}_2 + ... = \\text{const}.", "Va chạm mềm: Sau va chạm hai vật dính vào nhau và chuyển động cùng vận tốc \\vec{V} = \\frac{m_1 \\vec{v}_1 + m_2 \\vec{v}_2}{m_1 + m_2}.", "Chuyển động bằng phản lực: Ban đầu đứng yên, khi một phần khối lượng m phụt ra với vận tốc \\vec{v} thì thân tàu M chuyển động giật lùi với \\vec{V} = -\\frac{m}{M}\\vec{v}."] }
        ],
        examples: [
          { q: "Một khẩu đại bác khối lượng M = 1000 kg bắn một viên đạn khối lượng m = 10 kg theo phương ngang với vận tốc v = 500 m/s. Bỏ qua ma sát giữa súng và mặt đất. Tính vận tốc giật lùi của súng sau khi bắn.", a: "Chọn chiều dương là chiều chuyển động của viên đạn.\\nTrước khi bắn, hệ súng và đạn đứng yên nên tổng động lượng: p_0 = 0.\\nSau khi bắn, viên đạn bay với vận tốc v = 500 m/s, súng giật lùi với vận tốc V.\\nÁp dụng định luật bảo toàn động lượng:\\n0 = M \\cdot V + m \\cdot v\\n\\Rightarrow V = -\\frac{m \\cdot v}{M} = -\\frac{10 \\times 500}{1000} = -5 m/s.\\nDấu âm chứng tỏ súng giật lùi ngược chiều bay của đạn với độ lớn vận tốc 5 m/s." }
        ]
      }
  },
  {
    id: "ly-10-05",
    subject: "ly",
    title: "Chuyển Động Tròn Đều, Lực Hướng Tâm & Biến Dạng Của Vật Rắn",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Tổ Vật Lí THPT Chuyên KHTN & VietJack",
    year: 2025,
    buoiHoc: "Chuyên đề 18",
    caLive: "",
    ngayLive: "",
    description: "Tốc độ góc, gia tốc hướng tâm a = v^2/r, bản chất lực hướng tâm (lực ma sát nghỉ, góc nghiêng của đường cua) và định luật Hooke về biến dạng lò xo.",
    link: "https://thuvienvatly.com/vat-li-10-chuyen-dong-tron",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 10", "Chuyển động tròn", "Gia tốc hướng tâm", "Lực hướng tâm", "Định luật Hooke", "Lực đàn hồi"],
    downloads: 14100,
    featured: false,
    studyContent: {
        summary: "Giải thích hiện tượng vật lí thực tế quen thuộc: tại sao các khúc cua đường cao tốc phải làm mặt đường nghiêng vào trong, chuyển động của vệ tinh quanh Trái Đất và tính độ giãn của lò xo.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Tốc độ dài: v = \\omega \\cdot r; \\quad \\text{Chu kì: } T = \\frac{2\\pi}{\\omega}; \\quad \\text{Tần số: } f = \\frac{1}{T}",
          "Gia tốc hướng tâm: a_{ht} = \\frac{v^2}{r} = \\omega^2 r",
          "Lực hướng tâm: F_{ht} = m \\frac{v^2}{r} = m \\omega^2 r",
          "Định luật Hooke: F_{dh} = k |\\Delta l| = k |l - l_0|",
          "Góc nghiêng đường cua không trượt: \\tan \\theta = \\frac{v^2}{g \\cdot r}"
        ],
        studyTips: [
          "1. Chú ý: Lực hướng tâm luôn hướng vào tâm quỹ đạo tròn và vuông góc với vectơ vận tốc tức thời.",
          "2. Khi làm bài lò xo treo thẳng đứng, tại vị trí cân bằng: mg = k \\Delta l_0 \\Rightarrow \\Delta l_0 = \\frac{mg}{k}.",
          "3. Tốc độ góc kim giờ là \\omega_h = \\frac{2\\pi}{12 \\times 3600} rad/s, kim phút là \\omega_m = \\frac{2\\pi}{3600} rad/s."
        ],
        theory: [
          { title: "Chuyển động tròn đều & Gia tốc hướng tâm", points: ["Tốc độ góc \\omega = \\frac{\\Delta \\theta}{\\Delta t} (rad/s), liên hệ tốc độ dài v = \\omega \\cdot r.", "Chu kì T = \\frac{2\\pi}{\\omega}, tần số f = \\frac{1}{T} = \\frac{\\omega}{2\\pi}.", "Gia tốc hướng tâm đặc trưng cho sự thay đổi về hướng của vectơ vận tốc: a_{ht} = \\frac{v^2}{r} = \\omega^2 r."] },
          { title: "Lực hướng tâm & Định luật Hooke", points: ["Lực hướng tâm không phải là loại lực mới mà là hợp lực của các lực thực tế đóng vai trò giữ cho vật chuyển động tròn: F_{ht} = m a_{ht} = m \\frac{v^2}{r}.", "Biến dạng đàn hồi tuân theo định luật Hooke: Độ lớn lực đàn hồi của lò xo tỉ lệ thuận với độ biến dạng |\\Delta l| của lò xo: F_{dh} = k |\\Delta l|."] }
        ],
        examples: [
          { q: "Một ô tô có khối lượng 1500 kg đi qua một đoạn đường cong bán kính r = 50 m với tốc độ 36 km/h. Tính độ lớn lực hướng tâm cần thiết để giữ xe chạy an toàn trên quỹ đạo cong này.", a: "Đổi tốc độ sang m/s: v = \\frac{36}{3.6} = 10 m/s.\\nÁp dụng công thức lực hướng tâm:\\nF_{ht} = m \\frac{v^2}{r} = 1500 \\times \\frac{10^2}{50} = 1500 \\times \\frac{100}{50} = 1500 \\times 2 = 3000 N.\\nLực này do lực ma sát nghỉ giữa bánh xe và mặt đường cung cấp." }
        ]
      }
  },
  {
    id: "ly-11-01",
    subject: "ly",
    title: "Chuyên Đề Toàn Diện Dao Động Điều Hòa & Sóng Cơ Học (Lớp 11)",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thầy Vũ Ngọc Anh - Mapstudy & VietJack",
    year: 2025,
    buoiHoc: "Chuyên đề 19",
    caLive: "",
    ngayLive: "",
    description: "Phương trình dao động li độ, vận tốc, gia tốc, động năng, thế năng, con lắc lò xo, con lắc đơn, giao thoa sóng cơ và sóng dừng.",
    link: "https://mapstudy.edu.vn/vat-li-11-dao-dong-song",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 11", "Dao động điều hòa", "Con lắc lò xo", "Sóng cơ", "Giao thoa sóng", "Sóng dừng"],
    downloads: 19800,
    featured: true,
    studyContent: {
        summary: "Chương chiếm tỉ trọng lớn nhất trong đề thi THPT Quốc Gia mọi năm. Nắm chắc vòng tròn lượng giác để tìm thời gian, quãng đường và các vị trí cực đại cực tiểu giao thoa sóng.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Li độ: x = A \\cos(\\omega t + \\varphi); \\quad v_{\\max} = \\omega A; \\quad a_{\\max} = \\omega^2 A",
          "Hệ thức độc lập: x^2 + \\frac{v^2}{\\omega^2} = A^2",
          "Con lắc lò xo: \\omega = \\sqrt{\\frac{k}{m}}; \\quad T = 2\\pi\\sqrt{\\frac{m}{k}}",
          "Con lắc đơn: \\omega = \\sqrt{\\frac{g}{l}}; \\quad T = 2\\pi\\sqrt{\\frac{l}{g}}",
          "Bước sóng: \\lambda = \\frac{v}{f} = v \\cdot T",
          "Khoảng cách giữa hai cực đại liên tiếp trên đoạn nối hai nguồn: \\frac{\\lambda}{2}"
        ],
        studyTips: [
          "1. Dùng Vòng tròn lượng giác (pha dao động) để tìm thời gian ngắn nhất đi từ x_1 đến x_2.",
          "2. Động năng và thế năng biến thiên tuần hoàn với tần số f' = 2f, chu kì T' = T/2.",
          "3. Khi sóng truyền từ môi trường này sang môi trường khác: Tần số f KHÔNG ĐỔI, chỉ có tốc độ v và bước sóng \\lambda thay đổi."
        ],
        theory: [
          { title: "Dao động điều hòa", points: ["Phương trình li độ: x = A \\cos(\\omega t + \\varphi). Vận tốc v = -\\omega A \\sin(\\omega t + \\varphi) sớm pha \\pi/2 so với x.", "Gia tốc a = -\\omega^2 x sớm pha \\pi so với x (ngược pha).", "Hệ thức độc lập thời gian: x^2 + \\frac{v^2}{\\omega^2} = A^2; \\quad a^2 + \\omega^2 v^2 = \\omega^4 A^2.", "Động năng W_d = \\frac{1}{2}mv^2, Thế năng W_t = \\frac{1}{2}kx^2, Cơ năng W = \\frac{1}{2}kA^2 = \\text{const}."] },
          { title: "Sóng cơ & Giao thoa sóng", points: ["Bước sóng \\lambda = v \\cdot T = \\frac{v}{f} là quãng đường sóng truyền đi trong 1 chu kì.", "Giao thoa 2 nguồn cùng pha: Cực đại khi d_2 - d_1 = k\\lambda; Cực tiểu khi d_2 - d_1 = (k + 0.5)\\lambda.", "Sóng dừng với hai đầu cố định: Chiều dài dây L = k \\frac{\\lambda}{2} (k bụng sóng, k + 1 nút sóng)."] }
        ],
        examples: [
          { q: "Một chất điểm dao động điều hòa với biên độ A = 5 cm và chu kì T = 2 s. Tính tốc độ cực đại của chất điểm.", a: "Tần số góc của dao động:\\n\\omega = \\frac{2\\pi}{T} = \\frac{2\\pi}{2} = \\pi \\text{ rad/s}.\\nTốc độ cực đại đạt được khi chất điểm đi qua vị trí cân bằng:\\nv_{\\max} = \\omega A = \\pi \\times 5 = 5\\pi \\approx 15.7 \\text{ cm/s}." }
        ]
      }
  },
  {
    id: "ly-11-02",
    subject: "ly",
    title: "Điện Trường, Điện Thế, Định Luật Ohm Toàn Mạch & Hiện Tượng Cảm Ứng Điện Từ",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thư Viện Vật Lí & Mapstudy",
    year: 2025,
    buoiHoc: "Chuyên đề 20",
    caLive: "",
    ngayLive: "",
    description: "Lực tương tác Coulomb, cường độ điện trường, công lực điện và hiệu điện thế, định luật cảm ứng Faraday, định luật Lenz xác định chiều dòng điện cảm ứng.",
    link: "https://thuvienvatly.com/vat-li-11-dien-truong",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 11", "Điện trường", "Điện thế", "Từ thông", "Cảm ứng điện từ", "Định luật Lenz"],
    downloads: 17600,
    featured: true,
    studyContent: {
        summary: "Các hiện tượng điện - từ trường vi mô và vĩ mô. Hiểu rõ nguyên lý cảm ứng điện từ là nền tảng cho máy biến áp, máy phát điện xoay chiều và động cơ điện.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Lực Coulomb: F = 9 \\times 10^9 \\frac{|q_1 q_2|}{\\varepsilon r^2}",
          "Cường độ điện trường: E = \\frac{F}{|q|} = \\frac{U}{d}",
          "Công lực điện: A_{MN} = q U_{MN} = q(V_M - V_N)",
          "Từ thông: \\Phi = B S \\cos(\\vec{n}, \\vec{B}) \\quad (\\text{Wb})",
          "Suất điện động cảm ứng: |e_c| = |\\frac{\\Delta \\Phi}{\\Delta t}|"
        ],
        studyTips: [
          "1. Chú ý góc \\alpha trong công thức từ thông là góc giữa \\vec{B} và PHÁP TUYẾN \\vec{n} của mặt phẳng khung dây, không phải góc giữa \\vec{B} và mặt phẳng khung.",
          "2. Nếu từ thông tăng \\Rightarrow từ trường cảm ứng \\vec{B}_c ngược chiều \\vec{B} ngoài. Nếu từ thông giảm \\Rightarrow \\vec{B}_c cùng chiều \\vec{B} ngoài.",
          "3. Chiều dòng điện tuân theo quy tắc nắm tay phải."
        ],
        theory: [
          { title: "Điện trường & Hiệu điện thế", points: ["Định luật Coulomb: F = k \\frac{|q_1 q_2|}{\\varepsilon r^2} với k = 9 \\times 10^9 N.m^2/C^2.", "Cường độ điện trường gây bởi điện tích điểm Q: E = k \\frac{|Q|}{\\varepsilon r^2}.", "Công của lực điện trường không phụ thuộc hình dạng đường đi, chỉ phụ thuộc vị trí đầu và cuối: A = q E d = q U_{MN}."] },
          { title: "Từ thông & Cảm ứng điện từ", points: ["Từ thông qua mạch kín diện tích S: \\Phi = B S \\cos \\alpha (\\alpha là góc hợp bởi vectơ pháp tuyến \\vec{n} và \\vec{B}).", "Định luật cảm ứng Faraday: Suất điện động cảm ứng tỉ lệ với tốc độ biến thiên từ thông: e_c = -\\frac{\\Delta \\Phi}{\\Delta t}.", "Định luật Lenz: Dòng điện cảm ứng có chiều sao cho từ trường do nó sinh ra có tác dụng chống lại sự biến thiên của từ thông ban đầu sinh ra nó."] }
        ],
        examples: [
          { q: "Một khung dây phẳng có diện tích S = 100 cm^2 đặt trong từ trường đều có cảm ứng từ B = 0.05 T. Vectơ cảm ứng từ hợp với mặt phẳng khung dây một góc 30^\\circ. Tính từ thông qua khung dây.", a: "Đổi diện tích: S = 100 cm^2 = 100 \\times 10^{-4} m^2 = 0.01 m^2.\\nVectơ cảm ứng từ hợp với mặt phẳng khung dây góc 30^\\circ nên góc hợp với pháp tuyến \\vec{n} là:\\n\\alpha = 90^\\circ - 30^\\circ = 60^\\circ.\\nÁp dụng công thức tính từ thông:\\n\\Phi = B \\cdot S \\cdot \\cos \\alpha = 0.05 \\times 0.01 \\times \\cos 60^\\circ = 0.0005 \\times 0.5 = 2.5 \\times 10^{-4} \\text{ Wb}." }
        ]
      }
  },
  {
    id: "ly-11-03",
    subject: "ly",
    title: "Chuyên Đề Sóng Ánh Sáng: Hiện Tượng Tán Sắc & Giao Thoa Khe Young",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thầy Vũ Ngọc Anh - Mapstudy & Tổ Vật Lí Chuyên Sư Phạm",
    year: 2025,
    buoiHoc: "Chuyên đề 21",
    caLive: "",
    ngayLive: "",
    description: "Bản chất sóng của ánh sáng, hiện tượng tán sắc qua lăng kính, thí nghiệm giao thoa ánh sáng Young, xác định bước sóng ánh sáng và bề rộng quang phổ.",
    link: "https://mapstudy.edu.vn/vat-li-11-song-anh-sang",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 11", "Sóng ánh sáng", "Tán sắc ánh sáng", "Giao thoa Young", "Khoảng vân", "Quang phổ"],
    downloads: 16500,
    featured: false,
    studyContent: {
        summary: "Bằng chứng thực nghiệm khẳng định ánh sáng có tính chất sóng. Dạng bài toán tính khoảng vân, vị trí trùng nhau của 2 hoặc 3 bức xạ đơn sắc trong đề thi tốt nghiệp.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Khoảng vân: i = \\frac{\\lambda D}{a}",
          "Vị trí vân sáng: x_s = k \\cdot i \\quad (k = 0, \\pm 1, \\pm 2, ...)",
          "Vị trí vân tối: x_t = (k + 0.5) \\cdot i \\quad (k = 0, \\pm 1, \\pm 2, ...)",
          "Bề rộng quang phổ bậc k (ánh sáng trắng): \\Delta x_k = x_{s(tím)} - x_{s(đỏ)} = k \\frac{(\\lambda_{đỏ} - \\lambda_{tím}) D}{a}",
          "Điều kiện trùng nhau của 2 bức xạ: x_1 = x_2 \\Leftrightarrow k_1 \\lambda_1 = k_2 \\lambda_2"
        ],
        studyTips: [
          "1. Chú ý đổi đồng nhất đơn vị: a (mm), D (m), \\lambda (\\mu m) thì khoảng vân i sẽ tự động ra mm.",
          "2. Vân sáng bậc k: k nhận giá trị nguyên. Vân tối thứ 1 ứng với k = 0 hoặc k = -1.",
          "3. Bề rộng trường giao thoa L chứa số vân sáng: N_s = 2 \\left[\\frac{L}{2i}\\right] + 1."
        ],
        theory: [
          { title: "Hiện tượng tán sắc ánh sáng", points: ["Ánh sáng đơn sắc là ánh sáng có một màu nhất định và không bị tán sắc khi truyền qua lăng kính.", "Ánh sáng trắng là hỗn hợp của vô số ánh sáng đơn sắc có màu biến thiên liên tục từ đỏ đến tím.", "Chiết suất của môi trường trong suốt phụ thuộc vào bước sóng ánh sáng: n_{đỏ} < n_{cam} < ... < n_{tím} \\Rightarrow Góc lệch D_{đỏ} < D_{tím}."] },
          { title: "Giao thoa ánh sáng khe Young", points: ["Khoảng vân i là khoảng cách giữa hai vân sáng (hoặc hai vân tối) liên tiếp: i = \\frac{\\lambda D}{a}.", "Vị trí vân sáng bậc k: x_s = k \\cdot i = k \\frac{\\lambda D}{a} (k \\in \\mathbb{Z}).", "Vị trí vân tối thứ k: x_t = (k - 0.5) \\cdot i = (k - 0.5) \\frac{\\lambda D}{a}."] }
        ],
        examples: [
          { q: "Trong thí nghiệm Young về giao thoa ánh sáng, khoảng cách giữa hai khe là a = 1 mm, khoảng cách từ mặt phẳng chứa hai khe đến màn là D = 2 m. Chiếu ánh sáng đơn sắc có bước sóng \\lambda = 0.5 \\mu m. Tính khoảng vân và khoảng cách từ vân sáng trung tâm đến vân sáng bậc 4.", a: "Khoảng vân giao thoa:\\ni = \\frac{\\lambda D}{a} = \\frac{0.5 \\times 2}{1} = 1 \\text{ mm}.\\nKhoảng cách từ vân sáng trung tâm (k = 0) đến vân sáng bậc 4 (k = 4) là:\\nx_4 = 4 \\times i = 4 \\times 1 = 4 \\text{ mm}." }
        ]
      }
  },
  {
    id: "ly-11-04",
    subject: "ly",
    title: "Tụ Điện, Điện Dung, Ghép Bộ Tụ & Năng Lượng Điện Trường",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Khoa Vật Lí ĐH Sư Phạm Hà Nội & Thư Viện Vật Lí",
    year: 2025,
    buoiHoc: "Chuyên đề 22",
    caLive: "",
    ngayLive: "",
    description: "Cấu tạo tụ điện, định nghĩa điện dung C = Q/U, ghép tụ nối tiếp và song song, năng lượng điện trường dự trữ và ứng dụng của tụ trong mạch điện tử tử.",
    link: "https://thuvienvatly.com/vat-li-11-tu-dien",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 11", "Tụ điện", "Điện dung", "Ghép tụ", "Năng lượng điện trường"],
    downloads: 14900,
    featured: false,
    studyContent: {
        summary: "Linh kiện tích trữ và phóng điện căn bản trong kỹ thuật điện tử. Hiểu rõ quy tắc cộng điện tích khi ghép song song và phân bố hiệu điện thế khi ghép nối tiếp.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Điện dung: C = \\frac{Q}{U} \\quad (1 \\mu\\text{F} = 10^{-6}\\text{F}, 1\\text{pF} = 10^{-12}\\text{F})",
          "Ghép song song: C_b = C_1 + C_2 + ... + C_n",
          "Ghép nối tiếp: \\frac{1}{C_b} = \\frac{1}{C_1} + \\frac{1}{C_2} + ... + \\frac{1}{C_n}",
          "Năng lượng điện trường: W = \\frac{1}{2} C U^2 = \\frac{Q^2}{2C} = \\frac{1}{2} Q U"
        ],
        studyTips: [
          "1. Chú ý: Điện dung C không phụ thuộc vào điện tích Q hay hiệu điện thế U (nó chỉ phụ thuộc vào cấu tạo hình học của tụ).",
          "2. Công thức ghép tụ NGƯỢC LẠI hoàn toàn so với công thức ghép điện trở R (tụ ghép song song thì cộng, ghép nối tiếp thì nghịch đảo).",
          "3. Khi ngắt tụ khỏi nguồn điện thì điện tích Q không đổi; khi tụ vẫn nối với nguồn thì hiệu điện thế U không đổi."
        ],
        theory: [
          { title: "Điện dung của tụ điện", points: ["Tụ điện là một hệ hai vật dẫn đặt gần nhau và ngăn cách nhau bằng một lớp cách điện (điện môi).", "Điện dung đặc trưng cho khả năng tích điện của tụ ở một hiệu điện thế nhất định: C = \\frac{Q}{U} (đơn vị Farad, F).", "Tụ điện phẳng: C = \\frac{\\varepsilon S}{9 \\times 10^9 \\cdot 4\\pi d} (với S là diện tích đối diện, d là khoảng cách giữa 2 bản)."] },
          { title: "Ghép tụ điện & Năng lượng tích trữ", points: ["Ghép song song: Hiệu điện thế bằng nhau U = U_1 = U_2; Điện dung tương đương C_b = C_1 + C_2.", "Ghép nối tiếp: Điện tích bằng nhau Q = Q_1 = Q_2; \\frac{1}{C_b} = \\frac{1}{C_1} + \\frac{1}{C_2}.", "Năng lượng điện trường dự trữ trong tụ: W = \\frac{1}{2} C U^2 = \\frac{Q^2}{2C} = \\frac{1}{2} Q U."] }
        ],
        examples: [
          { q: "Một tụ điện có điện dung C = 20 \\mu F được tích điện dưới hiệu điện thế U = 100 V. Tính điện tích và năng lượng điện trường dự trữ trong tụ điện.", a: "Đổi điện dung: C = 20 \\mu F = 20 \\times 10^{-6} F.\\nĐiện tích của tụ điện:\\nQ = C \\cdot U = 20 \\times 10^{-6} \\times 100 = 2 \\times 10^{-3} \\text{ C} = 2 \\text{ mC}.\\nNăng lượng điện trường dự trữ trong tụ:\\nW = \\frac{1}{2} C U^2 = \\frac{1}{2} \\times (20 \\times 10^{-6}) \\times 100^2 = 10 \\times 10^{-6} \\times 10000 = 0.1 \\text{ J}." }
        ]
      }
  },
  {
    id: "ly-11-05",
    subject: "ly",
    title: "Dòng Điện Trong Mạch, Công & Công Suất Nguồn Điện, Định Luật Joule - Lenz",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thầy Vũ Ngọc Anh & VietJack",
    year: 2025,
    buoiHoc: "Chuyên đề 23",
    caLive: "",
    ngayLive: "",
    description: "Suất điện động và điện trở trong của nguồn, định luật Ohm toàn mạch I = E/(R+r), hiệu suất nguồn điện, định luật Joule - Lenz và bài toán cực trị công suất.",
    link: "https://mapstudy.edu.vn/vat-li-11-dinh-luat-ohm",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Vật lí 11", "Định luật Ohm", "Toàn mạch", "Suất điện động", "Công suất nguồn", "Joule-Lenz"],
    downloads: 17100,
    featured: false,
    studyContent: {
        summary: "Cốt lõi tính toán mạch điện một chiều. Trọng tâm bài toán tìm điện trở R ngoài để công suất mạch ngoài đạt giá trị cực đại và bài toán phối hợp ghép nguồn điện thành bộ.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Định luật Ohm toàn mạch: I = \\frac{\\mathcal{E}}{R_N + r}",
          "Hiệu điện thế mạch ngoài: U_N = \\mathcal{E} - I \\cdot r = I \\cdot R_N",
          "Công suất tiêu thụ mạch ngoài: \\mathcal{P}_N = I^2 R_N = \\frac{\\mathcal{E}^2 R_N}{(R_N + r)^2}",
          "Cực trị công suất: \\mathcal{P}_N đạt cực đại khi R_N = r, với \\mathcal{P}_{\\max} = \\frac{\\mathcal{E}^2}{4r}",
          "Hiệu suất nguồn điện: H = \\frac{U_N}{\\mathcal{E}} \\times 100\\% = \\frac{R_N}{R_N + r} \\times 100\\%"
        ],
        studyTips: [
          "1. Luôn xác định xem mạch điện có bao nhiêu nguồn và cách ghép nguồn (nối tiếp, song song, hỗn hợp đối xứng).",
          "2. Đừng quên tính điện trở trong r khi tính toán dòng điện trong mạch.",
          "3. Bài toán công suất cực đại sử dụng bất đẳng thức Cauchy: (R_N + r)^2 \\ge 4 R_N r."
        ],
        theory: [
          { title: "Định luật Ohm toàn mạch & Nguồn điện", points: ["Cường độ dòng điện trong mạch kín tỉ lệ thuận với suất điện động của nguồn và tỉ lệ nghịch với tổng trở toàn mạch: I = \\frac{\\mathcal{E}}{R_N + r}.", "Hiệu điện thế mạch ngoài (độ giảm thế mạch ngoài): U_N = \\mathcal{E} - I \\cdot r = I \\cdot R_N.", "Hiện tượng đoản mạch (ngắn mạch): Khi R_N = 0 \\Rightarrow I_{dm} = \\frac{\\mathcal{E}}{r} có thể gây cháy chập nguồn."] },
          { title: "Công, Công suất & Hiệu suất", points: ["Công của nguồn điện: A_{ng} = \\mathcal{E} \\cdot I \\cdot t; Công suất nguồn: \\mathcal{P}_{ng} = \\mathcal{E} \\cdot I.", "Nhiệt lượng tỏa ra trên điện trở (Định luật Joule - Lenz): Q = R \\cdot I^2 \\cdot t.", "Hiệu suất nguồn điện: H = \\frac{U_N}{\\mathcal{E}} = \\frac{R_N}{R_N + r} \\times 100\\%."] }
        ],
        examples: [
          { q: "Một nguồn điện có suất điện động \\mathcal{E} = 12 V, điện trở trong r = 2 \\Omega được nối với một biến trở R_N thành mạch kín. Tìm giá trị của biến trở R_N để công suất tiêu thụ trên mạch ngoài đạt cực đại và tính giá trị cực đại đó.", a: "Công suất tiêu thụ ở mạch ngoài là:\\n\\mathcal{P}_N = I^2 R_N = \\left(\\frac{\\mathcal{E}}{R_N + r}\\right)^2 R_N = \\frac{\\mathcal{E}^2 R_N}{(R_N + r)^2} = \\frac{\\mathcal{E}^2}{\\left(\\sqrt{R_N} + \\frac{r}{\\sqrt{R_N}}\\right)^2}.\\nTheo bất đẳng thức Cauchy:\\n\\sqrt{R_N} + \\frac{r}{\\sqrt{R_N}} \\ge 2\\sqrt{r}.\\nDấu '=' xảy ra khi \\sqrt{R_N} = \\frac{r}{\\sqrt{R_N}} \\Leftrightarrow R_N = r = 2 \\Omega.\\nKhi đó công suất tiêu thụ mạch ngoài đạt cực đại:\\n\\mathcal{P}_{\\max} = \\frac{\\mathcal{E}^2}{4r} = \\frac{12^2}{4 \\times 2} = \\frac{144}{8} = 18 \\text{ W}." }
        ]
      }
  },
  {
    id: "hoa-10-01",
    subject: "hoa",
    title: "Tổng Ôn Cấu Tạo Nguyên Tử, Bảng Tuần Hoàn & Quy Luật Biến Đổi Tuần Hoàn",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Tổ Hóa THPT Chuyên Sư Phạm & SGK Kết Nối Tri Thức",
    year: 2025,
    buoiHoc: "Chuyên đề 24",
    caLive: "",
    ngayLive: "",
    description: "Hạt cơ bản, obitan nguyên tử s, p, d, cấu hình electron, cấu tạo bảng tuần hoàn (chu kì, nhóm), quy luật biến đổi bán kính, độ âm điện, tính kim loại - phi kim.",
    link: "https://vietjack.com/hoa-hoc-10/nguyen-tu-bang-tuan-hoan.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 10", "Nguyên tử", "Cấu hình electron", "Bảng tuần hoàn", "Độ âm điện", "Bán kính nguyên tử"],
    downloads: 15900,
    featured: true,
    studyContent: {
        summary: "Nền móng cấu trúc vi mô của toàn bộ môn Hóa học. Quy luật biến đổi tuần hoàn giúp dự đoán chính xác tính chất hóa học của các nguyên tố và hợp chất.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Số khối: A = Z + N \\quad (Z: \\text{số hiệu nguyên tử}, N: \\text{số neutron})",
          "Cấu hình e lớp ngoài cùng nhóm IA - VIIIA: ns^1 \\rightarrow ns^2 np^6",
          "Số e tối đa trong lớp thứ n: 2n^2 \\quad (với n \\le 4)",
          "Quy luật chu kì: Z \\uparrow \\Rightarrow R \\downarrow, \\chi \\uparrow, \\text{Phi kim} \\uparrow, \\text{Kim loại} \\downarrow",
          "Quy luật nhóm A: Z \\uparrow \\Rightarrow R \\uparrow, \\chi \\downarrow, \\text{Phi kim} \\downarrow, \\text{Kim loại} \\uparrow"
        ],
        studyTips: [
          "1. Chú ý cấu hình e đặc biệt bão hòa/bán bão hòa của Cr (Z=24: [Ar]3d^5 4s^1) và Cu (Z=29: [Ar]3d^{10} 4s^1).",
          "2. Nguyên tố nhóm d (kim loại chuyển tiếp): e điền vào phân lớp (n-1)d trước phân lớp ns khi viết cấu hình theo năng lượng nhưng xếp lớp thì 3d đứng trước 4s.",
          "3. Phi kim mạnh nhất là Fluorine (F, độ âm điện 3.98), kim loại mạnh nhất (không phóng xạ) là Caesium (Cs)."
        ],
        theory: [
          { title: "Cấu tạo nguyên tử & Obitan", points: ["Nguyên tử gồm hạt nhân mang điện dương (proton, neutron) và lớp vỏ electron mang điện âm.", "Số khối A = Z + N. Trong nguyên tử trung hòa: Số proton = Số electron = Z.", "Obitan nguyên tử (AO) là khu vực không gian có xác suất tìm thấy electron khoảng 90%. AO s dạng hình cầu, AO p dạng hình số 8 nổi.", "Nguyên lý Pauli (mỗi AO chứa tối đa 2 e ghép đôi ngược chiều), Nguyên lý vững bền, Quy tắc Hund (e phân bố sao cho số e độc thân là lớn nhất)."] },
          { title: "Bảng tuần hoàn & Quy luật biến đổi tuần hoàn", points: ["Số thứ tự chu kì = Số lớp electron. Số thứ tự nhóm A = Số electron hóa trị.", "Trong một chu kì theo chiều Z tăng: Bán kính nguyên tử giảm, độ âm điện tăng, năng lượng ion hóa tăng, tính kim loại giảm, tính phi kim tăng.", "Trong một nhóm A theo chiều Z tăng: Bán kính nguyên tử tăng, độ âm điện giảm, tính kim loại tăng, tính phi kim giảm."] }
        ],
        examples: [
          { q: "Nguyên tử nguyên tố X có số hiệu nguyên tử Z = 17. Hãy viết cấu hình electron của X và xác định vị trí của X (ô, chu kì, nhóm) trong bảng tuần hoàn.", a: "Với Z = 17, cấu hình electron của X là:\\n1s^2 2s^2 2p^6 3s^2 3p^5 hoặc viết gọn là [Ne]3s^2 3p^5.\\nVị trí của X trong bảng tuần hoàn:\\n- Ô số: 17 (do Z = 17).\\n- Chu kì: 3 (do có 3 lớp electron).\\n- Nhóm: VIIA (do có 7 electron hóa trị ở lớp ngoài cùng 3s^2 3p^5 và electron cuối cùng điền vào phân lớp p).\\nNguyên tố X là Chlorine (Cl), một phi kim điển hình." }
        ]
      }
  },
  {
    id: "hoa-10-02",
    subject: "hoa",
    title: "Phản Ứng Oxi Hóa - Khử & Năng Lượng Hóa Học (Enthalpy Chuẩn)",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Thầy Phạm Thắng & SGK Kết Nối Tri Thức",
    year: 2025,
    buoiHoc: "Chuyên đề 25",
    caLive: "",
    ngayLive: "",
    description: "Số oxi hóa, phương pháp thăng bằng electron, phản ứng tỏa nhiệt/thu nhiệt, biến thiên enthalpy chuẩn Delta_r H^0_298, tính theo nhiệt tạo thành chuẩn và năng lượng liên kết.",
    link: "https://vietjack.com/hoa-hoc-10/phan-ung-oxi-hoa-khu-nang-luong.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 10", "Oxi hóa khử", "Thăng bằng electron", "Enthalpy", "Nhiệt phản ứng", "Năng lượng liên kết"],
    downloads: 17400,
    featured: true,
    studyContent: {
        summary: "Phần trọng tâm của chương trình GDPT 2018. Biến thiên Enthalpy chuẩn là kiến thức mới xuất hiện xuyên suốt trong cả 3 khối 10, 11 và 12.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Định luật bảo toàn e: \\sum n_{e\\ nhường} = \\sum n_{e\\ nhận}",
          "Tính \\Delta_r H^0_{298} theo nhiệt tạo thành chuẩn: \\Delta_r H^0_{298} = \\sum \\Delta_f H^0_{298}(\\text{sản phẩm}) - \\sum \\Delta_f H^0_{298}(\\text{chất đầu})",
          "Tính \\Delta_r H^0_{298} theo năng lượng liên kết: \\Delta_r H^0_{298} = \\sum E_b(\\text{chất đầu}) - \\sum E_b(\\text{sản phẩm})",
          "Nhiệt tạo thành chuẩn của đơn chất bền nhất bằng 0: \\Delta_f H^0_{298}(\\text{đơn chất bền}) = 0"
        ],
        studyTips: [
          "1. Chú ý thứ tự trừ: Tính theo \\Delta_f H thì lấy (SẢN PHẨM - ĐẦU), còn tính theo năng lượng liên kết E_b thì lấy (ĐẦU - SẢN PHẨM).",
          "2. Đừng quên nhân hệ số tỉ lượng của từng chất trong phương trình hóa học khi tính Enthalpy.",
          "3. Nhiệt tạo thành chuẩn của O_2(g), N_2(g), H_2(g), C(graphite) bằng 0."
        ],
        theory: [
          { title: "Phản ứng oxi hóa - khử", points: ["Chất khử (chất bị oxi hóa): Là chất nhường electron, số oxi hóa tăng sau phản ứng ('Khử cho, O nhận').", "Chất oxi hóa (chất bị khử): Là chất nhận electron, số oxi hóa giảm sau phản ứng.", "Phương pháp thăng bằng electron: Tổng số electron do chất khử nhường bằng tổng số electron do chất oxi hóa nhận."] },
          { title: "Năng lượng hóa học & Biến thiên Enthalpy", points: ["Phản ứng tỏa nhiệt: Giải phóng nhiệt ra môi trường, \\Delta_r H^0_{298} < 0 (hỗn hợp phản ứng nóng lên).", "Phản ứng thu nhiệt: Hấp thụ nhiệt từ môi trường, \\Delta_r H^0_{298} > 0 (hỗn hợp phản ứng lạnh đi).", "Điều kiện chuẩn: Áp suất 1 bar, nhiệt độ 25^\\circ C (298 K), nồng độ 1 mol/L."] }
        ],
        examples: [
          { q: "Cho phản ứng nhiệt nhôm: 2Al(s) + Fe_2O_3(s) \\rightarrow 2Fe(s) + Al_2O_3(s). Cho biết nhiệt tạo thành chuẩn của Fe_2O_3(s) là -824.2 kJ/mol và của Al_2O_3(s) là -1675.7 kJ/mol. Tính biến thiên enthalpy chuẩn của phản ứng và cho biết phản ứng tỏa nhiệt hay thu nhiệt.", a: "Nhiệt tạo thành chuẩn của các đơn chất Al(s) và Fe(s) bằng 0.\\nÁp dụng công thức tính \\Delta_r H^0_{298} theo nhiệt tạo thành chuẩn:\\n\\Delta_r H^0_{298} = \\Delta_f H^0_{298}(Al_2O_3) - \\Delta_f H^0_{298}(Fe_2O_3)\\n= (-1675.7) - (-824.2) = -1675.7 + 824.2 = -851.5 kJ.\\nDo \\Delta_r H^0_{298} = -851.5 kJ < 0 nên phản ứng tỏa lượng nhiệt rất lớn (dùng để hàn đường ray xe lửa)." }
        ]
      }
  },
  {
    id: "hoa-10-03",
    subject: "hoa",
    title: "Liên Kết Hóa Học: Liên Kết Ion, Liên Kết Cộng Hóa Trị & Liên Kết Hydrogen",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Khoa Hóa ĐH Sư Phạm Hà Nội & Vietchem",
    year: 2025,
    buoiHoc: "Chuyên đề 26",
    caLive: "",
    ngayLive: "",
    description: "Quy tắc bát tử Octet, liên kết ion, liên kết cộng hóa trị phân cực/không phân cực, liên kết sigma và pi, liên kết hydrogen và tương tác Van der Waals.",
    link: "https://vietjack.com/hoa-hoc-10/lien-ket-hoa-hoc.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 10", "Liên kết ion", "Cộng hóa trị", "Liên kết hydrogen", "Van der Waals", "Quy tắc Octet"],
    downloads: 14600,
    featured: false,
    studyContent: {
        summary: "Hiểu rõ bản chất liên kết hóa học giúp giải thích vì sao nước có nhiệt độ sôi cao bất thường, tính tan của các chất và cơ chế phản ứng hữu cơ.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Hiệu độ âm điện \\Delta\\chi = |\\chi_A - \\chi_B|",
          "\\Delta\\chi < 0.4: \\text{Liên kết cộng hóa trị không phân cực}",
          "0.4 \\le \\Delta\\chi < 1.7: \\text{Liên kết cộng hóa trị phân cực}",
          "\\Delta\\chi \\ge 1.7: \\text{Liên kết ion}",
          "Liên kết đơn: gồm 1 liên kết \\sigma bền",
          "Liên kết đôi: gồm 1 liên kết \\sigma và 1 liên kết \\pi",
          "Liên kết ba: gồm 1 liên kết \\sigma và 2 liên kết \\pi"
        ],
        studyTips: [
          "1. Chú ý liên kết cho - nhận (phối trí): cặp electron dùng chung chỉ do một nguyên tử đóng góp, ký hiệu mũi tên \\rightarrow (ví dụ NH_4^+, SO_2).",
          "2. Nước H_2O có nhiệt độ sôi cao hơn H_2S rất nhiều dù H_2S nặng hơn, nguyên nhân do H_2O tạo được liên kết hydrogen liên phân tử.",
          "3. Điều kiện tạo liên kết hydrogen: Phải có H gắn trực tiếp vào F, O hoặc N."
        ],
        theory: [
          { title: "Quy tắc Octet & Các loại liên kết cơ bản", points: ["Quy tắc Octet: Nguyên tử có xu hướng nhường, nhận hoặc góp chung electron để đạt cấu hình electron bền vững giống khí hiếm (8 e lớp ngoài cùng, riêng He có 2 e).", "Liên kết ion: Hình thành do lực hút tĩnh điện giữa cation (ion dương) và anion (ion âm). Thường xảy ra giữa kim loại điển hình và phi kim điển hình (\\Delta\\chi \\ge 1.7).", "Liên kết cộng hóa trị: Hình thành do sự dùng chung một hay nhiều cặp electron giữa hai nguyên tử. Không phân cực khi \\Delta\\chi < 0.4; phân cực khi 0.4 \\le \\Delta\\chi < 1.7.", "Liên kết \\sigma (xen phủ trục) bền; Liên kết \\pi (xen phủ bên) kém bền dễ bị bẻ gãy."] },
          { title: "Liên kết Hydrogen & Tương tác Van der Waals", points: ["Liên kết hydrogen: Lực hút tĩnh điện yếu hình thành giữa nguyên tử H linh động liên kết với nguyên tử có độ âm điện lớn (F, O, N) với cặp electron tự do của nguyên tử F, O, N khác.", "Vai trò liên kết hydrogen: Làm tăng mạnh nhiệt độ sôi, nhiệt độ nóng chảy và độ tan trong nước của các chất (nước H_2O, alcohol ROH, carboxylic acid RCOOH).", "Tương tác Van der Waals: Lực hút yếu giữa các phân tử gây ra bởi lưỡng cực cảm ứng; tăng khi phân tử khối và kích thước phân tử tăng."] }
        ],
        examples: [
          { q: "Dựa vào độ âm điện: \\chi(H) = 2.20; \\chi(Cl) = 3.16; \\chi(Na) = 0.93. Xác định loại liên kết trong phân tử Cl_2, HCl và NaCl.", a: "Trong Cl_2: \\Delta\\chi = 3.16 - 3.16 = 0 < 0.4 \\Rightarrow Liên kết cộng hóa trị không phân cực.\\nTrong HCl: \\Delta\\chi = 3.16 - 2.20 = 0.96 (nằm trong khoảng 0.4 \\le \\Delta\\chi < 1.7) \\Rightarrow Liên kết cộng hóa trị phân cực.\\nTrong NaCl: \\Delta\\chi = 3.16 - 0.93 = 2.23 \\ge 1.7 \\Rightarrow Liên kết ion." }
        ]
      }
  },
  {
    id: "hoa-10-04",
    subject: "hoa",
    title: "Tốc Độ Phản Ứng Hóa Học & Các Yếu Tố Ảnh Hưởng Đến Tốc Độ Phản Ứng",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Tổ Hóa Chuyên Amsterdam & SGK Cánh Diều",
    year: 2025,
    buoiHoc: "Chuyên đề 27",
    caLive: "",
    ngayLive: "",
    description: "Tốc độ trung bình, tốc độ tức thời, định luật tác dụng khối lượng Guldberg - Waage, hệ số nhiệt độ Van't Hoff, ảnh hưởng của nồng độ, áp suất, diện tích tiếp xúc và chất xúc tác.",
    link: "https://vietjack.com/hoa-hoc-10/toc-do-phan-ung.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 10", "Tốc độ phản ứng", "Hằng số tốc độ", "Hệ số Van't Hoff", "Xúc tác", "Năng lượng hoạt hóa"],
    downloads: 15200,
    featured: false,
    studyContent: {
        summary: "Kiến thức điều khiển phản ứng trong phòng thí nghiệm và công nghiệp hóa chất. Rất hay xuất hiện trong bài toán thí nghiệm và đồ thị biến thiên nồng độ theo thời gian.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Tốc độ trung bình: \\bar{v} = \\pm \\frac{\\Delta C}{\\Delta t}",
          "Định luật tác dụng khối lượng: v = k \\cdot [A]^a [B]^b",
          "Hệ số nhiệt độ Van't Hoff: \\frac{v_2}{v_1} = \\gamma^{\\frac{T_2 - T_1}{10}}",
          "Thời gian phản ứng tỉ lệ nghịch với tốc độ: \\frac{t_1}{t_2} = \\frac{v_2}{v_1} = \\gamma^{\\frac{T_2 - T_1}{10}}"
        ],
        studyTips: [
          "1. Chú ý: Chất rắn nguyên chất không xuất hiện trong biểu thức định luật tác dụng khối lượng.",
          "2. Phân biệt rõ: Tốc độ phản ứng (v) và Hằng số cân bằng (K_c). Chất xúc tác làm tăng tốc độ đạt tới cân bằng nhưng KHÔNG làm thay đổi hằng số cân bằng K_c.",
          "3. Tăng nhiệt độ làm thời gian phản ứng GIẢM (t_2 < t_1)."
        ],
        theory: [
          { title: "Khái niệm tốc độ phản ứng", points: ["Tốc độ phản ứng hóa học là đại lượng đặc trưng cho sự biến thiên nồng độ của một trong các chất phản ứng hoặc sản phẩm trong một đơn vị thời gian.", "Biểu thức định luật tác dụng khối lượng đối với phản ứng đơn giản aA + bB \\rightarrow sản phẩm: v = k \\cdot [A]^a \\cdot [B]^b.", "Hằng số tốc độ phản ứng k chỉ phụ thuộc vào bản chất của chất phản ứng và nhiệt độ, không phụ thuộc vào nồng độ các chất."] },
          { title: "5 Yếu tố ảnh hưởng đến tốc độ phản ứng", points: ["1. Nồng độ: Nồng độ chất phản ứng tăng làm tăng số va chạm hiệu quả \\Rightarrow tốc độ phản ứng tăng.", "2. Áp suất: Đối với chất khí, tăng áp suất tương đương tăng nồng độ khí \\Rightarrow tốc độ phản ứng tăng.", "3. Diện tích bề mặt: Tăng diện tích tiếp xúc (nghiền nhỏ chất rắn) \\Rightarrow tốc độ phản ứng tăng.", "4. Nhiệt độ: Khi tăng nhiệt độ, các phân tử chuyển động nhanh hơn, số va chạm hiệu quả tăng. Quy tắc Van't Hoff: Cứ tăng 10^\\circ C thì tốc độ phản ứng tăng từ 2 đến 4 lần (\\gamma).", "5. Chất xúc tác: Làm giảm năng lượng hoạt hóa của phản ứng \\Rightarrow tăng tốc độ phản ứng mà không bị tiêu hao sau phản ứng."] }
        ],
        examples: [
          { q: "Một phản ứng hóa học ở 20^\\circ C có tốc độ v_1. Biết hệ số nhiệt độ Van't Hoff của phản ứng là \\gamma = 3. Hỏi khi tăng nhiệt độ lên 50^\\circ C thì tốc độ phản ứng tăng lên bao nhiêu lần?", a: "Độ tăng nhiệt độ: \\Delta T = 50 - 20 = 30^\\circ C.\\nÁp dụng công thức Van't Hoff:\\n\\frac{v_2}{v_1} = \\gamma^{\\frac{T_2 - T_1}{10}} = 3^{\\frac{30}{10}} = 3^3 = 27 \\text{ lần}.\\nVậy tốc độ phản ứng tăng lên 27 lần." }
        ]
      }
  },
  {
    id: "hoa-10-05",
    subject: "hoa",
    title: "Chuyên Đề Nhóm Halogen (Nhóm VIIA): Tính Oxi Hóa, Hydrogen Halide & Muối Halide",
    grade: 10,
    category: "chuyen-de-10-11",
    source: "Tổ Hóa THPT Chuyên KHTN & Vietchem",
    year: 2025,
    buoiHoc: "Chuyên đề 28",
    caLive: "",
    ngayLive: "",
    description: "Cấu tạo phân tử halogen (F2, Cl2, Br2, I2), xu hướng giảm dần tính oxi hóa, điều chế nước Javel, tính acid của các hydrohalic acid HF, HCl, HBr, HI và nhận biết ion halide.",
    link: "https://vietjack.com/hoa-hoc-10/nhom-halogen.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 10", "Halogen", "Chlorine", "Nước Javel", "Hydrohalic acid", "Nhận biết ion halide"],
    downloads: 16300,
    featured: false,
    studyContent: {
        summary: "Nhóm nguyên tố phi kim điển hình nhất trong bảng tuần hoàn. Thường xuyên xuất hiện trong các bài toán thực tế về xử lý nước hồ bơi, tẩy trắng bằng nước Javel và muối I-ốt phòng ngừa bướu cổ.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Phản ứng đẩy halogen: X_2 + 2NaY \\rightarrow 2NaX + Y_2 \\quad (\\text{với } X_2 \\text{ đứng trước } Y_2)",
          "Nước Javel: Cl_2 + 2NaOH \\rightarrow NaCl + NaClO + H_2O",
          "Tẩy trắng của Cl_2 ẩm: Cl_2 + H_2O \\rightleftharpoons HCl + HClO \\quad (HClO \\text{ có tính oxi hóa mạnh})",
          "Ăn mòn thủy tinh: 4HF + SiO_2 \\rightarrow SiF_4 + 2H_2O",
          "Kết tủa nhận biết: AgCl \\downarrow \\text{(trắng)}, AgBr \\downarrow \\text{(vàng nhạt)}, AgI \\downarrow \\text{(vàng đậm)}"
        ],
        studyTips: [
          "1. Chú ý: F_2 KHÔNG BAO GIỜ đẩy được Cl_2, Br_2, I_2 ra khỏi dung dịch muối vì F_2 sẽ phản ứng ngay với nước trước.",
          "2. Nhận biết hồ tinh bột bằng I_2 tạo màu xanh tím đặc trưng.",
          "3. Muối AgCl, AgBr, AgI đều không tan trong acid mạnh (HNO_3 loãng)."
        ],
        theory: [
          { title: "Tính chất của đơn chất Halogen (X_2)", points: ["Cấu hình electron lớp ngoài cùng ns^2 np^5. Ở trạng thái đơn chất, các phân tử tồn tại dạng hai nguyên tử X_2 liên kết cộng hóa trị không phân cực.", "Tính oxi hóa giảm dần: F_2 > Cl_2 > Br_2 > I_2. Halogen đứng trước đẩy được halogen đứng sau ra khỏi dung dịch muối: Cl_2 + 2NaBr \\rightarrow 2NaCl + Br_2.", "Fluorine (F_2) là phi kim mạnh nhất, oxi hóa mãnh liệt nước ngay ở nhiệt độ thường: 2F_2 + 2H_2O \\rightarrow 4HF + O_2.", "Clo tác dụng với NaOH ở nhiệt độ thường tạo nước Javel: Cl_2 + 2NaOH \\rightarrow NaCl + NaClO + H_2O."] },
          { title: "Hydrogen halide & Nhận biết ion Halide", points: ["Tính acid của hydrohalic acid tăng dần theo thứ tự: HF < HCl < HBr < HI (HF là acid yếu nhưng có tính chất đặc biệt ăn mòn thủy tinh: 4HF + SiO_2 \\rightarrow SiF_4 + 2H_2O).", "Nhận biết các ion halide bằng dung dịch AgNO_3:\\n- F^-: Không có kết tủa (AgF tan).\\n- Cl^-: Kết tủa trắng AgCl.\\n- Br^-: Kết tủa vàng nhạt AgBr.\\n- I^-: Kết tủa vàng đậm AgI."] }
        ],
        examples: [
          { q: "Nhận biết 4 dung dịch mất nhãn chứa các muối riêng biệt: NaF, NaCl, NaBr, NaI chỉ bằng một thuốc thử duy nhất.", a: "Dùng một thuốc thử duy nhất là dung dịch AgNO_3:\\n- Lọ xuất hiện kết tủa trắng là NaCl: NaCl + AgNO_3 \\rightarrow AgCl \\downarrow (trắng) + NaNO_3.\\n- Lọ xuất hiện kết tủa vàng nhạt là NaBr: NaBr + AgNO_3 \\rightarrow AgBr \\downarrow (vàng nhạt) + NaNO_3.\\n- Lọ xuất hiện kết tủa vàng đậm là NaI: NaI + AgNO_3 \\rightarrow AgI \\downarrow (vàng đậm) + NaNO_3.\\n- Lọ không xuất hiện hiện tượng kết tủa là NaF (do AgF tan tốt trong nước)." }
        ]
      }
  },
  {
    id: "hoa-11-01",
    subject: "hoa",
    title: "Cân Bằng Hóa Học, Thuyết Bronsted - Lowry Về Acid - Base & Độ pH Dung Dịch",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thầy Phạm Thắng & SGK Kết Nối Tri Thức",
    year: 2025,
    buoiHoc: "Chuyên đề 29",
    caLive: "",
    ngayLive: "",
    description: "Phản ứng thuận nghịch, hằng số cân bằng Kc, nguyên lý Le Chatelier, thuyết acid - base của Bronsted - Lowry, tích số ion của nước Kw, thang pH và chuẩn độ acid - base.",
    link: "https://vietjack.com/hoa-hoc-11/can-bang-hoa-hoc-ph.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 11", "Cân bằng hóa học", "Le Chatelier", "Acid - Base", "Bronsted - Lowry", "Độ pH", "Chuẩn độ"],
    downloads: 18700,
    featured: true,
    studyContent: {
        summary: "Kiến thức đại cương quan trọng bậc nhất của Hóa 11. Giải thích sự chuyển dịch cân bằng trong công nghiệp sản xuất NH3 (quy trình Haber-Bosch), SO3 và tính chính xác pH trong máu người.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Hằng số cân bằng: K_c = \\frac{[C]^c [D]^d}{[A]^a [B]^b}",
          "Chuyển dịch cân bằng: Tăng T \\rightarrow chiều thu nhiệt (\\Delta H > 0); Giảm T \\rightarrow chiều tỏa nhiệt (\\Delta H < 0)",
          "Tăng áp suất \\rightarrow chuyển dịch về phía giảm số mol phân tử khí",
          "pH = -\\log[H^+]; \\quad pOH = -\\log[OH^-]; \\quad pH + pOH = 14 \\text{ (ở } 25^\\circ\\text{C)}",
          "Công thức chuẩn độ: C_{acid} \\cdot V_{acid} = C_{base} \\cdot V_{base}"
        ],
        studyTips: [
          "1. Chất xúc tác làm tăng tốc độ phản ứng thuận và nghịch như nhau nên KHÔNG làm chuyển dịch cân bằng.",
          "2. Nếu phản ứng có tổng số mol khí hai vế bằng nhau (\\Delta n = 0) thì áp suất KHÔNG làm chuyển dịch cân bằng.",
          "3. Nhớ quy tắc: TĂNG thì hệ CHỐNG BẰNG CÁCH GIẢM, GIẢM thì hệ CHỐNG BẰNG CÁCH TĂNG."
        ],
        theory: [
          { title: "Cân bằng hóa học & Nguyên lý Le Chatelier", points: ["Cân bằng hóa học là trạng thái của phản ứng thuận nghịch khi tốc độ phản ứng thuận bằng tốc độ phản ứng nghịch (v_t = v_n). Đây là cân bằng động.", "Biểu thức hằng số cân bằng: Với aA + bB \\rightleftharpoons cC + dD thì K_c = \\frac{[C]^c [D]^d}{[A]^a [B]^b} (chất rắn không có mặt trong biểu thức). Hằng số K_c CHỈ phụ thuộc vào nhiệt độ.", "Nguyên lý Le Chatelier: Khi một hệ cân bằng bị thay đổi một trong các yếu tố nồng độ, nhiệt độ, áp suất thì cân bằng sẽ chuyển dịch theo chiều chống lại sự thay đổi đó."] },
          { title: "Thuyết Bronsted - Lowry & Thang pH", points: ["Acid là chất có khả năng cho proton H^+; Base là chất có khả năng nhận proton H^+.", "Chất lưỡng tính: Vừa có thể cho proton, vừa có thể nhận proton (ví dụ H_2O, HCO_3^-, HSO_3^-).", "Tích số ion của nước ở 25^\\circ C: K_w = [H^+][OH^-] = 10^{-14}.", "pH = -\\log[H^+]; [H^+] = 10^{-pH}. Môi trường trung tính pH = 7, môi trường acid pH < 7, môi trường base pH > 7."] }
        ],
        examples: [
          { q: "Cho cân bằng trong bình kín: N_2(g) + 3H_2(g) \\rightleftharpoons 2NH_3(g) có \\Delta_r H^0_{298} = -92 kJ. Cân bằng chuyển dịch theo chiều nào khi: (a) Tăng nhiệt độ? (b) Tăng áp suất chung của hệ?", a: "Xét phản ứng:\\n(a) Vì \\Delta_r H^0_{298} = -92 kJ < 0 nên phản ứng thuận là tỏa nhiệt, phản ứng nghịch là thu nhiệt.\\nKhi tăng nhiệt độ, theo nguyên lý Le Chatelier, cân bằng chuyển dịch theo chiều làm giảm nhiệt độ (chiều thu nhiệt) \\Rightarrow Cân bằng chuyển dịch theo chiều nghịch.\\n(b) Vế trái có 1 + 3 = 4 mol khí, vế phải có 2 mol khí.\\nKhi tăng áp suất, cân bằng chuyển dịch theo chiều làm giảm số mol khí \\Rightarrow Cân bằng chuyển dịch theo chiều thuận (tạo ra nhiều NH_3 hơn)." }
        ]
      }
  },
  {
    id: "hoa-11-02",
    subject: "hoa",
    title: "Đại Cương Hóa Hữu Cơ & Hydrocarbon (Alkane, Alkene, Alkyne, Arene)",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thầy Phạm Thắng & VietJack",
    year: 2025,
    buoiHoc: "Chuyên đề 30",
    caLive: "",
    ngayLive: "",
    description: "Thuyết cấu tạo hóa học, đồng phân, danh pháp IUPAC, tính chất đặc trưng của alkane (thế SR), alkene/alkyne (cộng Markovnikov, trùng hợp, tráng bạc alk-1-yne) và arene.",
    link: "https://vietjack.com/hoa-hoc-11/hydrocarbon.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 11", "Hóa hữu cơ", "Alkane", "Alkene", "Alkyne", "Arene", "Markovnikov", "Quy tắc thế vòng"],
    downloads: 19300,
    featured: true,
    studyContent: {
        summary: "Bước chuyển sang toàn bộ nhánh Hóa học Hữu cơ. Nắm vững danh pháp thay thế IUPAC, quy tắc cộng Markovnikov và quy tắc thế vòng benzene là điều kiện tiên quyết để học tốt Este - Lipit lớp 12.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Công thức chung: Alkane C_n H_{2n+2}; Alkene C_n H_{2n}; Alkyne C_n H_{2n-2}; Arene C_n H_{2n-6}",
          "Độ bất bão hòa: k = \\frac{2C + 2 - H}{2} = \\pi + \\text{vòng}",
          "Quy tắc cộng Markovnikov: H \\rightarrow C \\text{ giàu H (bậc thấp)}, X \\rightarrow C \\text{ nghèo H (bậc cao)}",
          "Alk-1-yne phản ứng tạo kết tủa: RC \\equiv CH + AgNO_3 + NH_3 \\rightarrow RC \\equiv CAg \\downarrow + NH_4NO_3",
          "Toluene thế brom (Fe, t^\\circ) \\rightarrow o\\text{-bromotoluene} + p\\text{-bromotoluene}"
        ],
        studyTips: [
          "1. Nhận biết alkene/alkyne dùng nước brom (mất màu nâu đỏ) hoặc dung dịch KMnO_4 (mất màu tím, xuất hiện kết tủa nâu đen MnO_2).",
          "2. Phân biệt Alk-1-yne (có nối ba đầu mạch) với các alkyne khác bằng thuốc thử AgNO_3/NH_3.",
          "3. Toluene tác dụng với Br_2: Nếu có bột sắt (Fe) xúc tác thì thế vào nhân thơm; nếu chiếu sáng (as) thì thế vào nhánh metyl."
        ],
        theory: [
          { title: "Các loại Hydrocarbon cơ bản", points: ["Alkane (C_n H_{2n+2}, n \\ge 1): Hydrocarbon no chỉ chứa liên kết đơn C-C và C-H. Đặc trưng là phản ứng thế halogen (ưu tiên thế H ở C bậc cao nhất) và phản ứng cracking.", "Alkene (C_n H_{2n}, n \\ge 2): Chứa 1 liên kết đôi C=C (1 liên kết \\sigma bền + 1 liên kết \\pi kém bền). Làm mất màu nước brom, thuốc tím KMnO_4. Phản ứng cộng tuân theo quy tắc Markovnikov.", "Alkyne (C_n H_{2n-2}, n \\ge 2): Chứa 1 liên kết ba C \\equiv C. Các alk-1-yne có liên kết ba đầu mạch tác dụng với dung dịch AgNO_3/NH_3 tạo kết tủa vàng nhạt của muối bạc alkinua.", "Arene (Benzene C_6H_6 và đồng đẳng): Vòng thơm liên hợp bền vững. Tính chất 'dễ thế, khó cộng, bền với chất oxi hóa'."] },
          { title: "Quy tắc Markovnikov & Quy tắc thế Aren", points: ["Quy tắc cộng Markovnikov: Khi cộng phân tử bất đối xứng HX (như HCl, HBr, H_2O) vào alkene bất đối xứng, nguyên tử H ưu tiên cộng vào nguyên tử C mang nhiều H hơn (tạo sản phẩm chính).", "Quy tắc thế vòng benzene: Nếu vòng benzene có sẵn nhóm thế no (đẩy e như -CH_3, -OH, -NH_2) thì phản ứng thế tiếp theo ưu tiên vào vị trí ortho và para. Nếu có nhóm hút e (-NO_2, -COOH, -CHO) thì ưu tiên vào vị trí meta."] }
        ],
        examples: [
          { q: "Viết công thức cấu tạo của sản phẩm chính khi cho propene (CH_2=CH-CH_3) tác dụng với HBr.", a: "Phản ứng cộng HBr vào liên kết đôi của propene (alkene bất đối xứng):\\nCH_2=CH-CH_3 + HBr \\rightarrow ?\\nTheo quy tắc cộng Markovnikov, nguyên tử H sẽ cộng vào nguyên tử carbon mang nhiều H hơn (nhóm =CH_2), còn nguyên tử Br sẽ cộng vào carbon mang ít H hơn (nhóm -CH=).\\nSản phẩm chính là 2-bromopropane: CH_3-CH(Br)-CH_3.\\nSản phẩm phụ là 1-bromopropane: CH_2(Br)-CH_2-CH_3." }
        ]
      }
  },
  {
    id: "hoa-11-03",
    subject: "hoa",
    title: "Đơn Chất Nitrogen, Ammonia, Muối Ammonium, Nitric Acid & Mưa Acid",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Khoa Hóa ĐH Sư Phạm Hà Nội & VietJack",
    year: 2025,
    buoiHoc: "Chuyên đề 31",
    caLive: "",
    ngayLive: "",
    description: "Liên kết 3 bền vững trong N2, tính base và tính khử của NH3, nhiệt phân muối ammonium, tính oxi hóa cực mạnh của HNO3 và hiện tượng phú dưỡng nguồn nước.",
    link: "https://vietjack.com/hoa-hoc-11/nitrogen-ammonia-hno3.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 11", "Nitrogen", "Ammonia", "Muối ammonium", "Nitric acid", "Tính oxi hóa mạnh", "Phú dưỡng"],
    downloads: 17800,
    featured: false,
    studyContent: {
        summary: "Nhóm nguyên tố phi kim với nhiều hợp chất có ứng dụng thực tiễn to lớn (sản xuất phân đạm, thuốc nổ, acid công nghiệp). Hiểu rõ phản ứng oxi hóa của HNO3 với kim loại không giải phóng khí H2.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Tính base của NH_3: NH_3 + H_2O \\rightleftharpoons NH_4^+ + OH^-",
          "Tính khử của NH_3: 4NH_3 + 3O_2 \\xrightarrow{t^\\circ} 2N_2 + 6H_2O; \\quad 4NH_3 + 5O_2 \\xrightarrow{Pt, t^\\circ} 4NO + 6H_2O",
          "Phản ứng kim loại với HNO_3: M + HNO_3 \\rightarrow M(NO_3)_n + \\text{Sản phẩm khử} (NO_2, NO...) + H_2O",
          "Công thức tính nhanh số mol HNO_3 phản ứng: n_{HNO_3} = 2n_{NO_2} + 4n_{NO} + 10n_{N_2O} + 12n_{N_2} + 10n_{NH_4NO_3} + 2n_O (\\text{oxit})"
        ],
        studyTips: [
          "1. Dùng dung dịch kiềm đun nóng để nhận biết ion NH_4^+ qua mùi khai của khí NH_3 bay ra.",
          "2. Kim loại có tính khử mạnh (Mg, Al, Zn) tác dụng với HNO_3 rất dễ sinh ra muối ammonium NH_4NO_3 (dung dịch không có khí bay ra).",
          "3. Chú ý hiện tượng thụ động hóa: Fe và Al có thể dùng bình chứa làm bằng sắt/nhôm để đựng HNO_3 đặc, nguội."
        ],
        theory: [
          { title: "Đơn chất Nitrogen & Khí Ammonia (NH_3)", points: ["Phân tử N_2 có liên kết ba rất bền N \\equiv N (năng lượng liên kết 945 kJ/mol) nên ở nhiệt độ thường nitrogen khá trơ về mặt hóa học.", "Ammonia (NH_3) có dạng chóp tam giác, nguyên tử N còn một cặp electron tự do \\Rightarrow NH_3 thể hiện tính base yếu (làm xanh quỳ tím ẩm) và tính khử mạnh.", "Muối ammonium (NH_4^+) dễ tan trong nước, bị thủy phân tạo môi trường acid nhẹ; tác dụng với dung dịch kiềm sinh ra khí NH_3 có mùi khai đặc trưng."] },
          { title: "Nitric acid (HNO_3) & Hiện tượng môi trường", points: ["HNO_3 là một acid mạnh và là chất oxi hóa rất mạnh. Oxi hóa được hầu hết kim loại (trừ Au, Pt), phi kim (C, P, S) và hợp chất có số oxi hóa trung gian.", "Kim loại tác dụng với HNO_3 KHÔNG GIẢI PHÓNG H_2 mà tạo ra các sản phẩm khử của N: NO_2 (khí màu nâu đỏ), NO (khí không màu hóa nâu trong không khí), N_2O, N_2, NH_4NO_3.", "Al, Fe, Cr bị thụ động hóa trong HNO_3 đặc, nguội.", "Hiện tượng phú dưỡng (Eutrophication): Sự tích tụ dư thừa dinh dưỡng nitrate và phosphate trong nước ao hồ làm tảo nở hoa, suy giảm oxy hòa tan, cá chết hàng loạt."] }
        ],
        examples: [
          { q: "Hòa tan hoàn toàn 6.4 gam kim loại Cu vào dung dịch HNO_3 loãng dư. Tính thể tích khí NO (sản phẩm khử duy nhất, ở đkc 25^\\circ C, 1 bar) thu được.", a: "Số mol Cu: n_{Cu} = \\frac{6.4}{64} = 0.1 mol.\\nPhương trình phản ứng:\\n3Cu + 8HNO_3 \\rightarrow 3Cu(NO_3)_2 + 2NO \\uparrow + 4H_2O\\nTheo phương trình:\\nn_{NO} = \\frac{2}{3} n_{Cu} = \\frac{2}{3} \\times 0.1 = \\frac{0.2}{3} \\approx 0.0667 mol.\\nThể tích khí NO ở điều kiện chuẩn (đkc, 1 mol khí = 24.79 L):\\nV_{NO} = 0.0667 \\times 24.79 \\approx 1.653 L." }
        ]
      }
  },
  {
    id: "hoa-11-04",
    subject: "hoa",
    title: "Chuyên Đề Sulfur, Sulfur Dioxide & Sulfuric Acid (H2SO4 Đặc/Loãng)",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Tổ Hóa Chuyên Amsterdam & Vietchem",
    year: 2025,
    buoiHoc: "Chuyên đề 32",
    caLive: "",
    ngayLive: "",
    description: "Tính oxi hóa và tính khử của sulfur, khí SO2 (tính chất tẩy màu, gây mưa acid), quy trình tiếp xúc sản xuất H2SO4, tính háo nước và tính oxi hóa mạnh của H2SO4 đặc.",
    link: "https://vietjack.com/hoa-hoc-11/sulfur-h2so4.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 11", "Sulfur", "Sulfur dioxide", "H2SO4 đặc", "Quy trình tiếp xúc", "Mưa acid"],
    downloads: 16600,
    featured: false,
    studyContent: {
        summary: "Sulfuric acid là 'máu của ngành công nghiệp hóa chất'. Nắm vững sự khác biệt hoàn toàn về tính chất giữa H2SO4 loãng (chỉ có tính acid) và H2SO4 đặc (vừa là acid mạnh vừa là chất oxi hóa cực mạnh và háo nước).",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Thu gom thủy ngân: Hg + S \\rightarrow HgS",
          "Tẩy màu nước brom của SO_2: SO_2 + Br_2 + 2H_2O \\rightarrow 2HBr + H_2SO_4",
          "Oxi hóa Cu bằng H_2SO_4 đặc: Cu + 2H_2SO_4 (\\text{đặc}) \\xrightarrow{t^\\circ} CuSO_4 + SO_2 \\uparrow + 2H_2O",
          "Tính háo nước với đường: C_{12}H_{22}O_{11} \\xrightarrow{H_2SO_4 \\text{ đặc}} 12C + 11H_2O",
          "Quy tắc pha loãng an toàn: Rót TỪ TỪ acid vào nước dọc theo đũa thủy tinh, KHÔNG BAO GIỜ làm ngược lại."
        ],
        studyTips: [
          "1. Tuyệt đối không rót nước vào acid đặc vì nhiệt lượng tỏa ra quá lớn làm nước sôi đột ngột bắn acid gây bỏng nguy hiểm.",
          "2. Nhận biết ion SO_4^{2-} bằng dung dịch muối Barium (BaCl_2, Ba(OH)_2) tạo kết tủa trắng BaSO_4 không tan trong acid mạnh.",
          "3. Fe và Al cũng bị thụ động hóa trong H_2SO_4 đặc, nguội."
        ],
        theory: [
          { title: "Đơn chất Sulfur & Khí Sulfur dioxide (SO_2)", points: ["Sulfur (S): Số oxi hóa trung gian là 0, vừa thể hiện tính oxi hóa (tác dụng với kim loại, H_2) vừa thể hiện tính khử (tác dụng với phi kim O_2, F_2). Phản ứng với Thủy ngân (Hg) xảy ra ngay ở nhiệt độ thường dùng để thu gom thủy ngân rơi vỡ.", "SO_2: Khí mùi xốc, độc, sinh ra do đốt nhiên liệu hóa thạch chứa lưu huỳnh; tan trong nước tạo acid H_2SO_3 gây hiện tượng mưa acid.", "SO_2 làm mất màu dung dịch nước Brom và dung dịch thuốc tím KMnO_4 (dùng để nhận biết SO_2)."] },
          { title: "Sulfuric acid (H_2SO_4)", points: ["H_2SO_4 loãng: Mang đầy đủ tính chất của một acid mạnh (quỳ tím hóa đỏ, tác dụng với kim loại đứng trước H giải phóng H_2, tác dụng với basic oxide, base, muối).", "H_2SO_4 đặc: Có tính háo nước mãnh liệt (chiếm lấy nước của các hợp chất carbohydrate như đường mía, tinh bột biến thành than đen xốp xộp).", "H_2SO_4 đặc nóng: Có tính oxi hóa cực mạnh, oxi hóa được Cu, Fe, Ag... và các phi kim C, S, giải phóng khí SO_2.", "Sản xuất H_2SO_4 theo phương pháp tiếp xúc 3 giai đoạn: Quặng Pyrite FeS_2 (hoặc S) \\rightarrow SO_2 \\rightarrow SO_3 (xúc tác V_2O_5) \\rightarrow H_2SO_4 (hấp thụ bằng H_2SO_4 đặc tạo Oleum H_2SO_4.nSO_3)."] }
        ],
        examples: [
          { q: "Cho 11.2 gam sắt (Fe) phản ứng hoàn toàn với dung dịch H_2SO_4 đặc nóng dư. Tính thể tích khí SO_2 sinh ra ở điều kiện chuẩn (đkc 25^\\circ C, 1 bar).", a: "Số mol Fe: n_{Fe} = \\frac{11.2}{56} = 0.2 mol.\\nVì H_2SO_4 đặc nóng dư nên sắt bị oxi hóa lên số oxi hóa cao nhất là +3:\\n2Fe + 6H_2SO_4 (\\text{đặc}) \\xrightarrow{t^\\circ} Fe_2(SO_4)_3 + 3SO_2 \\uparrow + 6H_2O\\nTheo phương trình phản ứng:\\nn_{SO_2} = \\frac{3}{2} n_{Fe} = 1.5 \\times 0.2 = 0.3 mol.\\nThể tích khí SO_2 ở điều kiện chuẩn là:\\nV_{SO_2} = 0.3 \\times 24.79 = 7.437 L." }
        ]
      }
  },
  {
    id: "hoa-11-05",
    subject: "hoa",
    title: "Dẫn Xuất Halogen, Alcohol & Phenol (Cấu Trúc & Phản Ứng Đặc Trưng)",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Tổ Hóa THPT Chuyên Sư Phạm & VietJack",
    year: 2025,
    buoiHoc: "Chuyên đề 33",
    caLive: "",
    ngayLive: "",
    description: "Quy tắc tách Zaitsev của dẫn xuất halogen, liên kết hydrogen của alcohol, phản ứng với kim loại kiềm, phản ứng tách nước (tạo ether hoặc alkene), tính acid và phản ứng thế vòng của Phenol.",
    link: "https://vietjack.com/hoa-hoc-11/alcohol-phenol.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 11", "Dẫn xuất halogen", "Alcohol", "Phenol", "Zaitsev", "Liên kết hydrogen", "Kết tủa trắng Brom"],
    downloads: 18100,
    featured: true,
    studyContent: {
        summary: "Các hợp chất chứa nhóm định chức đầu tiên của Hóa học Hữu cơ. Hiểu rõ sự tương tác qua lại giữa vòng benzene và nhóm -OH trong phân tử Phenol làm tăng khả năng phản ứng thế và tính acid.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Tách nước tạo ether (140^\\circ C): 2ROH \\xrightarrow{H_2SO_4 \\text{ đặc}, 140^\\circ\\text{C}} R-O-R + H_2O",
          "Tách nước tạo alkene (170^\\circ C): C_n H_{2n+1}OH \\xrightarrow{H_2SO_4 \\text{ đặc}, 170^\\circ\\text{C}} C_n H_{2n} + H_2O",
          "Oxi hóa alcohol: R-CH_2OH + CuO \\xrightarrow{t^\\circ} R-CHO + Cu + H_2O",
          "Tính acid của Phenol: C_6H_5OH + NaOH \\rightarrow C_6H_5ONa + H_2O",
          "Nhận biết Phenol bằng Brom: C_6H_5OH + 3Br_2 \\rightarrow C_6H_2Br_3OH \\downarrow \\text{(trắng)} + 3HBr"
        ],
        studyTips: [
          "1. Alcohol đa chức có các nhóm -OH kề nhau (như glycerol, ethylene glycol) hòa tan Cu(OH)_2 tạo phức màu xanh lam thẫm đặc trưng.",
          "2. Phenol tác dụng được với dung dịch kiềm NaOH nhưng alcohol thì KHÔNG tác dụng với dung dịch kiềm.",
          "3. Sục khí CO_2 vào dung dịch sodium phenolate sẽ tái tạo lại phenol vẩn đục: C_6H_5ONa + CO_2 + H_2O \\rightarrow C_6H_5OH + NaHCO_3."
        ],
        theory: [
          { title: "Dẫn xuất halogen & Alcohol (R-OH)", points: ["Dẫn xuất halogen: Phản ứng tách HX theo quy tắc Zaitsev: Nguyên tử halogen X ưu tiên tách ra cùng nguyên tử H ở C bậc cao hơn để tạo alkene có nhiều nhóm thế hơn (bền hơn).", "Alcohol: Có liên kết hydrogen liên phân tử nên nhiệt độ sôi cao hơn nhiều so với hydrocarbon và dẫn xuất halogen tương đương.", "Tác dụng với kim loại kiềm: 2ROH + 2Na \\rightarrow 2RONa + H_2 \\uparrow.", "Phản ứng tách nước của alcohol: Ở 140^\\circ C tạo ether (2ROH \\rightarrow ROR + H_2O); ở 170^\\circ C tạo alkene (theo quy tắc Zaitsev).", "Oxi hóa không hoàn toàn bằng CuO: Alcohol bậc 1 tạo Aldehyde; Alcohol bậc 2 tạo Ketone; Alcohol bậc 3 không bị oxi hóa."] },
          { title: "Phenol (C_6H_5OH)", points: ["Phenol có nhóm -OH liên kết trực tiếp với nguyên tử carbon của vòng benzene.", "Tính acid của phenol: Do ảnh hưởng của vòng benzene hút electron, liên kết O-H phân cực mạnh hơn alcohol \\Rightarrow Phenol có tính acid yếu (làm mất màu NaOH), nhưng yếu hơn H_2CO_3 nên không làm đổi màu quỳ tím.", "Ảnh hưởng của nhóm -OH đến vòng benzene: Làm mật độ electron ở các vị trí ortho và para tăng lên \\Rightarrow Phenol phản ứng dễ dàng với dung dịch Brom tạo kết tủa trắng 2,4,6-tribromophenol (dùng để nhận biết phenol)."] }
        ],
        examples: [
          { q: "Thực hiện phản ứng tách nước từ butan-2-ol (CH_3-CH(OH)-CH_2-CH_3) ở 170^\\circ C có xúc tác H_2SO_4 đặc. Xác định cấu tạo của sản phẩm chính.", a: "Xét cấu tạo butan-2-ol: Nhóm -OH liên kết với C số 2.\\nNguyên tử H có thể tách ở C số 1 (bậc 1) hoặc C số 3 (bậc 2).\\nTheo quy tắc Zaitsev, nhóm -OH ưu tiên tách cùng H ở C bậc cao hơn (C số 3).\\nDo đó sản phẩm chính là but-2-ene:\\nCH_3-CH=CH-CH_3.\\nSản phẩm phụ là but-1-ene: CH_2=CH-CH_2-CH_3." }
        ]
      }
  },
  {
    id: "hoa-11-06",
    subject: "hoa",
    title: "Hợp Chất Carbonyl (Aldehyde, Ketone) & Carboxylic Acid",
    grade: 11,
    category: "chuyen-de-10-11",
    source: "Thầy Phạm Thắng & Tổ Hóa THPT Chuyên KHTN",
    year: 2025,
    buoiHoc: "Chuyên đề 34",
    caLive: "",
    ngayLive: "",
    description: "Nhóm carbonyl >C=O, phản ứng tráng bạc với thuốc thử Tollens, phản ứng tạo iodoform (CHI3 kết tủa vàng), tính acid của acid cacboxylic và phản ứng ester hóa.",
    link: "https://vietjack.com/hoa-hoc-11/carbonyl-carboxylic-acid.jsp",
    fileDe: "",
    fileVietTay: "",
    video: "",
    tags: ["Hóa học 11", "Aldehyde", "Ketone", "Carboxylic acid", "Tráng bạc", "Iodoform", "Ester hóa"],
    downloads: 19100,
    featured: true,
    studyContent: {
        summary: "Cầu nối trực tiếp dẫn thẳng vào Chương 1 Hóa học 12 (Ester - Lipid). Phản ứng ester hóa và tính chất phân biệt giữa aldehyde, ketone và acid là bài toán quen thuộc trong các đề thi THPT Quốc Gia.",
        files: {
          fileDe: "",
          fileVietTay: "",
          video: ""
        },
        keyFormulas: [
          "Phản ứng tráng bạc tỉ lệ: 1 \\text{ RCHO} \\rightarrow 2 \\text{ Ag} \\quad (\\text{Riêng } HCHO \\rightarrow 4 \\text{ Ag})",
          "Phản ứng tạo kết tủa vàng Iodoform: CH_3-C(=O)-R + 3I_2 + 4NaOH \\rightarrow CHI_3 \\downarrow \\text{(vàng)} + RCOONa + 3NaI + 3H_2O",
          "Phản ứng ester hóa: RCOOH + R'OH \\xrightleftharpoons{H_2SO_4 \\text{ đặc}, t^\\circ} RCOOR' + H_2O",
          "Tác dụng với muối carbonate: 2RCOOH + Na_2CO_3 \\rightarrow 2RCOONa + CO_2 \\uparrow + H_2O"
        ],
        studyTips: [
          "1. Ketone KHÔNG tham gia phản ứng tráng bạc với thuốc thử Tollens (dùng để phân biệt aldehyde và ketone).",
          "2. Formic acid (HCOOH) vừa có nhóm acid -COOH vừa có nhóm aldehyde -CHO nên VỪA có tính acid VỪA tham gia phản ứng tráng bạc.",
          "3. Phản ứng ester hóa là phản ứng thuận nghịch hai chiều, H_2SO_4 đặc đóng vai trò vừa là chất xúc tác vừa hút nước để chuyển dịch cân bằng sang phải."
        ],
        theory: [
          { title: "Hợp chất Carbonyl (Aldehyde & Ketone)", points: ["Cùng chứa nhóm carbonyl >C=O. Aldehyde có nhóm -CH=O liên kết với C hoặc H; Ketone có nhóm >C=O liên kết với hai gốc hydrocarbon.", "Phản ứng tráng bạc với thuốc thử Tollens: Aldehyde bị oxi hóa bởi [Ag(NH_3)_2]OH tạo thành bạc kim loại Ag bám sáng bóng trên thành ống nghiệm: RCHO + 2[Ag(NH_3)_2]OH \\rightarrow RCOONH_4 + 2Ag \\downarrow + 3NH_3 + H_2O.", "Phản ứng tạo iodoform: Các hợp chất chứa nhóm CH_3-C=O hoặc CH_3-CH(OH)- phản ứng với I_2 trong dung dịch kiềm tạo kết tủa vàng iodoform CHI_3 (dùng nhận biết acetone, ethanal, ethanol).", "Phản ứng khử: Cả aldehyde và ketone đều bị khử bởi NaBH_4 hoặc LiAlH_4 tạo alcohol tương ứng."] },
          { title: "Carboxylic Acid (R-COOH)", points: ["Chứa nhóm carboxyl -COOH gồm nhóm carbonyl >C=O gắn với nhóm hydroxyl -OH.", "Tạo liên kết hydrogen liên phân tử bền dạng nhị hợp tử (dimer) nên có nhiệt độ sôi cao nhất trong các hợp chất hữu cơ có cùng số C.", "Tính acid: Làm đỏ quỳ tím, tác dụng với kim loại đứng trước H, oxide base, base và muối carbonate (sinh ra khí CO_2).", "Phản ứng ester hóa: Tác dụng thuận nghịch với alcohol có mặt xúc tác H_2SO_4 đặc, đun nóng sinh ra ester và nước."] }
        ],
        examples: [
          { q: "Cho 4.4 gam acetaldehyde (CH_3CHO) tác dụng hoàn toàn với lượng dư dung dịch AgNO_3 trong NH_3, đun nóng nhẹ. Tính khối lượng Ag kim loại kết tủa thu được.", a: "Phân tử khối của CH_3CHO là M = 44 g/mol.\\nSố mol acetaldehyde: n_{CH_3CHO} = \\frac{4.4}{44} = 0.1 mol.\\nPhương trình phản ứng tráng bạc:\\nCH_3CHO + 2[Ag(NH_3)_2]OH \\rightarrow CH_3COONH_4 + 2Ag \\downarrow + 3NH_3 + H_2O\\nTheo phương trình:\\nn_{Ag} = 2 \\times n_{CH_3CHO} = 2 \\times 0.1 = 0.2 mol.\\nKhối lượng bạc kết tủa thu được:\\nm_{Ag} = 0.2 \\times 108 = 21.6 gam." }
        ]
      }
  }
];
